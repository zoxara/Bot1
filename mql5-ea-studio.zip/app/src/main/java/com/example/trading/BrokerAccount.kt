package com.example.trading

enum class BrokerConnectionState(val label: String) {
    DISCONNECTED("Disconnected"),
    CONNECTING("Connecting to MT5 Terminal..."),
    CONNECTED("Connected to MT5 Broker"),
    AUTH_FAILED("Authentication Failed")
}

data class BrokerCredentials(
    val loginId: String = "10892415",
    val password: String = "Mql5SecurePass#99",
    val server: String = "XMGlobal-Real 20",
    val bridgeEndpoint: String = "http://127.0.0.1:8080/mql5_bridge",
    val rememberCredentials: Boolean = true
)

data class BrokerAccountInfo(
    val loginId: String = "10892415",
    val serverName: String = "XMGlobal-Real 20",
    val brokerCompany: String = "XM Global Limited",
    val currency: String = "USD",
    val balance: Double = 10000.00,
    val equity: Double = 10000.00,
    val margin: Double = 0.0,
    val freeMargin: Double = 10000.00,
    val marginLevelPercent: Double = 0.0,
    val leverage: Int = 500,
    val pingLatencyMs: Int = 18,
    val serverTime: String = "22:42:00 GMT+2",
    val isDemo: Boolean = false,
    val tradeAllowed: Boolean = true,
    val hedgingAllowed: Boolean = true,
    val lastSyncTime: String = "Just now"
)

val PRESET_BROKER_SERVERS = listOf(
    "XMGlobal-Real 20",
    "XMGlobal-Real 1",
    "XMGlobal-Real 50",
    "XMGlobal-Demo",
    "Exness-Real",
    "ICMarketsSC-Live",
    "OctaFX-Real",
    "Custom Server"
)
