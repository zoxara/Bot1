package com.example.trading

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.mql5.Mql5Config
import com.example.notifications.FcmAlertManager
import com.example.notifications.FcmEventType
import com.example.notifications.FcmTradeAlert
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class TradingAsset(
    val symbol: String,
    val name: String,
    val basePrice: Double,
    val digits: Int,
    val point: Double,
    val spreadPoints: Int
)

data class SimulatedCandle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long = 1200L
)

enum class OrderType(val label: String, val isPending: Boolean) {
    BUY("Buy (Market)", false),
    SELL("Sell (Market)", false),
    BUY_LIMIT("Buy Limit", true),
    SELL_LIMIT("Sell Limit", true),
    BUY_STOP("Buy Stop", true),
    SELL_STOP("Sell Stop", true)
}

enum class OrderSideFilter(val label: String) {
    ALL("All Trades"),
    BUY_ONLY("Buys Only"),
    SELL_ONLY("Sells Only")
}

data class SimulatedPosition(
    val ticket: Long,
    val symbol: String,
    val isBuy: Boolean,
    val lots: Double,
    val openPrice: Double,
    var sl: Double,
    var tp: Double,
    var isStealthStop: Boolean = true,
    var trailingActive: Boolean = true,
    var currentProfit: Double = 0.0,
    val openTime: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
)

data class PendingOrder(
    val ticket: Long,
    val symbol: String,
    val orderType: OrderType,
    val lots: Double,
    val triggerPrice: Double,
    val sl: Double,
    val tp: Double,
    val time: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
)

data class TradeJournalEntry(
    val id: Long,
    val timestamp: String,
    val action: String,
    val details: String,
    val isSuccess: Boolean = true
)

data class BridgeCommandLog(
    val id: Long,
    val timestamp: String,
    val jsonPayload: String,
    val latencyMs: Int,
    val acknowledged: Boolean = true
)

class TradingEngine(
    private val scope: CoroutineScope,
    var config: Mql5Config = Mql5Config()
) {
    val supportedAssets = listOf(
        TradingAsset("XAUUSD", "Gold vs US Dollar", 2645.20, 2, 0.01, 15),
        TradingAsset("EURUSD", "Euro vs US Dollar", 1.08540, 5, 0.00001, 8),
        TradingAsset("BTCUSD", "Bitcoin vs USD", 64500.0, 1, 0.1, 150),
        TradingAsset("US30", "Dow Jones 30 Index", 41280.0, 1, 1.0, 25),
        TradingAsset("GBPUSD", "British Pound vs USD", 1.29820, 5, 0.00001, 10),
        TradingAsset("NAS100", "Nasdaq 100 Index", 19850.0, 1, 0.1, 20)
    )

    var currentAsset by mutableStateOf(supportedAssets[0])
        private set

    var currentPrice by mutableDoubleStateOf(currentAsset.basePrice)
        private set

    var currentBid by mutableDoubleStateOf(currentAsset.basePrice)
        private set

    var currentAsk by mutableDoubleStateOf(currentAsset.basePrice + currentAsset.spreadPoints * currentAsset.point)
        private set

    var accountBalance by mutableDoubleStateOf(10000.0)
        private set

    var accountEquity by mutableDoubleStateOf(10000.0)
        private set

    var floatingProfit by mutableDoubleStateOf(0.0)
        private set

    var autoTradeActive by mutableStateOf(config.defaultAutoTrade)
        private set

    var marketTrend by mutableStateOf("BULLISH")
        private set

    // Confluence and Win Probability
    var winProbability by mutableIntStateOf(85)
        private set

    var vsaStatus by mutableStateOf("SMART MONEY ACCUMULATION")
        private set

    var vsaVolumeRatio by mutableDoubleStateOf(1.78)
        private set

    var newsStatus by mutableStateOf("CLEAR")
        private set

    var dailyLimitHit by mutableStateOf(false)
        private set

    // User-selected lot size for on-the-fly execution
    var activeLotSize by mutableDoubleStateOf(0.05)

    // Remote Bridge State
    var bridgeConnected by mutableStateOf(true)
        private set

    var bridgeLatencyMs by mutableIntStateOf(12)
        private set

    // Broker Connection & Account Synchronization
    var brokerConnectionState by mutableStateOf(BrokerConnectionState.CONNECTED)
        private set

    var brokerCredentials by mutableStateOf(BrokerCredentials(
        loginId = config.brokerLoginId,
        server = config.brokerServer,
        bridgeEndpoint = config.bridgeUrl
    ))
        private set

    var brokerAccountInfo by mutableStateOf(BrokerAccountInfo(
        loginId = config.brokerLoginId,
        serverName = config.brokerServer,
        balance = accountBalance,
        equity = accountEquity
    ))
        private set

    var marginUsed by mutableDoubleStateOf(0.0)
        private set

    var freeMargin by mutableDoubleStateOf(10000.0)
        private set

    var marginLevelPercent by mutableDoubleStateOf(0.0)
        private set

    var accountLeverage by mutableIntStateOf(500)

    val candles = mutableStateListOf<SimulatedCandle>()
    val openPositions = mutableStateListOf<SimulatedPosition>()
    val pendingOrders = mutableStateListOf<PendingOrder>()
    val tradeJournal = mutableStateListOf<TradeJournalEntry>()
    val bridgeLogs = mutableStateListOf<BridgeCommandLog>()

    private var nextTicket = 105001L
    private var nextLogId = 1L
    private var tickJob: Job? = null
    private var candleTickCount = 0

    init {
        initializeCandles()
        addJournalEntry("SYSTEM", "Initialized MT5 Trading Engine with Stealth Protection & VSA")
        addBridgeLog("""{"cmd":"HANDSHAKE","agent":"Android_Companion","token":"${config.bridgeAuthToken}","status":"SYNCED"}""")
        startTickEngine()
    }

    fun selectAsset(asset: TradingAsset) {
        currentAsset = asset
        currentPrice = asset.basePrice
        currentBid = asset.basePrice
        currentAsk = asset.basePrice + asset.spreadPoints * asset.point
        initializeCandles()
        updateIndicatorAndVsaStats()
        addJournalEntry("SYMBOL", "Switched active symbol to ${asset.symbol}")
        dispatchBridgeCommand("SWITCH_SYMBOL", mapOf("symbol" to asset.symbol))
    }

    fun toggleAutoTrade() {
        autoTradeActive = !autoTradeActive
        val stateStr = if (autoTradeActive) "ENABLED" else "PAUSED"
        addJournalEntry("ALGO", "Auto-Trade $stateStr by user")
        dispatchBridgeCommand("SET_AUTOTRADE", mapOf("enabled" to autoTradeActive))
    }

    fun resetAccount() {
        accountBalance = 10000.0
        accountEquity = 10000.0
        floatingProfit = 0.0
        openPositions.clear()
        pendingOrders.clear()
        dailyLimitHit = false
        addJournalEntry("ACCOUNT", "Account balance reset to $10,000.00")
        dispatchBridgeCommand("RESET_ACCOUNT", emptyMap())
        updateAccountStats()
    }

    // Broker Connection & Authentication
    fun connectBroker(credentials: BrokerCredentials) {
        brokerCredentials = credentials
        brokerConnectionState = BrokerConnectionState.CONNECTING
        addJournalEntry("BROKER", "Authenticating with MT5 broker: ${credentials.server} (Account: #${credentials.loginId})...")
        dispatchBridgeCommand("BROKER_AUTH", mapOf(
            "login" to credentials.loginId,
            "server" to credentials.server,
            "endpoint" to credentials.bridgeEndpoint,
            "token" to config.bridgeAuthToken
        ))

        scope.launch(Dispatchers.Default) {
            delay(650)
            brokerConnectionState = BrokerConnectionState.CONNECTED
            bridgeConnected = true
            bridgeLatencyMs = Random.nextInt(12, 22)
            syncBrokerData()
            addJournalEntry("BROKER", "Handshake confirmed with ${credentials.server}. Live telemetry & position sync online.")
        }
    }

    fun disconnectBroker() {
        brokerConnectionState = BrokerConnectionState.DISCONNECTED
        addJournalEntry("BROKER", "Disconnected from MT5 broker (${brokerCredentials.server}).")
        dispatchBridgeCommand("BROKER_LOGOUT", mapOf("login" to brokerCredentials.loginId))
    }

    fun syncBrokerData() {
        val timeNow = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        bridgeLatencyMs = Random.nextInt(10, 19)
        updateAccountStats()
        brokerAccountInfo = brokerAccountInfo.copy(
            loginId = brokerCredentials.loginId,
            serverName = brokerCredentials.server,
            balance = accountBalance,
            equity = accountEquity,
            margin = marginUsed,
            freeMargin = freeMargin,
            marginLevelPercent = marginLevelPercent,
            leverage = accountLeverage,
            pingLatencyMs = bridgeLatencyMs,
            serverTime = "$timeNow GMT+2",
            lastSyncTime = timeNow
        )
        addJournalEntry("SYNC", "Synchronized balance, margin, and ${openPositions.size} open positions with MT5.")
        dispatchBridgeCommand("SYNC_DATA", mapOf("timestamp" to System.currentTimeMillis()))
    }

    fun updateLeverage(newLeverage: Int) {
        accountLeverage = newLeverage
        brokerAccountInfo = brokerAccountInfo.copy(leverage = newLeverage)
        updateAccountStats()
        addJournalEntry("ACCOUNT", "Broker Account leverage adjusted to 1:$newLeverage")
        dispatchBridgeCommand("SET_LEVERAGE", mapOf("leverage" to newLeverage))
    }

    // Execute Immediate Market Orders
    fun executeMarketBuy(lot: Double = activeLotSize) {
        executeOrder(OrderType.BUY, lot, currentAsk)
    }

    fun executeMarketSell(lot: Double = activeLotSize) {
        executeOrder(OrderType.SELL, lot, currentBid)
    }

    // Execute Advanced Pending Orders (Buy Limit, Sell Limit, Buy Stop, Sell Stop)
    fun placePendingOrder(type: OrderType, lot: Double, targetPrice: Double, customSl: Double? = null, customTp: Double? = null) {
        val ticket = nextTicket++
        val point = currentAsset.point
        val slDist = config.stopLossPoints * point
        val tpDist = config.takeProfitPoints * point

        val isBuyType = type == OrderType.BUY_LIMIT || type == OrderType.BUY_STOP
        val sl = customSl ?: if (isBuyType) targetPrice - slDist else targetPrice + slDist
        val tp = customTp ?: if (isBuyType) targetPrice + tpDist else targetPrice - tpDist

        val pending = PendingOrder(
            ticket = ticket,
            symbol = currentAsset.symbol,
            orderType = type,
            lots = lot,
            triggerPrice = targetPrice,
            sl = sl,
            tp = tp
        )
        pendingOrders.add(pending)
        addJournalEntry(
            "PENDING",
            "Placed #${ticket} ${type.label} @ ${formatPrice(targetPrice)} (SL: ${formatPrice(sl)}, TP: ${formatPrice(tp)})"
        )
        dispatchBridgeCommand(
            "PENDING_ORDER",
            mapOf(
                "ticket" to ticket,
                "type" to type.name,
                "symbol" to currentAsset.symbol,
                "lots" to lot,
                "price" to targetPrice,
                "sl" to sl,
                "tp" to tp,
                "stealth" to config.hideStopsFromBroker
            )
        )
    }

    fun cancelPendingOrder(ticket: Long) {
        val order = pendingOrders.find { it.ticket == ticket }
        if (order != null) {
            pendingOrders.remove(order)
            addJournalEntry("PENDING", "Cancelled #${ticket} ${order.orderType.label}")
            dispatchBridgeCommand("CANCEL_PENDING", mapOf("ticket" to ticket))
        }
    }

    // Modify active trade SL and TP
    fun modifyPositionStops(ticket: Long, newSl: Double, newTp: Double) {
        val pos = openPositions.find { it.ticket == ticket }
        if (pos != null) {
            pos.sl = newSl
            pos.tp = newTp
            addJournalEntry("MODIFY", "Updated #${ticket} Stealth SL: ${formatPrice(newSl)} | TP: ${formatPrice(newTp)}")
            dispatchBridgeCommand(
                "MODIFY_STOPS",
                mapOf("ticket" to ticket, "sl" to newSl, "tp" to newTp, "stealth" to pos.isStealthStop)
            )
        }
    }

    fun closeSinglePosition(ticket: Long) {
        val pos = openPositions.find { it.ticket == ticket } ?: return
        accountBalance += pos.currentProfit
        openPositions.remove(pos)
        updateAccountStats()
        addJournalEntry("CLOSE", "Closed #${ticket} ${if (pos.isBuy) "BUY" else "SELL"} P/L: ${formatCurrency(pos.currentProfit)}")
        dispatchBridgeCommand("CLOSE_POSITION", mapOf("ticket" to ticket))
    }

    // 1. One-Click Breakeven: Moves Stop Loss to open entry price for all positions (securing risk-free trades)
    fun executeBreakeven(filter: OrderSideFilter = OrderSideFilter.ALL, offsetPoints: Int = 0): Int {
        var count = 0
        openPositions.forEach { pos ->
            val matchesFilter = when (filter) {
                OrderSideFilter.ALL -> true
                OrderSideFilter.BUY_ONLY -> pos.isBuy
                OrderSideFilter.SELL_ONLY -> !pos.isBuy
            }
            if (matchesFilter) {
                val offset = offsetPoints * currentAsset.point
                val bePrice = if (pos.isBuy) pos.openPrice + offset else pos.openPrice - offset
                pos.sl = bePrice
                count++
            }
        }
        if (count > 0) {
            val offsetText = if (offsetPoints != 0) " (+${offsetPoints}pts buffer)" else ""
            addJournalEntry("BREAKEVEN", "Secured Breakeven on $count ${filter.label} positions$offsetText")
            dispatchBridgeCommand(
                "BREAKEVEN",
                mapOf(
                    "filter" to filter.name,
                    "symbol" to currentAsset.symbol,
                    "offset_points" to offsetPoints,
                    "modified_count" to count
                )
            )
            com.example.anime.AnimePetManager.say(
                "🛡️ Breakeven secured on $count positions! Risk eliminated, Senpai!",
                com.example.ui.theme.BullGreen,
                com.example.anime.AnimeAnimationPose.CHEERING_BULL
            )
        }
        return count
    }

    // 2. Bulk TP / SL Modifier: Set or modify TP / SL for all active trades simultaneously
    fun bulkModifyStops(
        filter: OrderSideFilter = OrderSideFilter.ALL,
        targetSl: Double? = null,
        targetTp: Double? = null,
        isRelativePoints: Boolean = false,
        slPoints: Int = 0,
        tpPoints: Int = 0
    ): Int {
        var count = 0
        val point = currentAsset.point
        openPositions.forEach { pos ->
            val matchesFilter = when (filter) {
                OrderSideFilter.ALL -> true
                OrderSideFilter.BUY_ONLY -> pos.isBuy
                OrderSideFilter.SELL_ONLY -> !pos.isBuy
            }
            if (matchesFilter) {
                if (isRelativePoints) {
                    if (slPoints > 0) {
                        pos.sl = if (pos.isBuy) pos.openPrice - (slPoints * point) else pos.openPrice + (slPoints * point)
                    }
                    if (tpPoints > 0) {
                        pos.tp = if (pos.isBuy) pos.openPrice + (tpPoints * point) else pos.openPrice - (tpPoints * point)
                    }
                } else {
                    if (targetSl != null) pos.sl = targetSl
                    if (targetTp != null) pos.tp = targetTp
                }
                count++
            }
        }
        if (count > 0) {
            val slDesc = if (targetSl != null) "SL: ${formatPrice(targetSl)}" else if (isRelativePoints && slPoints > 0) "SL: ${slPoints}pts" else "SL: kept"
            val tpDesc = if (targetTp != null) "TP: ${formatPrice(targetTp)}" else if (isRelativePoints && tpPoints > 0) "TP: ${tpPoints}pts" else "TP: kept"
            addJournalEntry("BULK_STOPS", "Bulk updated $count ${filter.label} positions -> $slDesc | $tpDesc")
            dispatchBridgeCommand(
                "BULK_MODIFY_STOPS",
                mapOf(
                    "filter" to filter.name,
                    "symbol" to currentAsset.symbol,
                    "target_sl" to (targetSl ?: 0.0),
                    "target_tp" to (targetTp ?: 0.0),
                    "is_points" to isRelativePoints,
                    "sl_points" to slPoints,
                    "tp_points" to tpPoints,
                    "modified_count" to count
                )
            )
            com.example.anime.AnimePetManager.say(
                "🎯 Bulk TP/SL applied to $count positions successfully!",
                com.example.ui.theme.AccentCyan,
                com.example.anime.AnimeAnimationPose.ANALYZING_CHART
            )
        }
        return count
    }

    // 3. One-Click Close Profit: Closes only trades currently in profit
    fun closeProfitablePositions(filter: OrderSideFilter = OrderSideFilter.ALL): Int {
        val toRemove = mutableListOf<SimulatedPosition>()
        var profitRealized = 0.0
        openPositions.forEach { pos ->
            val matchesFilter = when (filter) {
                OrderSideFilter.ALL -> true
                OrderSideFilter.BUY_ONLY -> pos.isBuy
                OrderSideFilter.SELL_ONLY -> !pos.isBuy
            }
            if (matchesFilter && pos.currentProfit > 0.0) {
                toRemove.add(pos)
                profitRealized += pos.currentProfit
            }
        }
        accountBalance += profitRealized
        openPositions.removeAll(toRemove)
        updateAccountStats()
        if (toRemove.isNotEmpty()) {
            addJournalEntry("CLOSE_PROFIT", "Closed ${toRemove.size} ${filter.label} profitable trades. Banked: ${formatCurrency(profitRealized)}")
            dispatchBridgeCommand(
                "CLOSE_PROFIT",
                mapOf(
                    "filter" to filter.name,
                    "symbol" to currentAsset.symbol,
                    "closed_count" to toRemove.size,
                    "realized_profit" to profitRealized
                )
            )
            com.example.anime.AnimePetManager.notifyTakeProfitHit(profitRealized)
        }
        return toRemove.size
    }

    // 4. One-Click Close Loss: Closes only trades currently in loss
    fun closeLosingPositions(filter: OrderSideFilter = OrderSideFilter.ALL): Int {
        val toRemove = mutableListOf<SimulatedPosition>()
        var lossRealized = 0.0
        openPositions.forEach { pos ->
            val matchesFilter = when (filter) {
                OrderSideFilter.ALL -> true
                OrderSideFilter.BUY_ONLY -> pos.isBuy
                OrderSideFilter.SELL_ONLY -> !pos.isBuy
            }
            if (matchesFilter && pos.currentProfit < 0.0) {
                toRemove.add(pos)
                lossRealized += pos.currentProfit
            }
        }
        accountBalance += lossRealized
        openPositions.removeAll(toRemove)
        updateAccountStats()
        if (toRemove.isNotEmpty()) {
            addJournalEntry("CLOSE_LOSS", "Pruned ${toRemove.size} ${filter.label} losing trades. Loss: ${formatCurrency(lossRealized)}")
            dispatchBridgeCommand(
                "CLOSE_LOSS",
                mapOf(
                    "filter" to filter.name,
                    "symbol" to currentAsset.symbol,
                    "closed_count" to toRemove.size,
                    "realized_loss" to lossRealized
                )
            )
            com.example.anime.AnimePetManager.say(
                "🛡️ Pruned ${toRemove.size} losing trades to protect margin capital!",
                com.example.ui.theme.AccentGold,
                com.example.anime.AnimeAnimationPose.ALERT_BEAR
            )
        }
        return toRemove.size
    }

    // 5. One-Click Close ALL: Emergency bulk termination of active market positions
    fun closeAllPositionsWithFilter(filter: OrderSideFilter = OrderSideFilter.ALL): Int {
        val toRemove = mutableListOf<SimulatedPosition>()
        var totalRealized = 0.0
        openPositions.forEach { pos ->
            val matchesFilter = when (filter) {
                OrderSideFilter.ALL -> true
                OrderSideFilter.BUY_ONLY -> pos.isBuy
                OrderSideFilter.SELL_ONLY -> !pos.isBuy
            }
            if (matchesFilter) {
                toRemove.add(pos)
                totalRealized += pos.currentProfit
            }
        }
        accountBalance += totalRealized
        openPositions.removeAll(toRemove)
        updateAccountStats()
        if (toRemove.isNotEmpty()) {
            addJournalEntry("CLOSE_ALL", "Emergency Close ALL executed: Terminated ${toRemove.size} ${filter.label} positions. Net P/L: ${formatCurrency(totalRealized)}")
            dispatchBridgeCommand(
                "CLOSE_ALL",
                mapOf(
                    "filter" to filter.name,
                    "symbol" to currentAsset.symbol,
                    "closed_count" to toRemove.size,
                    "realized_pnl" to totalRealized
                )
            )
            com.example.anime.AnimePetManager.say(
                "⚡ Emergency Close All! Terminated ${toRemove.size} positions at zero delay.",
                com.example.ui.theme.AccentCyan,
                com.example.anime.AnimeAnimationPose.RUNNING
            )
        }
        return toRemove.size
    }

    fun closeAllPositions(onlyProfitable: Boolean = false) {
        if (onlyProfitable) {
            closeProfitablePositions(OrderSideFilter.ALL)
        } else {
            closeAllPositionsWithFilter(OrderSideFilter.ALL)
        }
    }

    fun pingBridge() {
        bridgeLatencyMs = Random.nextInt(9, 22)
        bridgeConnected = true
        addBridgeLog("""{"cmd":"PING","timestamp":"${System.currentTimeMillis()}","latency":"${bridgeLatencyMs}ms"}""")
    }

    private fun executeOrder(orderType: OrderType, lot: Double, entryPrice: Double) {
        // Hidden / Anti-Manipulation Trade Protection: Check spread spike
        if (config.antiManipulationProtection && currentAsset.spreadPoints > config.maxSpreadPoints) {
            addJournalEntry(
                "REJECTED",
                "Anti-Manipulation Shield: Spread (${currentAsset.spreadPoints} pts) exceeds threshold (${config.maxSpreadPoints} pts). Order blocked to prevent dealing desk stop hunt."
            )
            com.example.anime.AnimePetManager.notifySpreadSpike(currentAsset.spreadPoints, config.maxSpreadPoints)
            return
        }

        val isBuy = orderType == OrderType.BUY
        val point = currentAsset.point
        val slDist = config.stopLossPoints * point
        val tpDist = config.takeProfitPoints * point

        val sl = if (isBuy) entryPrice - slDist else entryPrice + slDist
        val tp = if (isBuy) entryPrice + tpDist else entryPrice - tpDist

        val ticket = nextTicket++
        val pos = SimulatedPosition(
            ticket = ticket,
            symbol = currentAsset.symbol,
            isBuy = isBuy,
            lots = lot,
            openPrice = entryPrice,
            sl = sl,
            tp = tp,
            isStealthStop = config.hideStopsFromBroker,
            trailingActive = config.virtualTrailingStop
        )
        openPositions.add(pos)
        updateAccountStats()

        com.example.anime.AnimePetManager.notifyOrderExecuted(isBuy, lot, currentAsset.symbol)

        val stealthTag = if (config.hideStopsFromBroker) "🛡️ STEALTH (BROKER BLIND)" else "STANDARD"
        addJournalEntry(
            "EXECUTION",
            "Filled #${ticket} ${if (isBuy) "BUY" else "SELL"} ${lot} lots @ ${formatPrice(entryPrice)} [$stealthTag]"
        )

        dispatchBridgeCommand(
            "EXECUTE_MARKET",
            mapOf(
                "ticket" to ticket,
                "action" to if (isBuy) "BUY" else "SELL",
                "symbol" to currentAsset.symbol,
                "lots" to lot,
                "price" to entryPrice,
                "virtual_sl" to sl,
                "virtual_tp" to tp,
                "hide_stops" to config.hideStopsFromBroker,
                "trailing" to config.virtualTrailingStop
            )
        )

        if (config.fcmAlertsEnabled && config.fcmNotifyTradeTriggers) {
            FcmAlertManager.addAlert(
                FcmTradeAlert(
                    id = System.currentTimeMillis(),
                    title = "🟢 TRADE TRIGGERED: ${if (isBuy) "BUY" else "SELL"} ${lot} ${currentAsset.symbol}",
                    body = "Market order filled @ ${formatPrice(entryPrice)}. ${if (config.hideStopsFromBroker) "Stealth SL active (Broker Blind)" else "Standard Stops"}.",
                    eventType = FcmEventType.TRADE_TRIGGERED,
                    symbol = currentAsset.symbol,
                    ticket = ticket,
                    price = entryPrice
                )
            )
        }
    }

    private fun dispatchBridgeCommand(cmd: String, params: Map<String, Any>) {
        val payloadBuilder = StringBuilder()
        payloadBuilder.append("{\"cmd\":\"$cmd\",\"token\":\"${config.bridgeAuthToken}\"")
        params.forEach { (k, v) ->
            payloadBuilder.append(",\"$k\":")
            if (v is Number || v is Boolean) payloadBuilder.append(v) else payloadBuilder.append("\"$v\"")
        }
        payloadBuilder.append("}")
        addBridgeLog(payloadBuilder.toString())
    }

    private fun addBridgeLog(payload: String) {
        val timeStr = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        bridgeLogs.add(0, BridgeCommandLog(nextLogId++, timeStr, payload, bridgeLatencyMs))
        if (bridgeLogs.size > 50) bridgeLogs.removeAt(bridgeLogs.size - 1)
    }

    private fun addJournalEntry(action: String, details: String) {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        tradeJournal.add(0, TradeJournalEntry(nextLogId++, timeStr, action, details))
        if (tradeJournal.size > 50) tradeJournal.removeAt(tradeJournal.size - 1)
    }

    private fun initializeCandles() {
        candles.clear()
        var price = currentAsset.basePrice
        for (i in 0 until 35) {
            val delta = (Random.nextDouble() - 0.48) * currentAsset.point * 40
            val open = price
            val close = price + delta
            val high = max(open, close) + Random.nextDouble() * currentAsset.point * 15
            val low = min(open, close) - Random.nextDouble() * currentAsset.point * 15
            val vol = (1000L..4500L).random()
            candles.add(SimulatedCandle(open, high, low, close, vol))
            price = close
        }
        currentPrice = price
        currentBid = price
        currentAsk = price + currentAsset.spreadPoints * currentAsset.point
    }

    private fun startTickEngine() {
        tickJob?.cancel()
        tickJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(650)
                generateTick()
            }
        }
    }

    private fun generateTick() {
        val volatility = currentAsset.point * (if (currentAsset.symbol == "BTCUSD") 35.0 else 5.0)
        val tickDelta = (Random.nextDouble() - 0.49) * volatility
        val newPrice = max(currentAsset.point * 10, currentPrice + tickDelta)

        currentPrice = newPrice
        currentBid = newPrice
        currentAsk = newPrice + currentAsset.spreadPoints * currentAsset.point

        // 1. Check Pending Orders Trigger conditions
        checkPendingOrdersTrigger()

        // 2. Virtual/Stealth Stop Loss, Take Profit & Trailing Stop monitoring
        monitorVirtualStopsAndTrailing()

        // 3. Update active positions PnL
        var totalFloating = 0.0
        openPositions.forEach { pos ->
            val pnl = if (pos.isBuy) {
                (currentBid - pos.openPrice) / currentAsset.point * (pos.lots * 10.0)
            } else {
                (pos.openPrice - currentAsk) / currentAsset.point * (pos.lots * 10.0)
            }
            pos.currentProfit = pnl
            totalFloating += pnl
        }
        floatingProfit = totalFloating
        accountEquity = accountBalance + totalFloating

        // Daily Drawdown Protection Check
        val ddPct = if (accountBalance > 0) max(0.0, (10000.0 - accountEquity) / 10000.0 * 100.0) else 0.0
        if (ddPct >= config.maxDailyDrawdownPercent) {
            if (!dailyLimitHit) {
                dailyLimitHit = true
                addJournalEntry("CIRCUIT_BREAKER", "Max daily drawdown hit (${config.maxDailyDrawdownPercent}%). Auto-trading halted.")
                if (config.fcmAlertsEnabled && config.fcmNotifyCriticalErrors) {
                    FcmAlertManager.addAlert(
                        FcmTradeAlert(
                            id = System.currentTimeMillis(),
                            title = "🚨 CRITICAL EA ERROR: CIRCUIT BREAKER",
                            body = "Max daily drawdown threshold reached (${config.maxDailyDrawdownPercent}%). Algorithmic trading halted.",
                            eventType = FcmEventType.CRITICAL_ERROR,
                            symbol = currentAsset.symbol
                        )
                    )
                }
            }
        }

        // Candle building
        candleTickCount++
        if (candleTickCount > 8 && candles.isNotEmpty()) {
            candleTickCount = 0
            val last = candles.last()
            val newCandle = SimulatedCandle(
                open = last.close,
                high = max(last.close, currentPrice) + Random.nextDouble() * currentAsset.point * 5,
                low = min(last.close, currentPrice) - Random.nextDouble() * currentAsset.point * 5,
                close = currentPrice,
                volume = (1500L..5500L).random()
            )
            candles.add(newCandle)
            if (candles.size > 45) candles.removeAt(0)
            updateIndicatorAndVsaStats()

            // Automated Entry Check on New Bar Open
            if (autoTradeActive && !dailyLimitHit && winProbability >= config.minConfidencePercent) {
                if (marketTrend == "BULLISH" && openPositions.none { it.isBuy }) {
                    executeMarketBuy()
                } else if (marketTrend == "BEARISH" && openPositions.none { !it.isBuy }) {
                    executeMarketSell()
                }
            }
        }
    }

    private fun checkPendingOrdersTrigger() {
        val triggered = mutableListOf<PendingOrder>()
        pendingOrders.forEach { pending ->
            var isTriggered = false
            when (pending.orderType) {
                OrderType.BUY_LIMIT -> if (currentAsk <= pending.triggerPrice) isTriggered = true
                OrderType.SELL_LIMIT -> if (currentBid >= pending.triggerPrice) isTriggered = true
                OrderType.BUY_STOP -> if (currentAsk >= pending.triggerPrice) isTriggered = true
                OrderType.SELL_STOP -> if (currentBid <= pending.triggerPrice) isTriggered = true
                else -> {}
            }

            if (isTriggered) {
                triggered.add(pending)
                val isBuy = pending.orderType == OrderType.BUY_LIMIT || pending.orderType == OrderType.BUY_STOP
                val entryPrice = if (isBuy) currentAsk else currentBid
                val pos = SimulatedPosition(
                    ticket = nextTicket++,
                    symbol = pending.symbol,
                    isBuy = isBuy,
                    lots = pending.lots,
                    openPrice = entryPrice,
                    sl = pending.sl,
                    tp = pending.tp,
                    isStealthStop = config.hideStopsFromBroker
                )
                openPositions.add(pos)
                addJournalEntry("TRIGGER", "Triggered #${pending.ticket} ${pending.orderType.label} -> Position #${pos.ticket} Opened @ ${formatPrice(entryPrice)}")
            }
        }
        pendingOrders.removeAll(triggered)
    }

    private fun monitorVirtualStopsAndTrailing() {
        val toClose = mutableListOf<Pair<SimulatedPosition, String>>()
        val point = currentAsset.point
        val trailDist = config.trailingStopPoints * point
        val trailStep = config.trailingStepPoints * point

        openPositions.forEach { pos ->
            // Virtual Stop Loss check
            if (pos.isBuy && currentBid <= pos.sl) {
                toClose.add(pos to "STEALTH SL HIT")
            } else if (!pos.isBuy && currentAsk >= pos.sl) {
                toClose.add(pos to "STEALTH SL HIT")
            }
            // Virtual Take Profit check
            else if (pos.isBuy && currentBid >= pos.tp) {
                toClose.add(pos to "STEALTH TP HIT")
            } else if (!pos.isBuy && currentAsk <= pos.tp) {
                toClose.add(pos to "STEALTH TP HIT")
            }
            // Virtual Trailing Stop check
            else if (pos.trailingActive && config.virtualTrailingStop) {
                if (pos.isBuy) {
                    if (currentBid - pos.openPrice > trailDist) {
                        val potentialSl = currentBid - trailDist
                        if (potentialSl - pos.sl >= trailStep) {
                            pos.sl = potentialSl
                        }
                    }
                } else {
                    if (pos.openPrice - currentAsk > trailDist) {
                        val potentialSl = currentAsk + trailDist
                        if (pos.sl - potentialSl >= trailStep) {
                            pos.sl = potentialSl
                        }
                    }
                }
            }
        }

        toClose.forEach { (pos, reason) ->
            accountBalance += pos.currentProfit
            openPositions.remove(pos)
            addJournalEntry("EXIT", "$reason on #${pos.ticket}: P/L ${formatCurrency(pos.currentProfit)}")
            dispatchBridgeCommand("STEALTH_EXIT", mapOf("ticket" to pos.ticket, "reason" to reason))

            val isSl = reason.contains("SL")
            if (!isSl) {
                com.example.anime.AnimePetManager.notifyTakeProfitHit(pos.currentProfit)
            }
            if (config.fcmAlertsEnabled && ((isSl && config.fcmNotifyStopLoss) || (!isSl && config.fcmNotifyTakeProfit))) {
                FcmAlertManager.addAlert(
                    FcmTradeAlert(
                        id = System.currentTimeMillis(),
                        title = if (isSl) "🛑 STOP LOSS BREACHED: #${pos.ticket}" else "🎯 TAKE PROFIT REACHED: #${pos.ticket}",
                        body = "${if (isSl) "Virtual SL hit" else "Target profit achieved"} on ${currentAsset.symbol} ($reason). Position closed. P/L: ${formatCurrency(pos.currentProfit)}",
                        eventType = if (isSl) FcmEventType.STOP_LOSS_HIT else FcmEventType.TAKE_PROFIT_HIT,
                        symbol = currentAsset.symbol,
                        ticket = pos.ticket,
                        price = if (pos.isBuy) currentBid else currentAsk,
                        profit = pos.currentProfit
                    )
                )
            }
        }
        if (toClose.isNotEmpty()) {
            updateAccountStats()
        }
    }

    private fun updateIndicatorAndVsaStats() {
        if (candles.size < 15) return
        val closes = candles.map { it.close }
        val volumes = candles.map { it.volume }
        val lastClose = closes.last()
        val emaFast = closes.takeLast(7).average()
        val emaSlow = closes.takeLast(14).average()
        val avgVolume = volumes.takeLast(15).average()
        val lastVolume = volumes.last()

        vsaVolumeRatio = if (avgVolume > 0) (lastVolume / avgVolume * 100).toInt() / 100.0 else 1.0

        var baseScore = 50

        // 1. Multi-EMA Trend Confluence
        val isBull = lastClose > emaFast && emaFast > emaSlow
        val isBear = lastClose < emaFast && emaFast < emaSlow

        if (isBull) {
            marketTrend = "BULLISH"
            baseScore += 16
        } else if (isBear) {
            marketTrend = "BEARISH"
            baseScore += 16
        } else {
            marketTrend = "NEUTRAL"
        }

        // 2. RSI Confluence
        val rsiValue = (if (isBull) 58.0 else if (isBear) 42.0 else 50.0) + Random.nextDouble(-4.0, 4.0)
        if ((isBull && rsiValue in 52.0..66.0) || (isBear && rsiValue in 34.0..48.0)) {
            baseScore += 12
        }

        // 3. ATR Volatility Confluence
        baseScore += 8

        // 4. Volume Spread Analysis (VSA)
        if (vsaVolumeRatio > 1.5) {
            baseScore += 14
            vsaStatus = if (isBull) "SMART MONEY ACCUMULATION" else "SMART MONEY DISTRIBUTION"
        } else if (vsaVolumeRatio in 1.1..1.5) {
            baseScore += 8
            vsaStatus = "HIGH VOLUME ABSORPTION"
        } else {
            vsaStatus = "VOLUME CONSOLIDATION"
        }

        winProbability = min(96, max(42, baseScore + Random.nextInt(-2, 3)))
    }

    private fun updateAccountStats() {
        var total = 0.0
        openPositions.forEach { total += it.currentProfit }
        floatingProfit = total
        accountEquity = accountBalance + total

        // Contract-based Margin calculations for Forex/CFD
        val contractMultiplier = when (currentAsset.symbol) {
            "XAUUSD" -> 100.0
            "EURUSD", "GBPUSD" -> 100000.0
            else -> 1.0
        }
        val lev = if (accountLeverage > 0) accountLeverage else 500
        var totalMargin = 0.0
        openPositions.forEach { pos ->
            totalMargin += (pos.lots * contractMultiplier * pos.openPrice) / lev
        }
        marginUsed = (totalMargin * 100).toInt() / 100.0
        freeMargin = max(0.0, accountEquity - marginUsed)
        marginLevelPercent = if (marginUsed > 0.0) ((accountEquity / marginUsed) * 1000).toInt() / 10.0 else 0.0

        brokerAccountInfo = brokerAccountInfo.copy(
            balance = accountBalance,
            equity = accountEquity,
            margin = marginUsed,
            freeMargin = freeMargin,
            marginLevelPercent = marginLevelPercent,
            leverage = accountLeverage,
            pingLatencyMs = bridgeLatencyMs
        )
    }

    private fun formatPrice(price: Double): String {
        return String.format(Locale.US, "%.${currentAsset.digits}f", price)
    }

    private fun formatCurrency(amount: Double): String {
        val sign = if (amount >= 0) "+" else ""
        return String.format(Locale.US, "%s$%.2f", sign, amount)
    }
}
