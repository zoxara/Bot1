package com.example.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class Mql5FirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        FcmAlertManager.updateToken(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val title = remoteMessage.notification?.title
            ?: remoteMessage.data["title"]
            ?: "MT5 Trade Alert"
        val body = remoteMessage.notification?.body
            ?: remoteMessage.data["body"]
            ?: "EA trigger received from MetaTrader 5."

        val eventTypeStr = remoteMessage.data["event_type"] ?: "TRADE_TRIGGERED"
        val symbol = remoteMessage.data["symbol"] ?: "XAUUSD"
        val ticket = remoteMessage.data["ticket"]?.toLongOrNull() ?: 0L
        val price = remoteMessage.data["price"]?.toDoubleOrNull() ?: 0.0
        val profit = remoteMessage.data["profit"]?.toDoubleOrNull() ?: 0.0

        val eventType = when (eventTypeStr.uppercase()) {
            "TRADE_TRIGGERED", "BUY", "SELL" -> FcmEventType.TRADE_TRIGGERED
            "STOP_LOSS_HIT", "SL_HIT", "STOP_LOSS" -> FcmEventType.STOP_LOSS_HIT
            "TAKE_PROFIT_HIT", "TP_HIT", "TAKE_PROFIT" -> FcmEventType.TAKE_PROFIT_HIT
            "CRITICAL_ERROR", "ERROR", "CIRCUIT_BREAKER" -> FcmEventType.CRITICAL_ERROR
            else -> FcmEventType.SYSTEM_INFO
        }

        val alert = FcmTradeAlert(
            id = System.currentTimeMillis(),
            title = title,
            body = body,
            eventType = eventType,
            symbol = symbol,
            ticket = ticket,
            price = price,
            profit = profit
        )

        FcmAlertManager.addAlert(alert, applicationContext)
    }
}
