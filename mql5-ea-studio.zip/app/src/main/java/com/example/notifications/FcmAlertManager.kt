package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.google.firebase.messaging.FirebaseMessaging
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FcmEventType(val label: String, val severity: String) {
    TRADE_TRIGGERED("Trade Triggered", "INFO"),
    STOP_LOSS_HIT("Stop Loss Breached", "WARNING"),
    TAKE_PROFIT_HIT("Take Profit Reached", "SUCCESS"),
    CRITICAL_ERROR("Critical EA Error", "CRITICAL"),
    SYSTEM_INFO("System Notice", "INFO")
}

data class FcmTradeAlert(
    val id: Long,
    val title: String,
    val body: String,
    val eventType: FcmEventType,
    val symbol: String = "",
    val ticket: Long = 0L,
    val price: Double = 0.0,
    val profit: Double = 0.0,
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
)

object FcmAlertManager {
    const val CHANNEL_ID = "mql5_trading_alerts"
    const val CHANNEL_NAME = "MQL5 Trade & Risk Alerts"

    var fcmToken by mutableStateOf("Fetching FCM Token...")
        private set

    val alerts = mutableStateListOf<FcmTradeAlert>()
    private var nextAlertId = 1001L

    init {
        // Pre-populate with recent informative EA alerts
        addAlert(
            FcmTradeAlert(
                id = nextAlertId++,
                title = "🟢 TRADE TRIGGERED: BUY 0.20 XAUUSD",
                body = "Market order filled @ 2654.80. Stealth Stop Loss active at 2649.80 (Broker Blind).",
                eventType = FcmEventType.TRADE_TRIGGERED,
                symbol = "XAUUSD",
                ticket = 894125L,
                price = 2654.80
            )
        )
        addAlert(
            FcmTradeAlert(
                id = nextAlertId++,
                title = "🛑 STEALTH STOP LOSS HIT: #894080",
                body = "Price hit virtual SL at 2642.10. EA executed emergency client-side close. Loss: -$120.00.",
                eventType = FcmEventType.STOP_LOSS_HIT,
                symbol = "XAUUSD",
                ticket = 894080L,
                price = 2642.10,
                profit = -120.00
            )
        )
        addAlert(
            FcmTradeAlert(
                id = nextAlertId++,
                title = "⚠️ CRITICAL EA ERROR: CIRCUIT BREAKER",
                body = "Max daily drawdown threshold reached (4.0%). Algorithmic trading halted on all charts.",
                eventType = FcmEventType.CRITICAL_ERROR,
                symbol = "ACCOUNT",
                ticket = 0L
            )
        )
    }

    fun initToken() {
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful && task.result != null) {
                    fcmToken = task.result
                } else {
                    fcmToken = "fcm_token_device_sim_${System.currentTimeMillis().toString().takeLast(8)}"
                }
            }
        } catch (e: Exception) {
            fcmToken = "fcm_token_sim_${System.currentTimeMillis().toString().takeLast(8)}"
        }
    }

    fun updateToken(token: String) {
        fcmToken = token
    }

    fun addAlert(alert: FcmTradeAlert, context: Context? = null) {
        alerts.add(0, alert)
        if (alerts.size > 50) {
            alerts.removeAt(alerts.size - 1)
        }
        if (context != null) {
            postSystemNotification(context, alert)
        }
    }

    fun triggerSimulatedAlert(type: FcmEventType, symbol: String, context: Context) {
        val (title, body) = when (type) {
            FcmEventType.TRADE_TRIGGERED -> {
                "🟢 TRADE TRIGGERED: BUY 0.15 $symbol" to
                        "Order filled @ 2658.20. Win probability: 86% [VSA Confirmed]. Virtual SL: 2652.20."
            }
            FcmEventType.STOP_LOSS_HIT -> {
                "🛑 STOP LOSS BREACHED: $symbol" to
                        "Virtual SL touched at 2645.00. Stealth PositionClose() executed with 0 broker slippage. Loss: -$95.00."
            }
            FcmEventType.TAKE_PROFIT_HIT -> {
                "🎯 TAKE PROFIT REACHED: $symbol" to
                        "Target reached at 2675.00! Position closed with net profit of +$340.00."
            }
            FcmEventType.CRITICAL_ERROR -> {
                "🚨 CRITICAL ERROR: SPREAD ANOMALY" to
                        "Broker spread widened to 65 points during high-impact news release. New orders blocked by anti-manipulation filter."
            }
            FcmEventType.SYSTEM_INFO -> {
                "ℹ️ MT5 BRIDGE HEARTBEAT" to
                        "UniversalQuant_Pro_EA active on chart $symbol M15. Latency 14ms."
            }
        }

        val alert = FcmTradeAlert(
            id = nextAlertId++,
            title = title,
            body = body,
            eventType = type,
            symbol = symbol,
            ticket = (800000L..999999L).random(),
            price = 2658.20
        )
        addAlert(alert, context)
    }

    fun clearAlerts() {
        alerts.clear()
    }

    private fun postSystemNotification(context: Context, alert: FcmTradeAlert) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Instant alerts when MT5 EA triggers trades, stop losses, or critical errors"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 250, 100, 250)
                }
                notificationManager.createNotificationChannel(channel)
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("nav_tab", "tab_alerts")
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                alert.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(alert.title)
                .setContentText(alert.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(alert.body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            notificationManager.notify(alert.id.toInt(), builder.build())
        } catch (e: Exception) {
            // Log or ignore if running in test environment without notification services
        }
    }
}
