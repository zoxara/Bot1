package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.anime.AnimeFloatingPetOverlay
import com.example.anime.AnimePetManager
import com.example.mql5.Mql5CodeGenerator
import com.example.mql5.Mql5Config
import com.example.trading.TradingEngine
import com.example.ui.AlertsScreen
import com.example.ui.AnimeSettingsScreen
import com.example.ui.BridgeScreen
import com.example.ui.BrokerScreen
import com.example.ui.CodeViewerScreen
import com.example.ui.ConfigScreen
import com.example.ui.OnChartGuiScreen
import com.example.ui.SetupGuideScreen
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent()
            }
        }
    }
}

enum class NavTab(val title: String, val icon: ImageVector, val tag: String) {
    ON_CHART_GUI("Dashboard", Icons.Default.ShowChart, "tab_gui"),
    BROKER("Broker", Icons.Default.AccountBalance, "tab_broker"),
    MT5_BRIDGE("Bridge", Icons.Default.NetworkCheck, "tab_bridge"),
    ALERTS("Alerts", Icons.Default.Notifications, "tab_alerts"),
    ANIME_PET("Aoi-chan", Icons.Default.AutoAwesome, "tab_anime"),
    MQL5_CODE("EA Code", Icons.Default.Code, "tab_code"),
    CONFIG("Settings", Icons.Default.Tune, "tab_config"),
    GUIDE("Guide", Icons.Default.HelpOutline, "tab_guide")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(NavTab.ON_CHART_GUI) }
    var config by remember { mutableStateOf(Mql5Config()) }

    val engine = remember { TradingEngine(scope, config) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(BullGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "MQL5 EA Studio",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = TextPrimary
                            )
                            Text(
                                text = "MetaTrader 5 Companion • XM Broker & Stealth Engine",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }
                    }
                },
                actions = {
                    // Aoi-chan Virtual Assistant Quick Action
                    IconButton(
                        onClick = { selectedTab = NavTab.ANIME_PET },
                        modifier = Modifier.testTag("btn_top_aoi_pet")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Aoi-chan Virtual Assistant",
                            tint = if (selectedTab == NavTab.ANIME_PET) AccentGold else AccentCyan
                        )
                    }

                    // Quick Guide Action
                    IconButton(
                        onClick = { selectedTab = NavTab.GUIDE },
                        modifier = Modifier.testTag("btn_top_guide")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = "Setup Guide",
                            tint = if (selectedTab == NavTab.GUIDE) AccentCyan else TextMuted
                        )
                    }

                    // Quick Copy Full Code
                    IconButton(
                        onClick = {
                            val code = Mql5CodeGenerator.generateCompleteMql5Code(config)
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("UniversalQuant_Pro_EA.mq5", code)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "MQL5 EA Code Copied!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("btn_top_copy")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Quick Copy Code",
                            tint = AccentCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                tonalElevation = 4.dp
            ) {
                // Show core navigation tabs
                listOf(
                    NavTab.ON_CHART_GUI,
                    NavTab.BROKER,
                    NavTab.MT5_BRIDGE,
                    NavTab.ALERTS,
                    NavTab.ANIME_PET,
                    NavTab.MQL5_CODE,
                    NavTab.CONFIG
                ).forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AccentCyan,
                            selectedTextColor = AccentCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = AccentCyan.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag(tab.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                NavTab.ON_CHART_GUI -> OnChartGuiScreen(engine = engine)
                NavTab.BROKER -> BrokerScreen(engine = engine)
                NavTab.MT5_BRIDGE -> BridgeScreen(engine = engine)
                NavTab.ALERTS -> AlertsScreen(engine = engine)
                NavTab.ANIME_PET -> AnimeSettingsScreen(engine = engine)
                NavTab.MQL5_CODE -> CodeViewerScreen(config = config)
                NavTab.CONFIG -> ConfigScreen(
                    config = config,
                    onConfigChange = { newConfig ->
                        config = newConfig
                        engine.config = newConfig
                    }
                )
                NavTab.GUIDE -> SetupGuideScreen()
            }

            // Floating Interactive Anime Assistant Mascot (Draggable, Reactive to MT5)
            if (selectedTab != NavTab.ANIME_PET && AnimePetManager.settings.enabled) {
                AnimeFloatingPetOverlay(
                    engine = engine,
                    onOpenSettings = { selectedTab = NavTab.ANIME_PET },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = 28.dp)
                )
            }
        }
    }
}

// Provided for tests and screenshot validation
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier, color = TextPrimary)
}
