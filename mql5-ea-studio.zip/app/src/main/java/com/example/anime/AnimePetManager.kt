package com.example.anime

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

object AnimePetManager {
    private val dispatcher = runCatching { Dispatchers.Main.immediate }.getOrElse { Dispatchers.Default }
    private val scope = CoroutineScope(dispatcher)
    private var speechDismissJob: Job? = null
    private var poseResetJob: Job? = null

    var settings by mutableStateOf(AnimePetSettings())
        private set

    var currentPose by mutableStateOf(AnimeAnimationPose.IDLE)
        private set

    var speechText by mutableStateOf("Konnichiwa! I'm Aoi-chan, your MT5 trading assistant! Tap me for market advice! ✨")
        private set

    var speechCueColor by mutableStateOf(AccentCyan)
        private set

    var isSpeechVisible by mutableStateOf(true)
        private set

    var currentMarketCue by mutableStateOf(MarketSignalCue.RANGE_WAIT)
        private set

    // Floating position offsets (in Dp / Px)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)

    // Interaction counters
    var tapCount by mutableStateOf(0)
        private set

    fun updateSettings(newSettings: AnimePetSettings) {
        settings = newSettings
        if (!newSettings.enabled) {
            isSpeechVisible = false
        }
    }

    fun triggerPose(pose: AnimeAnimationPose, durationMs: Long = 3000L) {
        currentPose = pose
        poseResetJob?.cancel()
        if (pose != AnimeAnimationPose.IDLE) {
            poseResetJob = scope.launch {
                delay(durationMs)
                currentPose = AnimeAnimationPose.IDLE
            }
        }
    }

    fun say(
        text: String,
        color: Color = AccentCyan,
        pose: AnimeAnimationPose? = null,
        durationMs: Long = settings.speechBubbleDurationMs
    ) {
        if (!settings.enabled || !settings.speechBubbleEnabled) return

        speechText = text
        speechCueColor = color
        isSpeechVisible = true

        pose?.let { triggerPose(it) }

        speechDismissJob?.cancel()
        speechDismissJob = scope.launch {
            delay(durationMs)
            isSpeechVisible = false
        }
    }

    fun hideSpeech() {
        isSpeechVisible = false
        speechDismissJob?.cancel()
    }

    fun onPetTapped(engine: TradingEngine) {
        tapCount++
        when (tapCount % 5) {
            0 -> jump()
            1 -> runAnimation()
            2 -> analyzeMarketNow(engine)
            3 -> cheerOnProfit(engine)
            else -> giveRandomGreeting()
        }
    }

    fun jump() {
        triggerPose(AnimeAnimationPose.JUMPING, 1600L)
        say("Hoppu! Let's reach new ATH together, Senpai! 🦘✨", AccentGold)
    }

    fun runAnimation() {
        triggerPose(AnimeAnimationPose.RUNNING, 2200L)
        say("Zoom! Chasing institutional liquidity at lightning speed! 💨", AccentCyan)
    }

    fun cheerOnProfit(engine: TradingEngine) {
        triggerPose(AnimeAnimationPose.CHEERING_BULL, 3500L)
        val profitText = String.format(Locale.US, "$%.2f", engine.floatingProfit)
        if (engine.floatingProfit >= 0) {
            say(
                "Yatta! We're floating +$profitText in profit! XM MT5 bridge is running flawlessly! 💖",
                BullGreen,
                AnimeAnimationPose.CHEERING_BULL
            )
        } else {
            say(
                "Keep calm Senpai! Floating $profitText is just market noise. Our stealth stops will protect us! 🛡️",
                AccentGold,
                AnimeAnimationPose.ALERT_BEAR
            )
        }
    }

    fun giveRandomGreeting() {
        val quotes = listOf(
            "Ready for London & New York session volume! What's our next play? 📊",
            "Remember: Never risk more than 2% per trade! Risk management is true discipline. 🧠",
            "MQL5 Stealth Bridge is online. Your virtual stops are 100% invisible to brokers! 🛡️",
            "I'm keeping an eye on the MT5 tick stream for you 24/7! (｡♥‿♥｡)",
            "Candles are forming clean price action right now! Tap 'Analyze' for my read! 📈"
        )
        say(quotes[Random.nextInt(quotes.size)], AccentCyan, AnimeAnimationPose.IDLE)
    }

    fun analyzeMarketNow(engine: TradingEngine) {
        triggerPose(AnimeAnimationPose.ANALYZING_CHART, 4000L)
        val asset = engine.currentAsset
        val spread = asset.spreadPoints
        val isSpreadHigh = spread > engine.config.maxSpreadPoints

        if (isSpreadHigh) {
            currentMarketCue = MarketSignalCue.SPREAD_SPIKE
            say(
                "CAUTION! ${asset.symbol} spread spiked to $spread pts (max limit ${engine.config.maxSpreadPoints} pts)! Dealing desk stop-hunt risk! 🛡️",
                BearRed,
                AnimeAnimationPose.ALERT_BEAR
            )
            return
        }

        // Analyze price trend from engine candles
        val candles = engine.candles
        if (candles.size >= 5) {
            val last = candles.last()
            val prev = candles[candles.size - 2]
            val isBullish = last.close > last.open && last.close > prev.high * 0.999
            val isBearish = last.close < last.open && last.close < prev.low * 1.001

            if (isBullish) {
                currentMarketCue = MarketSignalCue.STRONG_BUY
                say(
                    "BUY SIGNAL: ${asset.symbol} showing strong bullish impulse! Buyer delta absorbed resistance! 🚀",
                    BullGreen,
                    AnimeAnimationPose.CHEERING_BULL
                )
            } else if (isBearish) {
                currentMarketCue = MarketSignalCue.STRONG_SELL
                say(
                    "SELL SIGNAL: ${asset.symbol} rejected from liquidity pool! Bearish order flow expanding! 📉",
                    BearRed,
                    AnimeAnimationPose.ALERT_BEAR
                )
            } else {
                currentMarketCue = MarketSignalCue.RANGE_WAIT
                say(
                    "CONSOLIDATION: ${asset.symbol} is accumulating volume. Wait for a clean structural break before entering! ☕",
                    AccentGold,
                    AnimeAnimationPose.ANALYZING_CHART
                )
            }
        } else {
            say("Gathering MT5 tick data for ${asset.symbol}... Looking stable! ✨", AccentCyan)
        }
    }

    fun notifyOrderExecuted(isBuy: Boolean, lot: Double, symbol: String) {
        if (!settings.enabled || !settings.autoMarketReactions) return
        val side = if (isBuy) "BUY" else "SELL"
        val color = if (isBuy) BullGreen else BearRed
        val pose = if (isBuy) AnimeAnimationPose.CHEERING_BULL else AnimeAnimationPose.ALERT_BEAR
        say("Sent $side order for $lot lots on $symbol to MT5 broker! Stealth protection engaged! 🚀", color, pose)
    }

    fun notifySpreadSpike(spread: Int, maxSpread: Int) {
        if (!settings.enabled || !settings.autoMarketReactions) return
        say("Spread Warning! Spread expanded to $spread pts (Threshold $maxSpread pts). Orders paused! ⚠️", BearRed, AnimeAnimationPose.ALERT_BEAR)
    }

    fun notifyTakeProfitHit(profit: Double) {
        if (!settings.enabled || !settings.autoMarketReactions) return
        val formatted = String.format(Locale.US, "$%.2f", profit)
        say("TAKE PROFIT HIT!! +$formatted secured in balance! Sugoi ne, Senpai!! 🏆🎉", BullGreen, AnimeAnimationPose.JUMPING, 6000L)
    }
}
