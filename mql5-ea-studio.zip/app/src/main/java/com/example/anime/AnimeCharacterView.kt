package com.example.anime

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun AnimeFloatingPetOverlay(
    engine: TradingEngine,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!AnimePetManager.settings.enabled) return

    val coroutineScope = rememberCoroutineScope()
    var showActionMenu by remember { mutableStateOf(false) }

    // Drag coordinates
    var dragX by remember { mutableFloatStateOf(AnimePetManager.offsetX) }
    var dragY by remember { mutableFloatStateOf(AnimePetManager.offsetY) }

    // Jumping animation state
    val jumpOffset = remember { Animatable(0f) }
    val jumpScaleX = remember { Animatable(1f) }
    val jumpScaleY = remember { Animatable(1f) }

    // Running horizontal bounce
    val runOffset = remember { Animatable(0f) }
    val runTilt = remember { Animatable(0f) }

    // Infinite bobbing/floating transition
    val infiniteTransition = rememberInfiniteTransition(label = "anime_pet_idle")
    val idleFloatY by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idleFloatY"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )
    val auraRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "auraRotation"
    )

    // Trigger physical jumps and runs when pose changes
    LaunchedEffect(AnimePetManager.currentPose) {
        when (AnimePetManager.currentPose) {
            AnimeAnimationPose.JUMPING -> {
                // Squash before leap
                jumpScaleX.animateTo(1.2f, tween(100))
                jumpScaleY.animateTo(0.8f, tween(100))
                // Leap up
                launch {
                    jumpScaleX.animateTo(0.9f, tween(250))
                    jumpScaleY.animateTo(1.15f, tween(250))
                    jumpScaleX.animateTo(1f, tween(250))
                    jumpScaleY.animateTo(1f, tween(250))
                }
                jumpOffset.animateTo(-70f, tween(300, easing = FastOutSlowInEasing))
                // Land with bouncy impact
                jumpOffset.animateTo(0f, tween(350, easing = FastOutSlowInEasing))
                jumpScaleX.animateTo(1.15f, tween(120))
                jumpScaleY.animateTo(0.85f, tween(120))
                jumpScaleX.animateTo(1f, tween(180))
                jumpScaleY.animateTo(1f, tween(180))
            }
            AnimeAnimationPose.RUNNING -> {
                runTilt.animateTo(14f, tween(150))
                repeat(4) {
                    runOffset.animateTo(25f, tween(200, easing = FastOutSlowInEasing))
                    runOffset.animateTo(-25f, tween(200, easing = FastOutSlowInEasing))
                }
                runOffset.animateTo(0f, tween(150))
                runTilt.animateTo(0f, tween(150))
            }
            else -> {
                jumpOffset.snapTo(0f)
                runOffset.snapTo(0f)
                runTilt.snapTo(0f)
            }
        }
    }

    Box(
        modifier = modifier
            .wrapContentSize()
            .offset { IntOffset(dragX.roundToInt(), dragY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { showActionMenu = false },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragX += dragAmount.x
                        dragY += dragAmount.y
                        AnimePetManager.offsetX = dragX
                        AnimePetManager.offsetY = dragY
                    }
                )
            }
            .alpha(AnimePetManager.settings.transparency)
            .scale(AnimePetManager.settings.scale)
            .testTag("anime_floating_pet_root")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // 1. Interactive Holographic Manga Speech Bubble
            AnimatedVisibility(
                visible = AnimePetManager.isSpeechVisible && AnimePetManager.settings.speechBubbleEnabled,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                MangaSpeechBubble(
                    text = AnimePetManager.speechText,
                    cueColor = AnimePetManager.speechCueColor,
                    characterName = AnimePetManager.settings.characterName,
                    onDismiss = { AnimePetManager.hideSpeech() },
                    onAdviceClick = { AnimePetManager.analyzeMarketNow(engine) }
                )
            }

            // 2. Interactive Action Menu (shown when tapped)
            AnimatedVisibility(
                visible = showActionMenu,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                PetMiniActionDock(
                    engine = engine,
                    onClose = { showActionMenu = false },
                    onOpenSettings = onOpenSettings
                )
            }

            // 3. Cute Animated Anime Character Avatar with dynamic Canvas effects
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .offset(y = (idleFloatY + jumpOffset.value).dp, x = runOffset.value.dp)
                    .rotate(runTilt.value)
                    .scale(scaleX = jumpScaleX.value, scaleY = jumpScaleY.value)
                    .clickable {
                        showActionMenu = !showActionMenu
                        AnimePetManager.onPetTapped(engine)
                    }
                    .testTag("anime_character_avatar"),
                contentAlignment = Alignment.Center
            ) {
                // Glowing Cyber Aura
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 2f
                    val auraColor = when (AnimePetManager.currentPose) {
                        AnimeAnimationPose.CHEERING_BULL -> BullGreen
                        AnimeAnimationPose.ALERT_BEAR -> BearRed
                        AnimeAnimationPose.ANALYZING_CHART -> AccentGold
                        AnimeAnimationPose.JUMPING -> AccentGold
                        AnimeAnimationPose.RUNNING -> AccentCyan
                        else -> AccentCyan
                    }

                    // Soft outer glow pulse
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                auraColor.copy(alpha = 0.35f * glowPulse),
                                auraColor.copy(alpha = 0.1f * glowPulse),
                                Color.Transparent
                            ),
                            center = center,
                            radius = radius * 1.15f
                        )
                    )

                    // Cyber ring orbit
                    drawCircle(
                        color = auraColor.copy(alpha = 0.45f),
                        radius = radius * 0.95f,
                        style = Stroke(width = 2.5f)
                    )
                }

                // Anime Mascot Image (Aoi-chan)
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .border(
                            2.dp,
                            when (AnimePetManager.currentPose) {
                                AnimeAnimationPose.CHEERING_BULL -> BullGreen
                                AnimeAnimationPose.ALERT_BEAR -> BearRed
                                AnimeAnimationPose.ANALYZING_CHART -> AccentGold
                                else -> AccentCyan
                            },
                            CircleShape
                        )
                        .background(SurfaceDark)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_anime_assistant),
                        contentDescription = "Aoi-chan Virtual Trading Assistant",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Dynamic Pose Emotion Badges
                    when (AnimePetManager.currentPose) {
                        AnimeAnimationPose.CHEERING_BULL -> {
                            Text(
                                text = "✨+$$$",
                                color = BullGreen,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .background(BgDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        AnimeAnimationPose.ALERT_BEAR -> {
                            Text(
                                text = "⚠️ RISK",
                                color = BearRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .background(BgDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        AnimeAnimationPose.ANALYZING_CHART -> {
                            Text(
                                text = "📊 MT5",
                                color = AccentGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .background(BgDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        AnimeAnimationPose.RUNNING -> {
                            Text(
                                text = "💨 DASH",
                                color = AccentCyan,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .background(BgDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        AnimeAnimationPose.JUMPING -> {
                            Text(
                                text = "🦘 HOP!",
                                color = AccentGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.sp,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .background(BgDark.copy(alpha = 0.85f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                        else -> Unit
                    }
                }

                // Live Market Cue Dot
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = (-4).dp, y = (-4).dp)
                        .background(
                            when (AnimePetManager.currentMarketCue) {
                                MarketSignalCue.STRONG_BUY -> BullGreen
                                MarketSignalCue.STRONG_SELL -> BearRed
                                MarketSignalCue.SPREAD_SPIKE -> BearRed
                                MarketSignalCue.RANGE_WAIT -> AccentGold
                                MarketSignalCue.PROFIT_CELEBRATION -> BullGreen
                            },
                            CircleShape
                        )
                        .border(2.dp, SurfaceDark, CircleShape)
                )
            }

            // Cute Character Name Tag
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = BgDark.copy(alpha = 0.88f),
                border = SurfaceBorder.let { androidx.compose.foundation.BorderStroke(1.dp, it) }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(BullGreen, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = AnimePetManager.settings.characterName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun MangaSpeechBubble(
    text: String,
    cueColor: Color,
    characterName: String,
    onDismiss: () -> Unit,
    onAdviceClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard.copy(alpha = 0.95f)),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, cueColor.copy(alpha = 0.8f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
            .widthIn(max = 240.dp)
            .padding(bottom = 6.dp)
            .testTag("manga_speech_bubble")
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(cueColor, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = characterName,
                        fontWeight = FontWeight.Black,
                        fontSize = 11.sp,
                        color = cueColor
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onAdviceClick,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Re-analyze Market",
                            tint = AccentCyan,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss speech bubble",
                            tint = TextMuted,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Text(
                text = text,
                fontSize = 11.5.sp,
                lineHeight = 15.sp,
                color = TextPrimary,
                fontWeight = FontWeight.Medium
            )

            // Speech bubble tail pointer
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            ) {
                val trianglePath = Path().apply {
                    moveTo(size.width / 2f - 8f, 0f)
                    lineTo(size.width / 2f + 8f, 0f)
                    lineTo(size.width / 2f, size.height)
                    close()
                }
                drawPath(path = trianglePath, color = cueColor.copy(alpha = 0.8f))
            }
        }
    }
}

@Composable
fun PetMiniActionDock(
    engine: TradingEngine,
    onClose: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark.copy(alpha = 0.95f)),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier
            .widthIn(max = 250.dp)
            .padding(bottom = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AccentCyan.copy(alpha = 0.2f),
                modifier = Modifier.clickable {
                    AnimePetManager.analyzeMarketNow(engine)
                    onClose()
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Psychology, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Advice", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AccentGold.copy(alpha = 0.2f),
                modifier = Modifier.clickable {
                    AnimePetManager.jump()
                    onClose()
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🦘 Jump", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentGold)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = BullGreen.copy(alpha = 0.2f),
                modifier = Modifier.clickable {
                    AnimePetManager.cheerOnProfit(engine)
                    onClose()
                }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = BullGreen, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Cheer", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BullGreen)
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = TextMuted.copy(alpha = 0.2f),
                modifier = Modifier.clickable {
                    onClose()
                    onOpenSettings()
                }
            ) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "Anime Assistant Settings",
                    tint = TextSecondary,
                    modifier = Modifier
                        .padding(4.dp)
                        .size(14.dp)
                )
            }
        }
    }
}
