package com.example.anime

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen

enum class AnimeAnimationPose(val label: String, val iconText: String) {
    IDLE("Idle Floating", "✨"),
    RUNNING("Dashing Run", "💨"),
    JUMPING("Joyful Jump", "🦘"),
    CHEERING_BULL("Bullish Cheer", "🎉"),
    ALERT_BEAR("Caution / Bear Alert", "⚠️"),
    ANALYZING_CHART("Chart Analysis", "📊")
}

enum class AssistantBehaviorMode(val title: String, val description: String) {
    SMART_ADVISOR(
        "Smart Market Advisor",
        "Active commentary on MT5 technical trends, liquidity sweeps, and live trade signals."
    ),
    PLAYFUL_PET(
        "Playful Mascot",
        "Expressive reactions, frequent jumps, cheers on profit, and uplifting companion remarks."
    ),
    SILENT_GUARDIAN(
        "Silent Risk Guardian",
        "Stays discreetly quiet, popping up only for critical spread spikes, news events, and drawdown warnings."
    )
}

enum class MarketSignalCue(
    val title: String,
    val cueText: String,
    val color: Color
) {
    STRONG_BUY(
        "BULLISH MOMENTUM",
        "Senpai! Buyers are dominating this candle! Looks like a great long setup! 🚀",
        BullGreen
    ),
    STRONG_SELL(
        "BEARISH REJECTION",
        "Watch out! Strong selling volume detected at resistance! Consider shorting! 📉",
        BearRed
    ),
    RANGE_WAIT(
        "MARKET CONSOLIDATION",
        "Price is ranging inside a liquidity zone. Patience is key, let's wait for a breakout! ☕",
        AccentGold
    ),
    SPREAD_SPIKE(
        "SPREAD WARNING",
        "Spread widened past safety limits! Broker dealing desk might be stop-hunting! 🛡️",
        BearRed
    ),
    PROFIT_CELEBRATION(
        "WINNING TRADE",
        "Sugoi!! XM MT5 is printing profit! Ready to lock it in or trail the stop? 💖",
        BullGreen
    )
}

data class AnimePetSettings(
    val enabled: Boolean = true,
    val systemOverlayEnabled: Boolean = false,
    val behaviorMode: AssistantBehaviorMode = AssistantBehaviorMode.SMART_ADVISOR,
    val scale: Float = 1.0f,
    val transparency: Float = 0.95f,
    val speechBubbleEnabled: Boolean = true,
    val speechBubbleDurationMs: Long = 4500L,
    val characterName: String = "Aoi-chan (碧)",
    val soundReaction: Boolean = true,
    val autoMarketReactions: Boolean = true
)
