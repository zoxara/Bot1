package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.trading.OrderSideFilter
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkTradeManagementPanel(
    engine: TradingEngine,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(OrderSideFilter.ALL) }
    var beOffsetPoints by remember { mutableIntStateOf(0) }
    var showTpSlStation by remember { mutableStateOf(true) }

    // Bulk TP/SL Config state
    var isPointsMode by remember { mutableStateOf(true) }
    var bulkSlPointsText by remember { mutableStateOf("50") }
    var bulkTpPointsText by remember { mutableStateOf("100") }
    var bulkSlPriceText by remember { mutableStateOf("") }
    var bulkTpPriceText by remember { mutableStateOf("") }

    // Filtered positions count and metrics
    val matchingPositions = engine.openPositions.filter { pos ->
        when (selectedFilter) {
            OrderSideFilter.ALL -> true
            OrderSideFilter.BUY_ONLY -> pos.isBuy
            OrderSideFilter.SELL_ONLY -> !pos.isBuy
        }
    }

    val totalMatchingCount = matchingPositions.size
    val profitCount = matchingPositions.count { it.currentProfit > 0.0 }
    val lossCount = matchingPositions.count { it.currentProfit < 0.0 }
    val totalProfitAmount = matchingPositions.filter { it.currentProfit > 0.0 }.sumOf { it.currentProfit }
    val totalLossAmount = matchingPositions.filter { it.currentProfit < 0.0 }.sumOf { it.currentProfit }
    val netMatchingPnL = matchingPositions.sumOf { it.currentProfit }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                colors = listOf(AccentCyan.copy(alpha = 0.6f), SurfaceBorder, AccentGold.copy(alpha = 0.4f))
            )
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(AccentCyan.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "BULK TRADE MANAGEMENT",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "One-Click Execution Engine • Zero Latency MT5 Bridge",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (engine.bridgeConnected) BullGreen.copy(alpha = 0.15f) else BearRed.copy(alpha = 0.15f),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(if (engine.bridgeConnected) BullGreen else BearRed)
                    )
                ) {
                    Text(
                        text = if (engine.bridgeConnected) "${engine.bridgeLatencyMs}ms MT5" else "OFFLINE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (engine.bridgeConnected) BullGreen else BearRed,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Target Scope Filter Tabs: ALL / BUYS ONLY / SELLS ONLY
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OrderSideFilter.values().forEach { filter ->
                    val isSelected = selectedFilter == filter
                    val count = when (filter) {
                        OrderSideFilter.ALL -> engine.openPositions.size
                        OrderSideFilter.BUY_ONLY -> engine.openPositions.count { it.isBuy }
                        OrderSideFilter.SELL_ONLY -> engine.openPositions.count { !it.isBuy }
                    }
                    val sideColor = when (filter) {
                        OrderSideFilter.ALL -> AccentCyan
                        OrderSideFilter.BUY_ONLY -> BullGreen
                        OrderSideFilter.SELL_ONLY -> BearRed
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) sideColor.copy(alpha = 0.2f) else SurfaceCard,
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) sideColor else SurfaceBorder)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedFilter = filter }
                            .testTag("filter_${filter.name}")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = filter.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) sideColor else TextSecondary
                            )
                            Text(
                                text = "$count Active",
                                fontSize = 9.sp,
                                color = if (isSelected) sideColor.copy(alpha = 0.8f) else TextMuted
                            )
                        }
                    }
                }
            }

            // Quick Stats summary of selected trades
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0F172A),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF1E293B))
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Filtered Target: ${selectedFilter.label} ($totalMatchingCount pos)",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "Net P/L: ${String.format(Locale.US, "%s$%.2f", if (netMatchingPnL >= 0) "+" else "", netMatchingPnL)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (netMatchingPnL >= 0) BullGreen else BearRed
                    )
                }
            }

            // 1. ONE-CLICK QUICK ACTION BUTTONS (Breakeven, Close Profit, Close Loss, Close ALL)
            Text(
                text = "ONE-CLICK POSITION CONTROLS",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = AccentGold,
                letterSpacing = 0.5.sp
            )

            // Button 1: BREAKEVEN
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { engine.executeBreakeven(selectedFilter, beOffsetPoints) },
                            enabled = totalMatchingCount > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0891B2),
                                disabledContainerColor = Color(0xFF1E293B)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1.3f)
                                .height(40.dp)
                                .testTag("btn_oneclick_breakeven")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "BREAKEVEN",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Offset buffer picker
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = "Buffer:", fontSize = 10.sp, color = TextMuted)
                            listOf(0, 5, 10).forEach { pts ->
                                val active = beOffsetPoints == pts
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (active) AccentCyan.copy(alpha = 0.25f) else SurfaceDark,
                                    border = CardDefaults.outlinedCardBorder().copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(if (active) AccentCyan else SurfaceBorder)
                                    ),
                                    modifier = Modifier.clickable { beOffsetPoints = pts }
                                ) {
                                    Text(
                                        text = "+${pts}p",
                                        fontSize = 10.sp,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                        color = if (active) AccentCyan else TextSecondary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = "Instantly moves Stop Loss to entry price (${if (beOffsetPoints > 0) "+${beOffsetPoints}pts commission buffer" else "zero risk"}) for $totalMatchingCount ${selectedFilter.label.lowercase()}.",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }

            // Two-Column Grid for Close Profit and Close Loss
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Button 2: CLOSE PROFIT
                Button(
                    onClick = { engine.closeProfitablePositions(selectedFilter) },
                    enabled = profitCount > 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF059669),
                        disabledContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_oneclick_close_profit")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "CLOSE PROFIT",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = if (profitCount > 0) Color.White else TextMuted
                        )
                        Text(
                            text = if (profitCount > 0) "+$${String.format(Locale.US, "%.2f", totalProfitAmount)} ($profitCount)" else "None in profit",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (profitCount > 0) Color(0xFFD1FAE5) else TextMuted
                        )
                    }
                }

                // Button 3: CLOSE LOSS
                Button(
                    onClick = { engine.closeLosingPositions(selectedFilter) },
                    enabled = lossCount > 0,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDC2626),
                        disabledContainerColor = Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_oneclick_close_loss")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "CLOSE LOSS",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = if (lossCount > 0) Color.White else TextMuted
                        )
                        Text(
                            text = if (lossCount > 0) "-$${String.format(Locale.US, "%.2f", kotlin.math.abs(totalLossAmount))} ($lossCount)" else "None in loss",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (lossCount > 0) Color(0xFFFEE2E2) else TextMuted
                        )
                    }
                }
            }

            // Button 4: CLOSE ALL (Emergency Kill Switch)
            Button(
                onClick = { engine.closeAllPositionsWithFilter(selectedFilter) },
                enabled = totalMatchingCount > 0,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD97706),
                    disabledContainerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("btn_oneclick_close_all")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CLOSE ALL POSITIONS (${selectedFilter.label.uppercase()})",
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        color = if (totalMatchingCount > 0) Color.Black else TextMuted
                    )
                }
            }

            // 2. BULK TP / SL CONTROL STATION (Collapsible / Advanced Panel)
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Station Header Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTpSlStation = !showTpSlStation },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = AccentCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BULK TP / SL CONTROL PANEL",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }

                        Icon(
                            imageVector = if (showTpSlStation) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    AnimatedVisibility(visible = showTpSlStation) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Mode Switch: Points vs Absolute Price
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isPointsMode) AccentCyan.copy(alpha = 0.2f) else SurfaceDark,
                                    border = CardDefaults.outlinedCardBorder().copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(if (isPointsMode) AccentCyan else SurfaceBorder)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { isPointsMode = true }
                                ) {
                                    Text(
                                        text = "Distance in Points / Pips",
                                        fontSize = 11.sp,
                                        fontWeight = if (isPointsMode) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isPointsMode) AccentCyan else TextSecondary,
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (!isPointsMode) AccentCyan.copy(alpha = 0.2f) else SurfaceDark,
                                    border = CardDefaults.outlinedCardBorder().copy(
                                        brush = androidx.compose.ui.graphics.SolidColor(if (!isPointsMode) AccentCyan else SurfaceBorder)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            isPointsMode = false
                                            if (bulkSlPriceText.isEmpty()) {
                                                bulkSlPriceText = String.format(Locale.US, "%.${engine.currentAsset.digits}f", engine.currentBid - 50 * engine.currentAsset.point)
                                            }
                                            if (bulkTpPriceText.isEmpty()) {
                                                bulkTpPriceText = String.format(Locale.US, "%.${engine.currentAsset.digits}f", engine.currentAsk + 100 * engine.currentAsset.point)
                                            }
                                        }
                                ) {
                                    Text(
                                        text = "Exact Price Level",
                                        fontSize = 11.sp,
                                        fontWeight = if (!isPointsMode) FontWeight.Bold else FontWeight.Normal,
                                        color = if (!isPointsMode) AccentCyan else TextSecondary,
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }

                            if (isPointsMode) {
                                // Relative Points Mode Controls
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // Stop Loss Points Input
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = "Stop Loss (Points)", fontSize = 10.sp, color = BearRed, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(
                                            value = bulkSlPointsText,
                                            onValueChange = { bulkSlPointsText = it.filter { c -> c.isDigit() } },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = BearRed,
                                                unfocusedBorderColor = SurfaceBorder,
                                                focusedTextColor = TextPrimary,
                                                unfocusedTextColor = TextPrimary
                                            ),
                                            trailingIcon = {
                                                Text("pts", fontSize = 10.sp, color = TextMuted, modifier = Modifier.padding(end = 6.dp))
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_bulk_sl_pts")
                                        )

                                        // Quick Presets
                                        Row(
                                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            listOf(25, 50, 100, 200).forEach { p ->
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = SurfaceDark,
                                                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                                                    modifier = Modifier.clickable { bulkSlPointsText = p.toString() }
                                                ) {
                                                    Text(text = "${p}p", fontSize = 9.sp, color = TextSecondary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                                }
                                            }
                                        }
                                    }

                                    // Take Profit Points Input
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = "Take Profit (Points)", fontSize = 10.sp, color = BullGreen, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(
                                            value = bulkTpPointsText,
                                            onValueChange = { bulkTpPointsText = it.filter { c -> c.isDigit() } },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = BullGreen,
                                                unfocusedBorderColor = SurfaceBorder,
                                                focusedTextColor = TextPrimary,
                                                unfocusedTextColor = TextPrimary
                                            ),
                                            trailingIcon = {
                                                Text("pts", fontSize = 10.sp, color = TextMuted, modifier = Modifier.padding(end = 6.dp))
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_bulk_tp_pts")
                                        )

                                        // Quick Presets
                                        Row(
                                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            listOf(50, 100, 200, 400).forEach { p ->
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = SurfaceDark,
                                                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                                                    modifier = Modifier.clickable { bulkTpPointsText = p.toString() }
                                                ) {
                                                    Text(text = "${p}p", fontSize = 9.sp, color = TextSecondary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                // Absolute Price Mode Controls
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = "Target SL Price", fontSize = 10.sp, color = BearRed, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(
                                            value = bulkSlPriceText,
                                            onValueChange = { bulkSlPriceText = it },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = BearRed,
                                                unfocusedBorderColor = SurfaceBorder,
                                                focusedTextColor = TextPrimary,
                                                unfocusedTextColor = TextPrimary
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_bulk_sl_price")
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(text = "Target TP Price", fontSize = 10.sp, color = BullGreen, fontWeight = FontWeight.Bold)
                                        OutlinedTextField(
                                            value = bulkTpPriceText,
                                            onValueChange = { bulkTpPriceText = it },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = BullGreen,
                                                unfocusedBorderColor = SurfaceBorder,
                                                focusedTextColor = TextPrimary,
                                                unfocusedTextColor = TextPrimary
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("input_bulk_tp_price")
                                        )
                                    }
                                }
                            }

                            // Action Buttons for Bulk Modifying TP / SL
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (isPointsMode) {
                                            val slPts = bulkSlPointsText.toIntOrNull() ?: 0
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                isRelativePoints = true,
                                                slPoints = slPts,
                                                tpPoints = 0
                                            )
                                        } else {
                                            val slPrice = bulkSlPriceText.toDoubleOrNull()
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                targetSl = slPrice,
                                                targetTp = null
                                            )
                                        }
                                    },
                                    enabled = totalMatchingCount > 0,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BearRed.copy(alpha = 0.85f),
                                        disabledContainerColor = Color(0xFF1E293B)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .testTag("btn_apply_bulk_sl")
                                ) {
                                    Text("Set SL Only", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        if (isPointsMode) {
                                            val tpPts = bulkTpPointsText.toIntOrNull() ?: 0
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                isRelativePoints = true,
                                                slPoints = 0,
                                                tpPoints = tpPts
                                            )
                                        } else {
                                            val tpPrice = bulkTpPriceText.toDoubleOrNull()
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                targetSl = null,
                                                targetTp = tpPrice
                                            )
                                        }
                                    },
                                    enabled = totalMatchingCount > 0,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = BullGreen.copy(alpha = 0.85f),
                                        disabledContainerColor = Color(0xFF1E293B)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .testTag("btn_apply_bulk_tp")
                                ) {
                                    Text("Set TP Only", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                Button(
                                    onClick = {
                                        if (isPointsMode) {
                                            val slPts = bulkSlPointsText.toIntOrNull() ?: 0
                                            val tpPts = bulkTpPointsText.toIntOrNull() ?: 0
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                isRelativePoints = true,
                                                slPoints = slPts,
                                                tpPoints = tpPts
                                            )
                                        } else {
                                            val slPrice = bulkSlPriceText.toDoubleOrNull()
                                            val tpPrice = bulkTpPriceText.toDoubleOrNull()
                                            engine.bulkModifyStops(
                                                filter = selectedFilter,
                                                targetSl = slPrice,
                                                targetTp = tpPrice
                                            )
                                        }
                                    },
                                    enabled = totalMatchingCount > 0,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AccentCyan,
                                        disabledContainerColor = Color(0xFF1E293B)
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1.2f)
                                        .height(36.dp)
                                        .testTag("btn_apply_bulk_both")
                                ) {
                                    Text("Apply Both", fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
