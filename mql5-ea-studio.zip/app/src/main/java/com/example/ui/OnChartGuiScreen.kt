package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.trading.OrderType
import com.example.trading.PendingOrder
import com.example.trading.SimulatedPosition
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun OnChartGuiScreen(
    engine: TradingEngine,
    modifier: Modifier = Modifier
) {
    var showPendingDialog by remember { mutableStateOf(false) }
    var modifyingPosition by remember { mutableStateOf<SimulatedPosition?>(null) }
    var showJournalDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Asset Selector & Bridge Status Bar
        item {
            Spacer(modifier = Modifier.height(2.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                engine.supportedAssets.forEach { asset ->
                    val isSelected = engine.currentAsset.symbol == asset.symbol
                    FilterChip(
                        selected = isSelected,
                        onClick = { engine.selectAsset(asset) },
                        label = {
                            Text(
                                text = asset.symbol,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AccentCyan.copy(alpha = 0.2f),
                            selectedLabelColor = AccentCyan,
                            containerColor = SurfaceCard,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) AccentCyan else SurfaceBorder
                        ),
                        modifier = Modifier.testTag("chip_${asset.symbol}")
                    )
                }

                // Bridge Latency Ping Button
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = BullGreen.copy(alpha = 0.12f),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BullGreen.copy(alpha = 0.4f))),
                    modifier = Modifier
                        .clickable { engine.pingBridge() }
                        .testTag("btn_bridge_ping")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(modifier = Modifier.size(6.dp).background(BullGreen, CircleShape))
                        Text(
                            text = "MT5 Bridge: ${engine.bridgeLatencyMs}ms",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BullGreen
                        )
                    }
                }

                IconButton(
                    onClick = { engine.resetAccount() },
                    modifier = Modifier.testTag("btn_reset_sim")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Simulation",
                        tint = TextSecondary
                    )
                }
            }
        }

        // 2. Market Live Quote Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = engine.currentAsset.symbol,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (engine.marketTrend == "BULLISH") BullGreen.copy(alpha = 0.15f)
                                else if (engine.marketTrend == "BEARISH") BearRed.copy(alpha = 0.15f)
                                else Color.Gray.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = engine.marketTrend,
                                    color = if (engine.marketTrend == "BULLISH") BullGreen
                                    else if (engine.marketTrend == "BEARISH") BearRed
                                    else Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = engine.currentAsset.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        val formatStr = "%.${engine.currentAsset.digits}f"
                        Text(
                            text = String.format(Locale.US, formatStr, engine.currentPrice),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = if (engine.marketTrend == "BULLISH") BullGreen else BearRed
                        )
                        Text(
                            text = "Bid: ${String.format(Locale.US, formatStr, engine.currentBid)} | Ask: ${String.format(Locale.US, formatStr, engine.currentAsk)}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // 3. Real-Time Win Probability & VSA Confluence Radar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(AccentCyan.copy(alpha = 0.35f))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = AccentCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "QUANT WIN PROBABILITY RADAR",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = AccentCyan,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BullGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${engine.winProbability}% HIGH WIN RATE",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = BullGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { engine.winProbability / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = if (engine.winProbability >= 75) BullGreen else AccentGold,
                        trackColor = Color(0xFF1E293B)
                    )

                    // Confluence Pillars Breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        ConfluencePillar("Trend EMA", engine.marketTrend, if (engine.marketTrend == "BULLISH") BullGreen else BearRed)
                        ConfluencePillar("RSI Momentum", if (engine.marketTrend == "BULLISH") "58 [Bull]" else "42 [Bear]", AccentCyan)
                        ConfluencePillar("ATR Volatility", "Optimal Exp.", Color(0xFF38BDF8))
                        ConfluencePillar("VSA Volume", "${engine.vsaVolumeRatio}x Spike", AccentGold)
                    }

                    // VSA Smart Money Status Banner
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF132032),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF23354E)))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VSA Institutional Signal:",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = engine.vsaStatus,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentGold
                            )
                        }
                    }
                }
            }
        }

        // 4. Hidden / Stealth Stop Loss Protection Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E2E)),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF1E3A5A))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = BullGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "STEALTH STOPS: ACTIVE (BROKER BLIND)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = BullGreen
                        )
                        Text(
                            text = "Stops are kept client-side. Zero SL/TP sent to broker order books to prevent stop-hunting.",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // 5. Authentic MT5 On-Chart GUI Dashboard Canvas
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MT5 ON-CHART GUI DASHBOARD (CHART VIEW)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    Text(
                        text = "Real-time Chart Objects",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(440.dp)
                        .background(Color(0xFF0D131F), RoundedCornerShape(12.dp))
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                ) {
                    // Candlestick Background Canvas
                    CandlestickCanvas(
                        candles = engine.candles,
                        modifier = Modifier.fillMaxSize()
                    )

                    // The On-Chart Dashboard Control Window
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xF2101726)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF2E3D52))
                        ),
                        modifier = Modifier
                            .padding(10.dp)
                            .width(290.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            // Title Bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(8.dp).background(BullGreen, CircleShape))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "⚡ QUANT ALGO PRO v3",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = AccentCyan
                                    )
                                }
                                Text(
                                    text = engine.currentAsset.symbol,
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF263345)))

                            // Metrics
                            DashboardMetricRow(label = "Balance", value = String.format(Locale.US, "$%.2f", engine.accountBalance))
                            DashboardMetricRow(label = "Equity", value = String.format(Locale.US, "$%.2f", engine.accountEquity))

                            val pnlColor by animateColorAsState(
                                targetValue = if (engine.floatingProfit >= 0) BullGreen else BearRed,
                                label = "pnlColor"
                            )
                            val pnlSign = if (engine.floatingProfit >= 0) "+" else ""
                            DashboardMetricRow(
                                label = "Floating P/L",
                                value = String.format(Locale.US, "%s$%.2f", pnlSign, engine.floatingProfit),
                                valueColor = pnlColor,
                                isBold = true
                            )

                            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF263345)))

                            // Win Prob & VSA
                            DashboardMetricRow(
                                label = "Win Probability",
                                value = "${engine.winProbability}% ${if (engine.marketTrend == "BULLISH") "BUY" else "SELL"}",
                                valueColor = if (engine.marketTrend == "BULLISH") BullGreen else BearRed,
                                isBold = true
                            )
                            DashboardMetricRow(label = "VSA Volume", value = engine.vsaStatus, valueColor = AccentGold)

                            // Quick Lot size on chart
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Active Lot:", fontSize = 11.sp, color = TextSecondary)
                                Text(
                                    text = "${engine.activeLotSize} Lots",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentCyan
                                )
                            }

                            // Interactive Chart Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { engine.executeMarketBuy() },
                                    colors = ButtonDefaults.buttonColors(containerColor = BullGreen),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("btn_chart_buy")
                                ) {
                                    Text("BUY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                }

                                Button(
                                    onClick = { engine.executeMarketSell() },
                                    colors = ButtonDefaults.buttonColors(containerColor = BearRed),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("btn_chart_sell")
                                ) {
                                    Text("SELL", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { engine.executeBreakeven() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0891B2)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(28.dp)
                                        .testTag("btn_chart_breakeven")
                                ) {
                                    Text("BREAKEVEN", fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color.White)
                                }

                                Button(
                                    onClick = { engine.closeAllPositions(onlyProfitable = false) },
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentGold),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(28.dp)
                                        .testTag("btn_chart_close_all")
                                ) {
                                    Text("CLOSE ALL", fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color.Black)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = { engine.closeProfitablePositions() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(28.dp)
                                        .testTag("btn_chart_close_profit")
                                ) {
                                    Text("CLOSE PROFIT", fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color.White)
                                }

                                Button(
                                    onClick = { engine.closeLosingPositions() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(28.dp)
                                        .testTag("btn_chart_close_loss")
                                ) {
                                    Text("CLOSE LOSS", fontWeight = FontWeight.Bold, fontSize = 9.sp, color = Color.White)
                                }
                            }

                            // Auto-Trade Toggle
                            Button(
                                onClick = { engine.toggleAutoTrade() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (engine.autoTradeActive) Color(0xFF132F3D) else Color(0xFF1E293B)
                                ),
                                shape = RoundedCornerShape(6.dp),
                                border = ButtonDefaults.outlinedButtonBorder().copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(if (engine.autoTradeActive) AccentCyan else Color.Gray)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(30.dp)
                                    .testTag("btn_chart_auto_toggle")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = if (engine.autoTradeActive) AccentCyan else TextMuted,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (engine.autoTradeActive) "AUTO-TRADE: ON" else "AUTO-TRADE: OFF",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = if (engine.autoTradeActive) AccentCyan else TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Quick Lot Selector & Advanced Order Entry Panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ORDER EXECUTION DOCK",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        TextButton(
                            onClick = { showPendingDialog = true },
                            modifier = Modifier.testTag("btn_open_pending_modal")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ PENDING ORDER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Quick Lot Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Lot:", fontSize = 11.sp, color = TextSecondary)
                        listOf(0.01, 0.05, 0.10, 0.50, 1.00).forEach { lot ->
                            val isSelected = engine.activeLotSize == lot
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) AccentCyan.copy(alpha = 0.2f) else SurfaceCard,
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) AccentCyan else SurfaceBorder)
                                ),
                                modifier = Modifier
                                    .clickable { engine.activeLotSize = lot }
                                    .testTag("chip_lot_$lot")
                            ) {
                                Text(
                                    text = String.format(Locale.US, "%.2f", lot),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) AccentCyan else TextSecondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Execution Buttons with Lot Size
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { engine.executeMarketBuy() },
                            colors = ButtonDefaults.buttonColors(containerColor = BullGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_dock_buy")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("MARKET BUY", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color.White)
                                Text("${engine.activeLotSize} lots @ ${String.format(Locale.US, "%.${engine.currentAsset.digits}f", engine.currentAsk)}", fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }

                        Button(
                            onClick = { engine.executeMarketSell() },
                            colors = ButtonDefaults.buttonColors(containerColor = BearRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_dock_sell")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("MARKET SELL", fontWeight = FontWeight.Black, fontSize = 12.sp, color = Color.White)
                                Text("${engine.activeLotSize} lots @ ${String.format(Locale.US, "%.${engine.currentAsset.digits}f", engine.currentBid)}", fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f))
                            }
                        }
                    }
                }
            }
        }

        // Bulk Trade Management & One-Click Control Panel
        item {
            BulkTradeManagementPanel(engine = engine)
        }

        // 7. Active Positions Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE OPEN POSITIONS (${engine.openPositions.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )

                TextButton(onClick = { showJournalDialog = true }) {
                    Icon(imageVector = Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trade Journal", fontSize = 11.sp)
                }
            }
        }

        if (engine.openPositions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No open trades. Click BUY or SELL above to open an order.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }
            }
        } else {
            items(engine.openPositions, key = { it.ticket }) { pos ->
                UpgradedPositionItemCard(
                    pos = pos,
                    engine = engine,
                    onModify = { modifyingPosition = pos }
                )
            }
        }

        // 8. Pending Orders Section
        if (engine.pendingOrders.isNotEmpty()) {
            item {
                Text(
                    text = "PENDING ORDERS (${engine.pendingOrders.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = AccentGold
                )
            }

            items(engine.pendingOrders, key = { it.ticket }) { pending ->
                PendingOrderItemCard(pending = pending, onCancel = { engine.cancelPendingOrder(pending.ticket) }, digits = engine.currentAsset.digits)
            }
        }

        // 9. Risk & Drawdown Circuit Breaker Card
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (engine.dailyLimitHit) BearRed.copy(alpha = 0.1f) else SurfaceCard
                ),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (engine.dailyLimitHit) BearRed else SurfaceBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = if (engine.dailyLimitHit) BearRed else BullGreen,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (engine.dailyLimitHit) "CIRCUIT BREAKER TRIGGERED" else "Daily Risk Guard: ACTIVE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (engine.dailyLimitHit) BearRed else TextPrimary
                        )
                        Text(
                            text = if (engine.dailyLimitHit) "Max daily loss hit (${engine.config.maxDailyDrawdownPercent}%). Auto-trading halted."
                            else "Max Daily Drawdown: ${engine.config.maxDailyDrawdownPercent}% | Anti-Slippage: ${engine.config.maxSlippagePoints} pts | Trailing: ${engine.config.trailingStopPoints} pts",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Modal Dialog: Place Pending Order
    if (showPendingDialog) {
        PendingOrderModalDialog(
            engine = engine,
            onDismiss = { showPendingDialog = false }
        )
    }

    // Modal Dialog: Modify Position Stops
    modifyingPosition?.let { pos ->
        ModifyPositionModalDialog(
            pos = pos,
            digits = engine.currentAsset.digits,
            onDismiss = { modifyingPosition = null },
            onSave = { newSl, newTp ->
                engine.modifyPositionStops(pos.ticket, newSl, newTp)
                modifyingPosition = null
            }
        )
    }

    // Modal Dialog: Trade Journal
    if (showJournalDialog) {
        TradeJournalModalDialog(
            engine = engine,
            onDismiss = { showJournalDialog = false }
        )
    }
}

@Composable
fun ConfluencePillar(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 10.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun UpgradedPositionItemCard(
    pos: SimulatedPosition,
    engine: TradingEngine,
    onModify: () -> Unit
) {
    val digits = engine.currentAsset.digits
    val formatStr = "%.${digits}f"

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (pos.currentProfit >= 0) BullGreen.copy(alpha = 0.3f) else BearRed.copy(alpha = 0.3f))
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_pos_${pos.ticket}")
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (pos.isBuy) BullGreen else BearRed
                    ) {
                        Text(
                            text = if (pos.isBuy) "BUY" else "SELL",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "#${pos.ticket} ${pos.symbol}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${pos.lots} lots",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                val pnlSign = if (pos.currentProfit >= 0) "+" else ""
                Text(
                    text = String.format(Locale.US, "%s$%.2f", pnlSign, pos.currentProfit),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = if (pos.currentProfit >= 0) BullGreen else BearRed
                )
            }

            // Price Details and Stealth Stop tags
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Open: ${String.format(Locale.US, formatStr, pos.openPrice)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
                Text(
                    text = "Stealth SL: ${String.format(Locale.US, formatStr, pos.sl)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BearRed.copy(alpha = 0.9f)
                )
                Text(
                    text = "TP: ${String.format(Locale.US, formatStr, pos.tp)}",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BullGreen.copy(alpha = 0.9f)
                )
            }

            // Action row: Modify & Close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onModify,
                    modifier = Modifier.height(28.dp).testTag("btn_modify_${pos.ticket}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Modify SL/TP", fontSize = 10.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = { engine.closeSinglePosition(pos.ticket) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    modifier = Modifier.height(28.dp).testTag("btn_close_pos_${pos.ticket}")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Close", fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun PendingOrderItemCard(
    pending: PendingOrder,
    onCancel: () -> Unit,
    digits: Int
) {
    val formatStr = "%.${digits}f"

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(8.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = AccentGold.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = pending.orderType.label,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "#${pending.ticket} ${pending.symbol}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Trigger: ${String.format(Locale.US, formatStr, pending.triggerPrice)} | ${pending.lots} lots",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
            }

            IconButton(onClick = onCancel) {
                Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel", tint = BearRed)
            }
        }
    }
}

@Composable
fun PendingOrderModalDialog(
    engine: TradingEngine,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(OrderType.BUY_LIMIT) }
    var lotInput by remember { mutableStateOf(engine.activeLotSize.toString()) }
    var priceInput by remember {
        mutableStateOf(String.format(Locale.US, "%.${engine.currentAsset.digits}f", engine.currentPrice))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Place MT5 Pending Order", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select Order Type:", fontSize = 12.sp, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(OrderType.BUY_LIMIT, OrderType.SELL_LIMIT, OrderType.BUY_STOP, OrderType.SELL_STOP).forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type.label, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = lotInput,
                    onValueChange = { lotInput = it },
                    label = { Text("Volume (Lots)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("Trigger Price") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val lot = lotInput.toDoubleOrNull() ?: 0.05
                    val price = priceInput.toDoubleOrNull() ?: engine.currentPrice
                    engine.placePendingOrder(selectedType, lot, price)
                    onDismiss()
                }
            ) {
                Text("Place Order")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ModifyPositionModalDialog(
    pos: SimulatedPosition,
    digits: Int,
    onDismiss: () -> Unit,
    onSave: (Double, Double) -> Unit
) {
    val formatStr = "%.${digits}f"
    var slInput by remember { mutableStateOf(String.format(Locale.US, formatStr, pos.sl)) }
    var tpInput by remember { mutableStateOf(String.format(Locale.US, formatStr, pos.tp)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modify Order #${pos.ticket}", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "${if (pos.isBuy) "BUY" else "SELL"} ${pos.lots} lots @ ${String.format(Locale.US, formatStr, pos.openPrice)}",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                OutlinedTextField(
                    value = slInput,
                    onValueChange = { slInput = it },
                    label = { Text("Stealth Stop Loss") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = tpInput,
                    onValueChange = { tpInput = it },
                    label = { Text("Stealth Take Profit") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newSl = slInput.toDoubleOrNull() ?: pos.sl
                    val newTp = tpInput.toDoubleOrNull() ?: pos.tp
                    onSave(newSl, newTp)
                }
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun TradeJournalModalDialog(
    engine: TradingEngine,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MT5 Trade Execution Journal", color = TextPrimary) },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(engine.tradeJournal, key = { it.id }) { entry ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = entry.action,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = AccentCyan
                                )
                                Text(
                                    text = entry.timestamp,
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = entry.details,
                                fontSize = 11.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun DashboardMetricRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
        Text(
            text = value,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isBold) FontWeight.Black else FontWeight.Medium,
            color = valueColor
        )
    }
}

@Composable
fun CandlestickCanvas(
    candles: List<com.example.trading.SimulatedCandle>,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (candles.isEmpty()) return@Canvas

        val gridColor = Color(0xFF192233)
        val stepY = size.height / 5f
        for (i in 1..4) {
            drawLine(
                color = gridColor,
                start = Offset(0f, stepY * i),
                end = Offset(size.width, stepY * i),
                strokeWidth = 1f
            )
        }

        val stepX = size.width / 6f
        for (i in 1..5) {
            drawLine(
                color = gridColor,
                start = Offset(stepX * i, 0f),
                end = Offset(stepX * i, size.height),
                strokeWidth = 1f
            )
        }

        var minPrice = candles.minOf { it.low }
        var maxPrice = candles.maxOf { it.high }
        if (maxPrice <= minPrice) maxPrice = minPrice + 1.0
        val priceRange = maxPrice - minPrice

        val candleWidth = max(2f, (size.width / candles.size) - 2f)

        candles.forEachIndexed { index, candle ->
            val x = index * (candleWidth + 2f) + candleWidth / 2f
            val isBull = candle.close >= candle.open
            val color = if (isBull) Color(0xFF10B981) else Color(0xFFEF4444)

            val openY = size.height - ((candle.open - minPrice) / priceRange * size.height).toFloat()
            val closeY = size.height - ((candle.close - minPrice) / priceRange * size.height).toFloat()
            val highY = size.height - ((candle.high - minPrice) / priceRange * size.height).toFloat()
            val lowY = size.height - ((candle.low - minPrice) / priceRange * size.height).toFloat()

            // Wick
            drawLine(
                color = color,
                start = Offset(x, highY),
                end = Offset(x, lowY),
                strokeWidth = 1.5f
            )

            // Body
            val topY = min(openY, closeY)
            val bodyHeight = max(2f, kotlin.math.abs(closeY - openY))
            drawRect(
                color = color,
                topLeft = Offset(x - candleWidth / 2f, topY),
                size = androidx.compose.ui.geometry.Size(candleWidth, bodyHeight)
            )
        }
    }
}
