package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.trading.BrokerConnectionState
import com.example.trading.BrokerCredentials
import com.example.trading.PRESET_BROKER_SERVERS
import com.example.trading.SimulatedPosition
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BrokerScreen(
    engine: TradingEngine,
    modifier: Modifier = Modifier
) {
    var showLoginForm by remember { mutableStateOf(engine.brokerConnectionState != BrokerConnectionState.CONNECTED) }
    var loginIdInput by remember { mutableStateOf(engine.brokerCredentials.loginId) }
    var passwordInput by remember { mutableStateOf(engine.brokerCredentials.password) }
    var selectedServer by remember { mutableStateOf(engine.brokerCredentials.server) }
    var customServerInput by remember { mutableStateOf("") }
    var endpointInput by remember { mutableStateOf(engine.brokerCredentials.bridgeEndpoint) }
    var passwordVisible by remember { mutableStateOf(false) }
    var rememberCredentials by remember { mutableStateOf(engine.brokerCredentials.rememberCredentials) }

    var selectedExecLot by remember { mutableDoubleStateOf(engine.activeLotSize) }

    val isConnected = engine.brokerConnectionState == BrokerConnectionState.CONNECTED
    val isConnecting = engine.brokerConnectionState == BrokerConnectionState.CONNECTING

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Broker Connection Header Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(
                                        when (engine.brokerConnectionState) {
                                            BrokerConnectionState.CONNECTED -> BullGreen
                                            BrokerConnectionState.CONNECTING -> AccentGold
                                            else -> BearRed
                                        },
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = if (isConnected) "XM GLOBAL MT5: CONNECTED" else if (isConnecting) "CONNECTING TO BROKER..." else "BROKER DISCONNECTED",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 13.sp,
                                    color = when (engine.brokerConnectionState) {
                                        BrokerConnectionState.CONNECTED -> BullGreen
                                        BrokerConnectionState.CONNECTING -> AccentGold
                                        else -> BearRed
                                    }
                                )
                                Text(
                                    text = "Account #${engine.brokerAccountInfo.loginId} • ${engine.brokerAccountInfo.serverName}",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = AccentCyan.copy(alpha = 0.15f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${engine.brokerAccountInfo.pingLatencyMs} ms",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = AccentCyan
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { engine.syncBrokerData() },
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("btn_broker_sync")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Sync Broker Data",
                                    tint = AccentCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Server Time: ${engine.brokerAccountInfo.serverTime} • Synced: ${engine.brokerAccountInfo.lastSyncTime}",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                        Text(
                            text = if (showLoginForm) "Hide Login Form ▲" else "Modify Login Form ▼",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyan,
                            modifier = Modifier.clickable { showLoginForm = !showLoginForm }
                        )
                    }
                }
            }
        }

        // 2. XM / MT5 Broker Account Login Interface
        item {
            AnimatedVisibility(visible = showLoginForm) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.VpnKey, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "XM / MT5 BROKER CREDENTIALS & GATEWAY",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        // Account Login ID
                        OutlinedTextField(
                            value = loginIdInput,
                            onValueChange = { loginIdInput = it },
                            label = { Text("MT5 Account Login ID", fontSize = 11.sp) },
                            placeholder = { Text("e.g., 10892415", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_broker_login")
                        )

                        // Password with Visibility Toggle
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Master / Investor Password", fontSize = 11.sp) },
                            placeholder = { Text("Enter MT5 Password", fontSize = 11.sp) },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle password visibility",
                                        tint = TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_broker_password")
                        )

                        // Broker Server Selector Chips
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Broker Server:", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                PRESET_BROKER_SERVERS.forEach { serverName ->
                                    FilterChip(
                                        selected = selectedServer == serverName,
                                        onClick = { selectedServer = serverName },
                                        label = { Text(serverName, fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AccentCyan.copy(alpha = 0.2f),
                                            selectedLabelColor = AccentCyan
                                        )
                                    )
                                }
                            }
                        }

                        if (selectedServer == "Custom Server") {
                            OutlinedTextField(
                                value = customServerInput,
                                onValueChange = { customServerInput = it },
                                label = { Text("Custom MT5 Server Name", fontSize = 11.sp) },
                                placeholder = { Text("e.g. ICMarkets-Live02", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Local Bridge Endpoint / VPS Address
                        OutlinedTextField(
                            value = endpointInput,
                            onValueChange = { endpointInput = it },
                            label = { Text("MT5 Terminal Local Gateway / Bridge URL", fontSize = 11.sp) },
                            placeholder = { Text("http://127.0.0.1:8080/mql5_bridge", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Remember Credentials Locally", fontSize = 12.sp, color = TextSecondary)
                            Switch(
                                checked = rememberCredentials,
                                onCheckedChange = { rememberCredentials = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val finalServer = if (selectedServer == "Custom Server" && customServerInput.isNotBlank()) {
                                        customServerInput.trim()
                                    } else {
                                        selectedServer
                                    }
                                    engine.connectBroker(
                                        BrokerCredentials(
                                            loginId = loginIdInput.trim(),
                                            password = passwordInput,
                                            server = finalServer,
                                            bridgeEndpoint = endpointInput.trim(),
                                            rememberCredentials = rememberCredentials
                                        )
                                    )
                                    showLoginForm = false
                                },
                                enabled = !isConnecting,
                                colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = Color.Black),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("btn_broker_connect")
                            ) {
                                if (isConnecting) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Connecting...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Connect Broker", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (isConnected) {
                                OutlinedButton(
                                    onClick = { engine.disconnectBroker() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = BearRed),
                                    modifier = Modifier
                                        .weight(0.8f)
                                        .height(44.dp)
                                        .testTag("btn_broker_disconnect")
                                ) {
                                    Icon(imageVector = Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Disconnect", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Real-Time Account Metrics (6-Pack Financial Dashboard Grid)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "SYNCHRONIZED ACCOUNT TELEMETRY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccountMetricCard(
                        title = "LIVE BALANCE",
                        value = formatCurrency(engine.accountBalance),
                        subtext = "USD • Cash settled",
                        valueColor = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    AccountMetricCard(
                        title = "REAL-TIME EQUITY",
                        value = formatCurrency(engine.accountEquity),
                        subtext = "${if (engine.floatingProfit >= 0) "+" else ""}${formatCurrency(engine.floatingProfit)} open",
                        valueColor = if (engine.floatingProfit >= 0) BullGreen else BearRed,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccountMetricCard(
                        title = "MARGIN USED",
                        value = formatCurrency(engine.marginUsed),
                        subtext = "Active collateral",
                        valueColor = TextPrimary,
                        modifier = Modifier.weight(1f)
                    )

                    AccountMetricCard(
                        title = "FREE MARGIN",
                        value = formatCurrency(engine.freeMargin),
                        subtext = "Available for trades",
                        valueColor = AccentCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccountMetricCard(
                        title = "MARGIN LEVEL %",
                        value = if (engine.marginUsed > 0) "${String.format(Locale.US, "%.1f", engine.marginLevelPercent)}%" else "∞",
                        subtext = if (engine.marginLevelPercent > 500.0) "Healthy Buffer" else "Monitor Exposure",
                        valueColor = if (engine.marginLevelPercent > 500.0 || engine.marginUsed == 0.0) BullGreen else AccentGold,
                        modifier = Modifier.weight(1f)
                    )

                    AccountMetricCard(
                        title = "ACCOUNT LEVERAGE",
                        value = "1:${engine.accountLeverage}",
                        subtext = "XM Dynamic Ratio",
                        valueColor = AccentGold,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Leverage Selector Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Leverage Mode:", fontSize = 11.sp, color = TextMuted)
                    listOf(100, 200, 500, 1000).forEach { lev ->
                        FilterChip(
                            selected = engine.accountLeverage == lev,
                            onClick = { engine.updateLeverage(lev) },
                            label = { Text("1:$lev", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentGold.copy(alpha = 0.2f),
                                selectedLabelColor = AccentGold
                            ),
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }
        }

        // 4. Anti-Manipulation & Hidden Stealth Protection Indicator
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = BullGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BROKER-BLIND STEALTH PROTECTION",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = BullGreen
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BullGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "ACTIVE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = BullGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "Orders sent via this companion app operate in Broker-Blind mode. Virtual SL/TP are managed in client RAM and trigger instant market exits when touched. Broker dealing desks cannot hunt your stops.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("• Anti-Spread-Spike Guard: ${engine.config.maxSpreadPoints} pts", fontSize = 10.sp, color = TextMuted)
                        Text("• Max Slippage Tolerance: ${engine.config.maxSlippagePoints} pts", fontSize = 10.sp, color = TextMuted)
                    }
                }
            }
        }

        // 5. Fast 1-Click Remote Order Execution Pad
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "FAST REMOTE TRADE DISPATCH (${engine.currentAsset.symbol})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Text(
                            text = "Spread: ${engine.currentAsset.spreadPoints} pts",
                            fontSize = 11.sp,
                            color = AccentGold
                        )
                    }

                    // Lot Size Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Lot Size:", fontSize = 11.sp, color = TextSecondary)
                        listOf(0.01, 0.05, 0.10, 0.20, 0.50, 1.00).forEach { lot ->
                            FilterChip(
                                selected = selectedExecLot == lot,
                                onClick = {
                                    selectedExecLot = lot
                                    engine.activeLotSize = lot
                                },
                                label = { Text(String.format(Locale.US, "%.2f", lot), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AccentCyan.copy(alpha = 0.25f),
                                    selectedLabelColor = AccentCyan
                                ),
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }

                    // BUY and SELL Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { engine.executeMarketBuy(selectedExecLot) },
                            colors = ButtonDefaults.buttonColors(containerColor = BullGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_broker_buy")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("BUY $selectedExecLot LOT", fontWeight = FontWeight.Black, fontSize = 12.sp)
                                Text("@ ${formatPrice(engine.currentAsk, engine.currentAsset.digits)}", fontSize = 10.sp)
                            }
                        }

                        Button(
                            onClick = { engine.executeMarketSell(selectedExecLot) },
                            colors = ButtonDefaults.buttonColors(containerColor = BearRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("btn_broker_sell")
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("SELL $selectedExecLot LOT", fontWeight = FontWeight.Black, fontSize = 12.sp)
                                Text("@ ${formatPrice(engine.currentBid, engine.currentAsset.digits)}", fontSize = 10.sp)
                            }
                        }
                    }

                    // Emergency Close Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { engine.closeAllPositions(onlyProfitable = true) },
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .testTag("btn_broker_close_profitable"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BullGreen)
                        ) {
                            Text("Close Profitable", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { engine.closeAllPositions(onlyProfitable = false) },
                            colors = ButtonDefaults.buttonColors(containerColor = BearRed.copy(alpha = 0.85f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .testTag("btn_broker_close_all")
                        ) {
                            Icon(imageVector = Icons.Default.Block, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Emergency Close All", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 6. Synchronized Open Broker Positions List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SYNCHRONIZED OPEN POSITIONS (${engine.openPositions.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )

                if (engine.openPositions.isNotEmpty()) {
                    Text(
                        text = "Net P/L: ${formatCurrency(engine.floatingProfit)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (engine.floatingProfit >= 0) BullGreen else BearRed
                    )
                }
            }
        }

        if (engine.openPositions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = TextMuted, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("No open positions on broker account", fontSize = 12.sp, color = TextMuted)
                            Text("Use the 1-Click execution pad above to enter protected positions", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        } else {
            items(engine.openPositions, key = { it.ticket }) { pos ->
                BrokerPositionItem(
                    pos = pos,
                    currentPrice = if (pos.isBuy) engine.currentBid else engine.currentAsk,
                    digits = engine.currentAsset.digits,
                    onClose = { engine.closeSinglePosition(pos.ticket) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AccountMetricCard(
    title: String,
    value: String,
    subtext: String,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontSize = 10.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text(
                text = value,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                color = valueColor
            )
            Text(subtext, fontSize = 10.sp, color = TextSecondary)
        }
    }
}

@Composable
fun BrokerPositionItem(
    pos: SimulatedPosition,
    currentPrice: Double,
    digits: Int,
    onClose: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(10.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (pos.isBuy) BullGreen.copy(alpha = 0.18f) else BearRed.copy(alpha = 0.18f)
                    ) {
                        Text(
                            text = if (pos.isBuy) "BUY" else "SELL",
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp,
                            color = if (pos.isBuy) BullGreen else BearRed,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${pos.symbol} • ${pos.lots} Lot",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "#${pos.ticket}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }

                Text(
                    text = formatCurrency(pos.currentProfit),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = if (pos.currentProfit >= 0) BullGreen else BearRed
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Open: ${formatPrice(pos.openPrice, digits)} → Current: ${formatPrice(currentPrice, digits)}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                    Text(
                        text = "Virtual SL: ${formatPrice(pos.sl, digits)} | TP: ${formatPrice(pos.tp, digits)} 🛡️ Broker-Blind",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }

                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = BearRed.copy(alpha = 0.8f)),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Close", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun formatCurrency(amount: Double): String {
    val sign = if (amount >= 0) "+" else ""
    return String.format(Locale.US, "%s$%.2f", sign, amount)
}

private fun formatPrice(price: Double, digits: Int): String {
    return String.format(Locale.US, "%.${digits}f", price)
}
