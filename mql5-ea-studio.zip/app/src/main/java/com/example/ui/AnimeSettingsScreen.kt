package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.anime.AnimeAnimationPose
import com.example.anime.AnimePetManager
import com.example.anime.AnimePetOverlayService
import com.example.anime.AssistantBehaviorMode
import com.example.anime.MarketSignalCue
import com.example.trading.TradingEngine
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BearRed
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AnimeSettingsScreen(
    engine: TradingEngine,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings = AnimePetManager.settings

    var hasOverlayPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else {
                true
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 48.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header & Character Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Anime Avatar Preview
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .shadow(8.dp, CircleShape)
                                .clip(CircleShape)
                                .border(
                                    2.dp,
                                    when (AnimePetManager.currentPose) {
                                        AnimeAnimationPose.CHEERING_BULL -> BullGreen
                                        AnimeAnimationPose.ALERT_BEAR -> BearRed
                                        AnimeAnimationPose.ANALYZING_CHART -> AccentGold
                                        else -> AccentCyan
                                    },
                                    CircleShape
                                )
                                .background(SurfaceCard)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_anime_assistant),
                                contentDescription = "Aoi-chan Virtual Assistant",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = settings.characterName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = if (settings.enabled) BullGreen.copy(alpha = 0.2f) else TextMuted.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (settings.enabled) "ACTIVE" else "OFFLINE",
                                        color = if (settings.enabled) BullGreen else TextMuted,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "MetaTrader 5 Algorithmic Trading Companion",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Current Pose: ${AnimePetManager.currentPose.label}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = AccentCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = SurfaceBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Speech bubble preview
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AnimePetManager.speechCueColor.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "💬 Live Speech Cue",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AnimePetManager.speechCueColor
                                )
                                Text(
                                    text = "Tap avatar to interact",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = AnimePetManager.speechText,
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Section 1: Master Toggles & System-Wide Overlay
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "FLOATING PET CONTROLS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan
                    )

                    // In-App Overlay Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Enable In-App Floating Companion",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Displays Aoi-chan floating and reacting to charts inside the app",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                        Switch(
                            checked = settings.enabled,
                            onCheckedChange = {
                                AnimePetManager.updateSettings(settings.copy(enabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AccentCyan,
                                checkedTrackColor = SurfaceCard
                            ),
                            modifier = Modifier.testTag("switch_anime_pet_enabled")
                        )
                    }

                    HorizontalDivider(color = SurfaceBorder)

                    // System-Wide Home Screen Overlay Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "System-Wide Home Screen Overlay",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    Icons.Default.Security,
                                    contentDescription = null,
                                    tint = if (hasOverlayPermission) BullGreen else AccentGold,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Text(
                                text = "Let Aoi-chan float above Android Home Screen & other apps while MT5 trades",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }

                        Switch(
                            checked = settings.systemOverlayEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                                        // Request permission
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")
                                        ).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        context.startActivity(intent)
                                    } else {
                                        AnimePetManager.updateSettings(settings.copy(systemOverlayEnabled = true))
                                        AnimePetOverlayService.start(context)
                                    }
                                } else {
                                    AnimePetManager.updateSettings(settings.copy(systemOverlayEnabled = false))
                                    AnimePetOverlayService.stop(context)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = BullGreen,
                                checkedTrackColor = SurfaceCard
                            ),
                            modifier = Modifier.testTag("switch_system_overlay")
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AccentGold.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = AccentGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Grant 'Appear on top' permission to float on Home Screen.",
                                        fontSize = 11.sp,
                                        color = TextPrimary
                                    )
                                }
                                Button(
                                    onClick = {
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")
                                        ).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        context.startActivity(intent)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AccentGold),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Grant", color = BgDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = SurfaceBorder)

                    // Speech Bubble & Auto Reaction Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Speech Bubble Cues", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Shows comic bubble with market recommendations", fontSize = 11.sp, color = TextMuted)
                        }
                        Switch(
                            checked = settings.speechBubbleEnabled,
                            onCheckedChange = { AnimePetManager.updateSettings(settings.copy(speechBubbleEnabled = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                            modifier = Modifier.testTag("switch_speech_bubble")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Auto Market Reactions", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Aoi-chan auto reacts to Buy/Sell fills, profits, and spread spikes", fontSize = 11.sp, color = TextMuted)
                        }
                        Switch(
                            checked = settings.autoMarketReactions,
                            onCheckedChange = { AnimePetManager.updateSettings(settings.copy(autoMarketReactions = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                            modifier = Modifier.testTag("switch_auto_reactions")
                        )
                    }
                }
            }
        }

        // Section 2: Behavior Mode Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "ASSISTANT BEHAVIOR MODE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan
                    )

                    AssistantBehaviorMode.values().forEach { mode ->
                        val isSelected = settings.behaviorMode == mode
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) SurfaceCard else SurfaceDark
                            ),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) AccentCyan else SurfaceBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    AnimePetManager.updateSettings(settings.copy(behaviorMode = mode))
                                }
                                .testTag("card_mode_${mode.name}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = when (mode) {
                                        AssistantBehaviorMode.SMART_ADVISOR -> Icons.Default.Psychology
                                        AssistantBehaviorMode.PLAYFUL_PET -> Icons.Default.Star
                                        AssistantBehaviorMode.SILENT_GUARDIAN -> Icons.Default.Security
                                    },
                                    contentDescription = null,
                                    tint = if (isSelected) AccentCyan else TextMuted,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = mode.title,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) AccentCyan else TextPrimary
                                    )
                                    Text(
                                        text = mode.description,
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = AccentCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 3: Visual Sliders (Scale, Transparency, Duration)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "VISUALS & SIZE ADJUSTMENT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan
                    )

                    // Scale Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Character Scale", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("${(settings.scale * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
                        }
                        Slider(
                            value = settings.scale,
                            onValueChange = { AnimePetManager.updateSettings(settings.copy(scale = it)) },
                            valueRange = 0.6f..1.5f,
                            steps = 8,
                            colors = SliderDefaults.colors(
                                thumbColor = AccentCyan,
                                activeTrackColor = AccentCyan,
                                inactiveTrackColor = SurfaceBorder
                            ),
                            modifier = Modifier.testTag("slider_anime_scale")
                        )
                    }

                    // Transparency Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Transparency / Opacity", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("${(settings.transparency * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
                        }
                        Slider(
                            value = settings.transparency,
                            onValueChange = { AnimePetManager.updateSettings(settings.copy(transparency = it)) },
                            valueRange = 0.4f..1.0f,
                            steps = 5,
                            colors = SliderDefaults.colors(
                                thumbColor = AccentCyan,
                                activeTrackColor = AccentCyan,
                                inactiveTrackColor = SurfaceBorder
                            ),
                            modifier = Modifier.testTag("slider_anime_transparency")
                        )
                    }

                    // Speech Bubble Duration Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Bubble Auto-Dismiss", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("${settings.speechBubbleDurationMs / 1000f}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentCyan)
                        }
                        Slider(
                            value = settings.speechBubbleDurationMs.toFloat(),
                            onValueChange = { AnimePetManager.updateSettings(settings.copy(speechBubbleDurationMs = it.toLong())) },
                            valueRange = 2000f..8000f,
                            steps = 5,
                            colors = SliderDefaults.colors(
                                thumbColor = AccentCyan,
                                activeTrackColor = AccentCyan,
                                inactiveTrackColor = SurfaceBorder
                            ),
                            modifier = Modifier.testTag("slider_anime_speech_duration")
                        )
                    }
                }
            }
        }

        // Section 4: Live Animation & Pose Tester
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "MANUAL ANIMATION & POSE SELECTOR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan
                    )

                    Text(
                        text = "Tap any animation state below to test Aoi-chan's running, jumping, and cheer poses:",
                        fontSize = 11.sp,
                        color = TextMuted
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(AnimeAnimationPose.values()) { pose ->
                            val isCurrent = AnimePetManager.currentPose == pose
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCurrent) AccentCyan.copy(alpha = 0.2f) else SurfaceCard,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isCurrent) AccentCyan else SurfaceBorder
                                ),
                                modifier = Modifier.clickable {
                                    AnimePetManager.triggerPose(pose, 3500L)
                                    when (pose) {
                                        AnimeAnimationPose.RUNNING -> AnimePetManager.runAnimation()
                                        AnimeAnimationPose.JUMPING -> AnimePetManager.jump()
                                        AnimeAnimationPose.CHEERING_BULL -> AnimePetManager.cheerOnProfit(engine)
                                        AnimeAnimationPose.ALERT_BEAR -> AnimePetManager.say("Warning! High volatility detected! Keep stops tight! ⚠️", BearRed, pose)
                                        AnimeAnimationPose.ANALYZING_CHART -> AnimePetManager.analyzeMarketNow(engine)
                                        AnimeAnimationPose.IDLE -> AnimePetManager.say("Gently floating and monitoring tick flow... ✨", AccentCyan, pose)
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(pose.iconText, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = pose.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isCurrent) AccentCyan else TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 5: Live Trading Market Perception
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ASSISTANT MARKET PERCEPTION",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyan
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BullGreen.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "REAL-TIME MT5",
                                color = BullGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // 4-Card Telemetry Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PerceptionMetricCard(
                            label = "Symbol Tracked",
                            value = engine.currentAsset.symbol,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        PerceptionMetricCard(
                            label = "Spread Guard",
                            value = "${engine.currentAsset.spreadPoints} / ${engine.config.maxSpreadPoints} pts",
                            color = if (engine.currentAsset.spreadPoints > engine.config.maxSpreadPoints) BearRed else BullGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PerceptionMetricCard(
                            label = "Floating P/L",
                            value = String.format(Locale.US, "$%.2f", engine.floatingProfit),
                            color = if (engine.floatingProfit >= 0) BullGreen else BearRed,
                            modifier = Modifier.weight(1f)
                        )
                        PerceptionMetricCard(
                            label = "Current Signal Cue",
                            value = AnimePetManager.currentMarketCue.title,
                            color = AnimePetManager.currentMarketCue.color,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { AnimePetManager.analyzeMarketNow(engine) },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentCyan),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_ask_market_advice")
                    ) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = BgDark, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ask Aoi-chan for Immediate Market Analysis",
                            color = BgDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PerceptionMetricCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, fontSize = 10.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(3.dp))
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}
