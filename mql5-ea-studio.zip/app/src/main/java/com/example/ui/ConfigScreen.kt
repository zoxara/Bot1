package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mql5.LotMode
import com.example.mql5.Mql5Config
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun ConfigScreen(
    config: Mql5Config,
    onConfigChange: (Mql5Config) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BullGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "LIVE MQL5 SYNCHRONIZATION",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = AccentCyan
                        )
                        Text(
                            text = "Adjusting these parameters automatically updates the MQL5 script & the live simulator.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Section 1: Stealth / Hidden Stops & Trade Protection
        item {
            ConfigSectionCard(
                title = "HIDDEN STOPS & ANTI-MANIPULATION",
                icon = Icons.Default.Shield
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Hide Stops from Broker (Stealth Mode)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text(
                            text = "Broker sees zero SL/TP. Prevents stop-hunting and liquidity sweeps.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Switch(
                        checked = config.hideStopsFromBroker,
                        onCheckedChange = { onConfigChange(config.copy(hideStopsFromBroker = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_stealth_mode")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Client-Side Virtual Trailing Stop", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text(
                            text = "Dynamically ratchets stealth stop without sending network modification packets.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Switch(
                        checked = config.virtualTrailingStop,
                        onCheckedChange = { onConfigChange(config.copy(virtualTrailingStop = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_trailing_stop")
                    )
                }

                if (config.virtualTrailingStop) {
                    SliderParamRow(
                        label = "Trailing Stop Distance (Points)",
                        valueText = "${config.trailingStopPoints} pts",
                        value = config.trailingStopPoints.toFloat(),
                        valueRange = 50f..500f,
                        steps = 9,
                        onValueChange = { onConfigChange(config.copy(trailingStopPoints = it.toInt())) },
                        testTag = "slider_trail_dist"
                    )

                    SliderParamRow(
                        label = "Trailing Step (Points)",
                        valueText = "${config.trailingStepPoints} pts",
                        value = config.trailingStepPoints.toFloat(),
                        valueRange = 10f..100f,
                        steps = 9,
                        onValueChange = { onConfigChange(config.copy(trailingStepPoints = it.toInt())) },
                        testTag = "slider_trail_step"
                    )
                }

                SliderParamRow(
                    label = "Anti-Slippage Max Deviation",
                    valueText = "${config.maxSlippagePoints} pts",
                    value = config.maxSlippagePoints.toFloat(),
                    valueRange = 5f..50f,
                    steps = 9,
                    onValueChange = { onConfigChange(config.copy(maxSlippagePoints = it.toInt())) },
                    testTag = "slider_slippage"
                )

                SliderParamRow(
                    label = "Anti-Spread-Spike Max Threshold",
                    valueText = "${config.maxSpreadPoints} pts",
                    value = config.maxSpreadPoints.toFloat(),
                    valueRange = 10f..100f,
                    steps = 9,
                    onValueChange = { onConfigChange(config.copy(maxSpreadPoints = it.toInt())) },
                    testTag = "slider_spread_filter"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Anti-Manipulation Dealing Desk Shield", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text(
                            text = "Blocks trade execution if broker widens spread right before high impact ticks.",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Switch(
                        checked = config.antiManipulationProtection,
                        onCheckedChange = { onConfigChange(config.copy(antiManipulationProtection = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_anti_manipulation")
                    )
                }
            }
        }

        // Section 2: Risk & Position Sizing
        item {
            ConfigSectionCard(
                title = "RISK & POSITION SIZING",
                icon = Icons.Default.Security
            ) {
                // Fixed Lot vs Dynamic Risk %
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Dynamic Risk % Sizing", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text(
                            text = if (config.lotMode == LotMode.RISK_PERCENT) "Auto-calculate lot by risk %" else "Fixed lot per trade",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Switch(
                        checked = config.lotMode == LotMode.RISK_PERCENT,
                        onCheckedChange = { isRisk ->
                            onConfigChange(config.copy(lotMode = if (isRisk) LotMode.RISK_PERCENT else LotMode.FIXED))
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_risk_mode")
                    )
                }

                if (config.lotMode == LotMode.FIXED) {
                    SliderParamRow(
                        label = "Fixed Lot Size",
                        valueText = String.format(Locale.US, "%.2f Lots", config.fixedLot),
                        value = config.fixedLot.toFloat(),
                        valueRange = 0.01f..1.0f,
                        steps = 99,
                        onValueChange = { onConfigChange(config.copy(fixedLot = (it * 100).toInt() / 100.0)) },
                        testTag = "slider_lot"
                    )
                } else {
                    SliderParamRow(
                        label = "Risk Percentage per Trade",
                        valueText = String.format(Locale.US, "%.1f%% of Balance", config.riskPercent),
                        value = config.riskPercent.toFloat(),
                        valueRange = 0.5f..5.0f,
                        steps = 9,
                        onValueChange = { onConfigChange(config.copy(riskPercent = (it * 10).toInt() / 10.0)) },
                        testTag = "slider_risk_pct"
                    )
                }

                SliderParamRow(
                    label = "Stop Loss (Points)",
                    valueText = "${config.stopLossPoints} pts",
                    value = config.stopLossPoints.toFloat(),
                    valueRange = 100f..1500f,
                    steps = 14,
                    onValueChange = { onConfigChange(config.copy(stopLossPoints = it.toInt())) },
                    testTag = "slider_sl"
                )

                SliderParamRow(
                    label = "Take Profit (Points)",
                    valueText = "${config.takeProfitPoints} pts",
                    value = config.takeProfitPoints.toFloat(),
                    valueRange = 100f..3000f,
                    steps = 29,
                    onValueChange = { onConfigChange(config.copy(takeProfitPoints = it.toInt())) },
                    testTag = "slider_tp"
                )

                SliderParamRow(
                    label = "Max Daily Drawdown (Circuit Breaker)",
                    valueText = "${config.maxDailyDrawdownPercent}%",
                    value = config.maxDailyDrawdownPercent.toFloat(),
                    valueRange = 1.0f..10.0f,
                    steps = 9,
                    onValueChange = { onConfigChange(config.copy(maxDailyDrawdownPercent = (it * 10).toInt() / 10.0)) },
                    testTag = "slider_max_dd"
                )
            }
        }

        // Section 3: Technical Indicators & VSA Confluence
        item {
            ConfigSectionCard(
                title = "INDICATORS & VSA CONFLUENCE",
                icon = Icons.Default.ShowChart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Volume Spread Analysis (VSA)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text("Detect institutional accumulation & volume absorption", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = config.useVsaVolume,
                        onCheckedChange = { onConfigChange(config.copy(useVsaVolume = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_vsa")
                    )
                }

                SliderParamRow(
                    label = "Fast EMA Period",
                    valueText = "${config.fastEmaPeriod}",
                    value = config.fastEmaPeriod.toFloat(),
                    valueRange = 5f..30f,
                    steps = 25,
                    onValueChange = { onConfigChange(config.copy(fastEmaPeriod = it.toInt())) },
                    testTag = "slider_fast_ema"
                )

                SliderParamRow(
                    label = "Slow EMA Period",
                    valueText = "${config.slowEmaPeriod}",
                    value = config.slowEmaPeriod.toFloat(),
                    valueRange = 30f..100f,
                    steps = 14,
                    onValueChange = { onConfigChange(config.copy(slowEmaPeriod = it.toInt())) },
                    testTag = "slider_slow_ema"
                )

                SliderParamRow(
                    label = "Baseline Trend 200 EMA",
                    valueText = "${config.trendEmaPeriod}",
                    value = config.trendEmaPeriod.toFloat(),
                    valueRange = 100f..300f,
                    steps = 4,
                    onValueChange = { onConfigChange(config.copy(trendEmaPeriod = it.toInt())) },
                    testTag = "slider_trend_ema"
                )

                SliderParamRow(
                    label = "Min Win Probability % for Auto-Entry",
                    valueText = "${config.minConfidencePercent}%",
                    value = config.minConfidencePercent.toFloat(),
                    valueRange = 50f..90f,
                    steps = 8,
                    onValueChange = { onConfigChange(config.copy(minConfidencePercent = it.toInt())) },
                    testTag = "slider_confidence"
                )
            }
        }

        // Section 4: News Filter & Protection
        item {
            ConfigSectionCard(
                title = "NEWS FILTER & SAFETIES",
                icon = Icons.Default.Tune
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("High Impact News Filter", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                        Text("Pause entries before/after major economic news", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = config.useNewsFilter,
                        onCheckedChange = { onConfigChange(config.copy(useNewsFilter = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_news_filter")
                    )
                }

                if (config.useNewsFilter) {
                    SliderParamRow(
                        label = "Buffer Minutes Before News",
                        valueText = "${config.newsMinutesBefore} mins",
                        value = config.newsMinutesBefore.toFloat(),
                        valueRange = 10f..60f,
                        steps = 5,
                        onValueChange = { onConfigChange(config.copy(newsMinutesBefore = it.toInt())) },
                        testTag = "slider_news_before"
                    )

                    SliderParamRow(
                        label = "Buffer Minutes After News",
                        valueText = "${config.newsMinutesAfter} mins",
                        value = config.newsMinutesAfter.toFloat(),
                        valueRange = 10f..60f,
                        steps = 5,
                        onValueChange = { onConfigChange(config.copy(newsMinutesAfter = it.toInt())) },
                        testTag = "slider_news_after"
                    )
                }
            }

            // Firebase Cloud Messaging (FCM) Real-Time Alerts
            ConfigSectionCard(title = "FIREBASE CLOUD MESSAGING (FCM) ALERTS", icon = Icons.Default.Notifications) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Real-Time Push Alerts", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Instant notifications for trades, stop losses, and critical errors", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = config.fcmAlertsEnabled,
                        onCheckedChange = { onConfigChange(config.copy(fcmAlertsEnabled = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard),
                        modifier = Modifier.testTag("switch_fcm_alerts")
                    )
                }

                if (config.fcmAlertsEnabled) {
                    OutlinedTextField(
                        value = config.fcmServerKey,
                        onValueChange = { onConfigChange(config.copy(fcmServerKey = it)) },
                        label = { Text("FCM Server Key / Auth Bearer", fontSize = 11.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = config.fcmTargetTopic,
                        onValueChange = { onConfigChange(config.copy(fcmTargetTopic = it)) },
                        label = { Text("Broadcast Topic", fontSize = 11.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = TextPrimary),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Alert on Trade Triggers", fontSize = 12.sp, color = TextSecondary)
                        Switch(
                            checked = config.fcmNotifyTradeTriggers,
                            onCheckedChange = { onConfigChange(config.copy(fcmNotifyTradeTriggers = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Alert on Stop Loss Hit", fontSize = 12.sp, color = TextSecondary)
                        Switch(
                            checked = config.fcmNotifyStopLoss,
                            onCheckedChange = { onConfigChange(config.copy(fcmNotifyStopLoss = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Alert on Take Profit Reached", fontSize = 12.sp, color = TextSecondary)
                        Switch(
                            checked = config.fcmNotifyTakeProfit,
                            onCheckedChange = { onConfigChange(config.copy(fcmNotifyTakeProfit = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Alert on Critical Errors", fontSize = 12.sp, color = TextSecondary)
                        Switch(
                            checked = config.fcmNotifyCriticalErrors,
                            onCheckedChange = { onConfigChange(config.copy(fcmNotifyCriticalErrors = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = AccentCyan, checkedTrackColor = SurfaceCard)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ConfigSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = AccentCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = AccentCyan,
                    letterSpacing = 0.5.sp
                )
            }

            content()
        }
    }
}

@Composable
fun SliderParamRow(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit,
    testTag: String = ""
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, fontSize = 12.sp, color = TextSecondary)
            Text(text = valueText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = AccentCyan,
                activeTrackColor = AccentCyan,
                inactiveTrackColor = SurfaceCard
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
