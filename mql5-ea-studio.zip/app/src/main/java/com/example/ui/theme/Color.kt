package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0A0F1D)
val SurfaceDark = Color(0xFF111827)
val SurfaceCard = Color(0xFF1E293B)
val SurfaceBorder = Color(0xFF334155)

val BullGreen = Color(0xFF10B981)
val BullGreenLight = Color(0xFF34D399)
val BearRed = Color(0xFFEF4444)
val BearRedLight = Color(0xFFF87171)

val AccentCyan = Color(0xFF00E5FF)
val AccentBlue = Color(0xFF38BDF8)
val AccentGold = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Material Theme Mappings
val PrimaryDark = AccentCyan
val SecondaryDark = AccentBlue
val TertiaryDark = AccentGold
