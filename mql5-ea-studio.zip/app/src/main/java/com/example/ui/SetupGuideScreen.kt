package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class SetupStep(
    val title: String,
    val description: String,
    val tip: String
)

@Composable
fun SetupGuideScreen(modifier: Modifier = Modifier) {
    val steps = remember {
        listOf(
            SetupStep(
                title = "1. Open MetaEditor in MT5",
                description = "Launch your MetaTrader 5 terminal on your computer, then press F4 on your keyboard or click 'Tools' -> 'MetaQuotes Language Editor'.",
                tip = "Shortcut: Press F4 in MT5"
            ),
            SetupStep(
                title = "2. Create a New Expert Advisor",
                description = "Inside MetaEditor, click 'New' (Ctrl+N) -> select 'Expert Advisor (template)' -> click Next. Name it 'UniversalQuant_Pro_EA' -> click Finish.",
                tip = "Location: MQL5/Experts/UniversalQuant_Pro_EA.mq5"
            ),
            SetupStep(
                title = "3. Paste the MQL5 v3.00 Source Code",
                description = "Clear any existing template code in MetaEditor, then copy the complete script from the 'MQL5 Source Code' tab in this app and paste it into the editor window.",
                tip = "Use the 'Copy .mq5' button in this app"
            ),
            SetupStep(
                title = "4. Compile the Script (F7)",
                description = "Press F7 or click the green 'Compile' button in MetaEditor. Check the 'Errors' tab at the bottom to verify it compiles with 0 errors and 0 warnings.",
                tip = "Generates UniversalQuant_Pro_EA.ex5"
            ),
            SetupStep(
                title = "5. Enable Algorithmic Trading & WebRequest",
                description = "In MT5, click 'Algo Trading' in the top toolbar so it glows green. In 'Tools' -> 'Options' -> 'Expert Advisors', check 'Allow Algo Trading' and 'Allow WebRequest for listed URL'. Add http://127.0.0.1:8080 if using network bridge.",
                tip = "Essential for remote bridge and algo execution"
            ),
            SetupStep(
                title = "6. Attach EA to Any Chart",
                description = "Open any chart (e.g. XAUUSD M15, EURUSD H1, BTCUSD, US30). In the Navigator panel (Ctrl+N), expand 'Expert Advisors' and drag 'UniversalQuant_Pro_EA' onto the chart.",
                tip = "Universal asset compatibility enabled"
            ),
            SetupStep(
                title = "7. Verify Stealth Protection & VSA Radar",
                description = "On chart attachment, verify the On-Chart GUI Dashboard displays 'STEALTH STOPS: ACTIVE' (stops hidden from broker order books) and 'WIN PROBABILITY: 85% [VSA CONFIRMED]'.",
                tip = "Zero stop orders exposed to broker dealer desks"
            ),
            SetupStep(
                title = "8. Connect Mobile Companion Bridge",
                description = "Open the 'MT5 Bridge' tab in this app. Commands issued here (BUY, SELL, PENDING, CLOSE) instantly transmit via the local file/network bridge to execute on your MT5 terminal.",
                tip = "Instant remote control with sub-20ms latency"
            )
        )
    }

    val checkedSteps = remember { mutableStateMapOf<Int, Boolean>() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = null,
                        tint = AccentCyan,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "METATRADER 5 DEPLOYMENT CHECKLIST",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = AccentCyan
                        )
                        Text(
                            text = "Follow these simple steps to install, compile, and run the EA on your MT5 charts.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        itemsIndexed(steps) { index, step ->
            val isChecked = checkedSteps[index] == true
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isChecked) Color(0xFF0F2027) else SurfaceDark
                ),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isChecked) BullGreen else SurfaceBorder)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Checkbox(
                        checked = isChecked,
                        onCheckedChange = { checkedSteps[index] = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = BullGreen,
                            uncheckedColor = TextMuted,
                            checkmarkColor = Color.Black
                        ),
                        modifier = Modifier.testTag("chk_step_$index")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = step.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isChecked) BullGreen else TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = step.description,
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF131C2E)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = AccentCyan,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = step.tip,
                                    fontSize = 10.sp,
                                    color = AccentCyan
                                )
                            }
                        }
                    }
                }
            }
        }

        // Summary Note
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🔒 Stealth Architecture Security Notice",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "When 'Hide Stops from Broker' is active, the EA sends market orders with sl=0.0 and tp=0.0. The EA dynamically monitors tick quotes and executes an instantaneous PositionClose() upon breach, ensuring dealing desks cannot hunt your stops.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
