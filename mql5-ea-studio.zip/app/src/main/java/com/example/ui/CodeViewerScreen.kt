package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mql5.Mql5CodeGenerator
import com.example.mql5.Mql5Config
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.BgDark
import com.example.ui.theme.BullGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CodeViewerScreen(
    config: Mql5Config,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isCopied by remember { mutableStateOf(false) }
    var selectedSection by remember { mutableStateOf("ALL") }

    val fullCode = remember(config) {
        Mql5CodeGenerator.generateCompleteMql5Code(config)
    }

    val displayedCode = remember(fullCode, selectedSection) {
        if (selectedSection == "ALL") {
            fullCode
        } else {
            extractCodeSection(fullCode, selectedSection)
        }
    }

    val lines = remember(displayedCode) { displayedCode.lines() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Header & Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MQL5 SOURCE CODE v3.00",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )
                Text(
                    text = "UniversalQuant_Pro_EA.mq5 • ${lines.size} lines",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, fullCode)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Export MQL5 Script"))
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentCyan),
                    border = ButtonDefaults.outlinedButtonBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)
                    ),
                    modifier = Modifier.testTag("btn_share_code")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(16.dp)
                    )
                }

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("UniversalQuant_Pro_EA.mq5", fullCode)
                        clipboard.setPrimaryClip(clip)
                        isCopied = true
                        Toast.makeText(context, "Full MQL5 Script copied to clipboard!", Toast.LENGTH_SHORT).show()
                        scope.launch {
                            delay(2500)
                            isCopied = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCopied) BullGreen else AccentCyan
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_copy_code")
                ) {
                    Icon(
                        imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        tint = BgDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isCopied) "Copied!" else "Copy .mq5",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = BgDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Section Filter Chips
        val sections = listOf(
            "ALL" to "All Code",
            "STEALTH" to "Stealth Stops",
            "VSA" to "VSA Win Prob",
            "BRIDGE" to "Remote Bridge",
            "INPUTS" to "Inputs & Risk",
            "TICK" to "OnTick() Loop",
            "EXEC" to "Order Exec",
            "GUI" to "On-Chart GUI"
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            sections.forEach { (key, label) ->
                val isSelected = selectedSection == key
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedSection = key },
                    label = { Text(text = label, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AccentCyan.copy(alpha = 0.2f),
                        selectedLabelColor = AccentCyan,
                        containerColor = SurfaceCard,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = if (isSelected) AccentCyan else SurfaceBorder
                    ),
                    modifier = Modifier.testTag("chip_sec_$key")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Code Editor Box
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
            shape = RoundedCornerShape(8.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(SurfaceBorder)),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            val vScroll = rememberScrollState()
            val hScroll = rememberScrollState()

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
                    .verticalScroll(vScroll)
            ) {
                // Line Numbers
                Column(
                    modifier = Modifier
                        .padding(end = 12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    lines.indices.forEach { index ->
                        Text(
                            text = "${index + 1}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF334155),
                            lineHeight = 16.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height((lines.size * 16).dp)
                        .background(Color(0xFF1E293B))
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Source Code Lines
                Column(
                    modifier = Modifier.horizontalScroll(hScroll)
                ) {
                    lines.forEach { line ->
                        Text(
                            text = line,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = getSyntaxColor(line),
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

fun getSyntaxColor(line: String): Color {
    val trimmed = line.trimStart()
    return when {
        trimmed.startsWith("//") -> Color(0xFF64748B) // Comment
        trimmed.startsWith("#property") || trimmed.startsWith("#include") || trimmed.startsWith("#define") -> Color(0xFFF59E0B) // Preprocessor
        trimmed.startsWith("input") || trimmed.startsWith("sinput") -> Color(0xFF38BDF8) // Inputs
        trimmed.startsWith("int ") || trimmed.startsWith("void ") || trimmed.startsWith("double ") || trimmed.startsWith("bool ") || trimmed.startsWith("string ") || trimmed.startsWith("ulong ") -> Color(0xFF00E5FF) // Types
        trimmed.contains("OnInit()") || trimmed.contains("OnDeinit(") || trimmed.contains("OnTick()") || trimmed.contains("OnChartEvent(") || trimmed.contains("MonitorStealthOrders(") -> Color(0xFF10B981) // Handlers
        trimmed.startsWith("if(") || trimmed.startsWith("else") || trimmed.startsWith("return") || trimmed.startsWith("for(") -> Color(0xFFF43F5E) // Flow
        else -> Color(0xFFE2E8F0)
    }
}

fun extractCodeSection(fullCode: String, section: String): String {
    return when (section) {
        "STEALTH" -> {
            val start = fullCode.indexOf("//| STEALTH STOPS & VIRTUAL TRAILING STOP ENGINE")
            val end = fullCode.indexOf("//| VOLUME SPREAD ANALYSIS (VSA)")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "VSA" -> {
            val start = fullCode.indexOf("//| VOLUME SPREAD ANALYSIS (VSA)")
            val end = fullCode.indexOf("//| AUTOMATED TRADE EXECUTION LOGIC")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "BRIDGE" -> {
            val start = fullCode.indexOf("//| REMOTE COMPANION BRIDGE PROTOCOL")
            val end = fullCode.indexOf("//| POSITION MANAGEMENT UTILITIES")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "INPUTS" -> {
            val start = fullCode.indexOf("//| INPUT PARAMETERS")
            val end = fullCode.indexOf("//| STEALTH TRADE PROTECTION DATA STRUCTURE")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "TICK" -> {
            val start = fullCode.indexOf("//| Expert tick function")
            val end = fullCode.indexOf("//| STEALTH STOPS & VIRTUAL TRAILING STOP ENGINE")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "EXEC" -> {
            val start = fullCode.indexOf("//| ORDER EXECUTION WITH OPTIONAL STEALTH STOPS")
            val end = fullCode.indexOf("//| REMOTE COMPANION BRIDGE PROTOCOL")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        "GUI" -> {
            val start = fullCode.indexOf("//| ON-CHART GUI DASHBOARD CREATION")
            val end = fullCode.indexOf("//| End of UniversalQuant_Pro_EA.mq5")
            if (start != -1 && end != -1) fullCode.substring(start, end).trim() else fullCode
        }
        else -> fullCode
    }
}
