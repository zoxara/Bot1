package com.example.mql5

data class Mql5Config(
    val eaName: String = "UniversalQuant_Pro_EA",
    val magicNumber: Long = 882025L,
    val lotMode: LotMode = LotMode.FIXED,
    val fixedLot: Double = 0.01,
    val riskPercent: Double = 1.0,
    val stopLossPoints: Int = 300,
    val takeProfitPoints: Int = 600,
    val maxDailyDrawdownPercent: Double = 5.0,
    val fastEmaPeriod: Int = 20,
    val slowEmaPeriod: Int = 50,
    val trendEmaPeriod: Int = 200,
    val rsiPeriod: Int = 14,
    val rsiOverbought: Int = 70,
    val rsiOversold: Int = 30,
    val atrPeriod: Int = 14,
    val minConfidencePercent: Int = 75,
    val useNewsFilter: Boolean = true,
    val newsMinutesBefore: Int = 30,
    val newsMinutesAfter: Int = 30,
    val defaultAutoTrade: Boolean = true,
    // Hidden / Stealth Trade Protection
    val hideStopsFromBroker: Boolean = true,
    val virtualTrailingStop: Boolean = true,
    val trailingStopPoints: Int = 150,
    val trailingStepPoints: Int = 50,
    val maxSlippagePoints: Int = 15,
    // VSA & Win Probability Confluence
    val useVsaVolume: Boolean = true,
    val vsaPeriod: Int = 20,
    val vsaVolumeSpikeRatio: Double = 1.6,
    // MT5 Remote Control Bridge & Broker Account
    val bridgeEnabled: Boolean = true,
    val bridgeUrl: String = "http://127.0.0.1:8080/mql5_bridge",
    val bridgeAuthToken: String = "QUANT_BRIDGE_KEY_9988",
    val bridgePollIntervalMs: Int = 500,
    val brokerLoginId: String = "10892415",
    val brokerServer: String = "XMGlobal-Real 20",
    val maxSpreadPoints: Int = 35,
    val antiManipulationProtection: Boolean = true,
    // Firebase Cloud Messaging (FCM) Real-Time Alerts
    val fcmAlertsEnabled: Boolean = true,
    val fcmServerKey: String = "FIREBASE_FCM_SERVER_KEY_MQL5",
    val fcmTargetDeviceToken: String = "",
    val fcmTargetTopic: String = "mql5_trading_alerts",
    val fcmNotifyTradeTriggers: Boolean = true,
    val fcmNotifyStopLoss: Boolean = true,
    val fcmNotifyTakeProfit: Boolean = true,
    val fcmNotifyCriticalErrors: Boolean = true
)

enum class LotMode(val label: String) {
    FIXED("Fixed Lot Size"),
    RISK_PERCENT("Dynamic Risk % of Balance")
}
