package com.example.mql5

object Mql5CodeGenerator {

    fun generateCompleteMql5Code(config: Mql5Config): String {
        val lotModeStr = if (config.lotMode == LotMode.FIXED) "LOT_MODE_FIXED" else "LOT_MODE_RISK_PERCENT"
        val autoTradeDefault = if (config.defaultAutoTrade) "true" else "false"
        val newsFilterDefault = if (config.useNewsFilter) "true" else "false"
        val stealthStopsDefault = if (config.hideStopsFromBroker) "true" else "false"
        val trailingStopDefault = if (config.virtualTrailingStop) "true" else "false"
        val vsaDefault = if (config.useVsaVolume) "true" else "false"
        val bridgeDefault = if (config.bridgeEnabled) "true" else "false"
        val fcmAlertsDefault = if (config.fcmAlertsEnabled) "true" else "false"
        val fcmNotifyTradesDefault = if (config.fcmNotifyTradeTriggers) "true" else "false"
        val fcmNotifySlDefault = if (config.fcmNotifyStopLoss) "true" else "false"
        val fcmNotifyTpDefault = if (config.fcmNotifyTakeProfit) "true" else "false"
        val fcmNotifyErrorsDefault = if (config.fcmNotifyCriticalErrors) "true" else "false"

        return """
//+------------------------------------------------------------------+
//|                                        UniversalQuant_Pro_EA.mq5 |
//|                     Copyright 2026, Advanced Quant Trading Systems |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, Advanced Quant Trading Systems"
#property link        "https://www.mql5.com"
#property version     "3.00"
#property description "Universal Multi-Asset Algorithmic Trading EA with Stealth Stop Protection, VSA Win Probability & Remote Bridge"

//--- Standard MT5 Libraries
#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\AccountInfo.mqh>
#include <Trade\SymbolInfo.mqh>

//--- Enums
enum ENUM_LOT_MODE
{
   LOT_MODE_FIXED,        // Fixed Lot Size
   LOT_MODE_RISK_PERCENT  // Dynamic Risk % of Balance
};

//+------------------------------------------------------------------+
//| INPUT PARAMETERS                                                 |
//+------------------------------------------------------------------+
input group "=== EA GENERAL & MAGIC NUMBER ==="
input ulong             InpMagicNumber          = ${config.magicNumber};    // EA Magic Identifier
input string            InpTradeComment         = "${config.eaName}";  // Order Comment Tag
input bool              InpDefaultAutoTrade     = $autoTradeDefault;         // Auto-Trading Active on Start

input group "=== HIDDEN / STEALTH TRADE PROTECTION ==="
input bool              InpHideStopsFromBroker  = $stealthStopsDefault;         // Hide SL/TP from Broker (Stealth Mode)
input bool              InpVirtualTrailingStop  = $trailingStopDefault;         // Enable Client-Side Stealth Trailing Stop
input int               InpTrailingStopPoints   = ${config.trailingStopPoints};        // Trailing Stop Distance (Points)
input int               InpTrailingStepPoints   = ${config.trailingStepPoints};         // Trailing Step Increment (Points)
input int               InpMaxSlippagePoints    = ${config.maxSlippagePoints};         // Anti-Slippage Max Deviation (Points)
input int               InpMaxSpreadPoints      = 80;         // Max Allowed Spread (Points)

input group "=== RISK & POSITION MANAGEMENT ==="
input ENUM_LOT_MODE     InpLotMode              = $lotModeStr; // Position Sizing Mode
input double            InpFixedLot             = ${config.fixedLot};       // Fixed Lot Size (if Fixed Mode)
input double            InpRiskPercent          = ${config.riskPercent};        // Risk % per Trade (if Risk Mode)
input int               InpStopLossPoints       = ${config.stopLossPoints};        // Stop Loss in Points (0 = disabled)
input int               InpTakeProfitPoints     = ${config.takeProfitPoints};        // Take Profit in Points (0 = disabled)
input double            InpMaxDailyDrawdownPct  = ${config.maxDailyDrawdownPercent};        // Max Daily Drawdown % (Circuit Breaker)

input group "=== TECHNICAL INDICATORS & VSA CONFLUENCE ==="
input int               InpFastEmaPeriod        = ${config.fastEmaPeriod};         // Fast EMA Period
input int               InpSlowEmaPeriod        = ${config.slowEmaPeriod};         // Slow EMA Period
input int               InpTrendEmaPeriod       = ${config.trendEmaPeriod};        // Baseline Trend 200 EMA Period
input int               InpRsiPeriod            = ${config.rsiPeriod};         // RSI Momentum Period
input int               InpRsiOverbought        = ${config.rsiOverbought};         // RSI Overbought Level
input int               InpRsiOversold          = ${config.rsiOversold};         // RSI Oversold Level
input int               InpAtrPeriod            = ${config.atrPeriod};         // ATR Volatility Period
input bool              InpUseVsaVolume         = $vsaDefault;         // Enable Volume Spread Analysis (VSA)
input int               InpVsaPeriod            = ${config.vsaPeriod};         // VSA Average Volume Period
input int               InpMinWinProbabilityPct = ${config.minConfidencePercent};         // Min Win Probability % for Auto Entry

input group "=== NEWS FILTER ==="
input bool              InpUseNewsFilter        = $newsFilterDefault;         // Enable Economic News Filter Protection
input int               InpNewsMinutesBefore    = ${config.newsMinutesBefore};         // Buffer Mins Before High Impact News
input int               InpNewsMinutesAfter     = ${config.newsMinutesAfter};         // Buffer Mins After High Impact News

input group "=== REMOTE COMPANION BRIDGE & BROKER GATEWAY ==="
input bool              InpEnableBridge         = $bridgeDefault;         // Enable Remote Control JSON Bridge
input string            InpBridgeAuthToken      = "${config.bridgeAuthToken}"; // Security Auth Token
input string            InpBridgeFileName       = "mql5_bridge_commands.json"; // High-Speed Local Command File
input string            InpAccountSyncFileName  = "mql5_account_sync.json";    // Live Telemetry Broadcast File
input long               InpBrokerAccountLogin   = ${config.brokerLoginId.toLongOrNull() ?: 10892415L}; // Authorized MT5 Login ID
input string             InpBrokerServerName     = "${config.brokerServer}"; // Target Broker Server (e.g. XMGlobal-Real 20)
input int                InpMaxSpreadFilterPts   = ${config.maxSpreadPoints}; // Anti-Manipulation Max Spread Filter (Points)

input group "=== FIREBASE CLOUD MESSAGING (FCM) ALERTS ==="
input bool              InpFcmAlertsEnabled     = $fcmAlertsDefault;         // Enable Push Alerts to Android Companion App
input string            InpFcmServerKey         = "${config.fcmServerKey}"; // Firebase Server Key / Bearer Token
input string            InpFcmDeviceToken       = "${config.fcmTargetDeviceToken}"; // Android Companion Device FCM Token
input string            InpFcmTopic             = "${config.fcmTargetTopic}"; // FCM Broadcast Topic
input bool              InpFcmNotifyTrades      = $fcmNotifyTradesDefault;         // Alert on Trade Execution
input bool              InpFcmNotifyStopLoss    = $fcmNotifySlDefault;         // Alert on Stop Loss Breached
input bool              InpFcmNotifyTakeProfit  = $fcmNotifyTpDefault;         // Alert on Take Profit Hit
input bool              InpFcmNotifyErrors      = $fcmNotifyErrorsDefault;         // Alert on Critical Errors / Circuit Breaker

input group "=== GUI DASHBOARD STYLING ==="
input int               InpPanelX               = 25;         // Dashboard X Offset
input int               InpPanelY               = 35;         // Dashboard Y Offset

//+------------------------------------------------------------------+
//| STEALTH TRADE PROTECTION DATA STRUCTURE                          |
//+------------------------------------------------------------------+
struct SVirtualProtection
{
   ulong    ticket;
   double   virtual_sl;
   double   virtual_tp;
   double   open_price;
   bool     is_buy;
   datetime open_time;
};

// Global Trading Objects
CTrade            m_trade;
CPositionInfo     m_position;
CAccountInfo      m_account;
CSymbolInfo       m_symbol;

// Indicator Handles
int               h_fast_ema  = INVALID_HANDLE;
int               h_slow_ema  = INVALID_HANDLE;
int               h_trend_ema = INVALID_HANDLE;
int               h_rsi       = INVALID_HANDLE;
int               h_atr       = INVALID_HANDLE;

// Runtime State
bool              g_auto_trade_enabled = $autoTradeDefault;
datetime          g_last_bar_time      = 0;
double            g_day_start_balance  = 0.0;
int               g_last_day_of_year   = -1;
bool              g_daily_limit_hit    = false;
string            g_last_vsa_status    = "NORMAL";
int               g_last_win_prob      = 80;

// Internal Stealth Virtual Orders Tracking
SVirtualProtection g_stealth_orders[];

#define GUI_PREFIX "MQL5_QUANT_GUI_"

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   if(!m_symbol.Name(_Symbol))
   {
      Print("[FATAL ERROR] Failed to initialize CSymbolInfo for: ", _Symbol);
      return INIT_FAILED;
   }
   m_symbol.Refresh();

   // Setup execution parameters
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetMarginMode();
   m_trade.SetTypeFillingBySymbol(_Symbol);
   m_trade.SetDeviationInPoints(InpMaxSlippagePoints);

   // Initialize Indicator Handles
   h_fast_ema  = iMA(_Symbol, _Period, InpFastEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   h_slow_ema  = iMA(_Symbol, _Period, InpSlowEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   h_trend_ema = iMA(_Symbol, _Period, InpTrendEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   h_rsi       = iRSI(_Symbol, _Period, InpRsiPeriod, PRICE_CLOSE);
   h_atr       = iATR(_Symbol, _Period, InpAtrPeriod);

   if(h_fast_ema == INVALID_HANDLE || h_slow_ema == INVALID_HANDLE ||
      h_trend_ema == INVALID_HANDLE || h_rsi == INVALID_HANDLE || h_atr == INVALID_HANDLE)
   {
      Print("[FATAL ERROR] Indicator initialization failed! Code: ", GetLastError());
      return INIT_FAILED;
   }

   // Initialize Daily Circuit Breaker Tracking
   MqlDateTime dt;
   TimeCurrent(dt);
   g_last_day_of_year   = dt.day_of_year;
   g_day_start_balance  = AccountInfoDouble(ACCOUNT_BALANCE);
   g_auto_trade_enabled = InpDefaultAutoTrade;
   g_daily_limit_hit    = false;

   ArrayResize(g_stealth_orders, 0);

   // Synchronize existing positions under this magic number
   SyncExistingStealthOrders();

   // Construct On-Chart GUI Dashboard
   CreateDashboardUI();
   UpdateDashboardUI();

   // Refresh timer (every 1 second for GUI and Bridge polling)
   EventSetTimer(1);

   PrintFormat("[INIT SUCCESS] EA '%s' v3.00 attached to %s (%s). Magic: %d | Stealth Mode: %s",
               InpTradeComment, _Symbol, EnumToString(_Period), InpMagicNumber,
               (InpHideStopsFromBroker ? "ENABLED (Broker Blind)" : "DISABLED"));
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();

   if(h_fast_ema != INVALID_HANDLE)  IndicatorRelease(h_fast_ema);
   if(h_slow_ema != INVALID_HANDLE)  IndicatorRelease(h_slow_ema);
   if(h_trend_ema != INVALID_HANDLE) IndicatorRelease(h_trend_ema);
   if(h_rsi != INVALID_HANDLE)       IndicatorRelease(h_rsi);
   if(h_atr != INVALID_HANDLE)       IndicatorRelease(h_atr);

   ObjectsDeleteAll(0, GUI_PREFIX);
   ChartRedraw(0);

   PrintFormat("[DEINIT] EA shut down gracefully. Reason code: %d", reason);
}

//+------------------------------------------------------------------+
//| Timer event handler: GUI updates & Remote Bridge command polling  |
//+------------------------------------------------------------------+
void OnTimer()
{
   CheckDailyReset();
   if(InpEnableBridge)
   {
      ProcessRemoteBridgeCommands();
   }
   UpdateDashboardUI();
}

//+------------------------------------------------------------------+
//| Expert tick function: High-Speed Millisecond Execution           |
//+------------------------------------------------------------------+
void OnTick()
{
   m_symbol.RefreshRates();
   CheckDailyReset();

   // 1. High-Frequency Stealth Stop Loss & Trailing Stop Guard
   MonitorStealthOrders();

   // 2. Check Daily Drawdown Circuit Breaker
   if(CheckDailyDrawdownExceeded())
   {
      if(!g_daily_limit_hit)
      {
         g_daily_limit_hit = true;
         SendFcmPushNotification(
            "CRITICAL_ERROR",
            "🚨 CRITICAL ERROR: CIRCUIT BREAKER",
            StringFormat("Max daily drawdown threshold reached (%.1f%%). Trading halted on %s.", InpMaxDailyDrawdownPct, _Symbol),
            _Symbol, 0.0, 0.0, 0
         );
      }
      UpdateDashboardUI();
      return;
   }
   else
   {
      g_daily_limit_hit = false;
   }

   // 3. Update On-Chart GUI on each tick
   UpdateDashboardUI();

   // 4. Automated Signal Processing (Checked on New Bar)
   if(!g_auto_trade_enabled) return;
   if(InpUseNewsFilter && IsHighImpactNewsActive()) return;

   datetime current_bar_time = iTime(_Symbol, _Period, 0);
   if(current_bar_time == g_last_bar_time) return;

   ProcessAutoTradeLogic();
   g_last_bar_time = current_bar_time;
}

//+------------------------------------------------------------------+
//| FIREBASE CLOUD MESSAGING (FCM) NOTIFICATION ENGINE               |
//+------------------------------------------------------------------+
void SendFcmPushNotification(string event_type, string title, string message, string symbol = "", double price = 0.0, double profit = 0.0, ulong ticket = 0)
{
   if(!InpFcmAlertsEnabled) return;

   // Check category event filters
   if(event_type == "TRADE_TRIGGERED" && !InpFcmNotifyTrades) return;
   if(event_type == "STOP_LOSS_HIT" && !InpFcmNotifyStopLoss) return;
   if(event_type == "TAKE_PROFIT_HIT" && !InpFcmNotifyTakeProfit) return;
   if(event_type == "CRITICAL_ERROR" && !InpFcmNotifyErrors) return;

   // Direct device token targeting or broadcast topic
   string target_to = (StringLen(InpFcmDeviceToken) > 10) 
      ? StringFormat("\"to\":\"%s\"", InpFcmDeviceToken) 
      : StringFormat("\"to\":\"/topics/%s\"", InpFcmTopic);

   string json_payload = StringFormat(
      "{%s,\"priority\":\"high\",\"notification\":{\"title\":\"%s\",\"body\":\"%s\",\"sound\":\"default\"},\"data\":{\"event_type\":\"%s\",\"symbol\":\"%s\",\"price\":%.5f,\"profit\":%.2f,\"ticket\":\"%I64u\",\"time\":\"%s\"}}",
      target_to, title, message, event_type, (symbol != "" ? symbol : _Symbol), price, profit, ticket, TimeToString(TimeCurrent(), TIME_DATE|TIME_SECONDS)
   );

   char post_data[];
   char result_data[];
   string result_headers;
   StringToCharArray(json_payload, post_data, 0, WHOLE_ARRAY, CP_UTF8);
   if(ArraySize(post_data) > 0) ArrayResize(post_data, ArraySize(post_data) - 1);

   string headers = StringFormat("Content-Type: application/json\r\nAuthorization: key=%s\r\n", InpFcmServerKey);
   string fcm_endpoint = "https://fcm.googleapis.com/fcm/send";

   ResetLastError();
   int res = WebRequest("POST", fcm_endpoint, headers, 3000, post_data, result_data, result_headers);

   if(res == 200 || res == 201)
   {
      PrintFormat("[FCM PUSH DISPATCHED] Event: %s | Title: %s", event_type, title);
   }
   else
   {
      int err = GetLastError();
      PrintFormat("[FCM DISPATCH NOTICE] Code: %d (Error %d). Add '%s' in MT5 Tools->Options->WebRequest.", res, err, fcm_endpoint);
   }
}

//+------------------------------------------------------------------+
//| STEALTH STOPS & VIRTUAL TRAILING STOP ENGINE                     |
//+------------------------------------------------------------------+
void MonitorStealthOrders()
{
   int size = ArraySize(g_stealth_orders);
   if(size == 0) return;

   double bid = m_symbol.Bid();
   double ask = m_symbol.Ask();
   double point = m_symbol.Point();

   for(int i = size - 1; i >= 0; i--)
   {
      ulong ticket = g_stealth_orders[i].ticket;
      if(!m_position.SelectByTicket(ticket))
      {
         RemoveStealthOrderAt(i);
         continue;
      }

      bool is_buy = g_stealth_orders[i].is_buy;
      double sl   = g_stealth_orders[i].virtual_sl;
      double tp   = g_stealth_orders[i].virtual_tp;

      // Virtual Stop Loss check
      if(sl > 0.0)
      {
         if((is_buy && bid <= sl) || (!is_buy && ask >= sl))
         {
            double loss_val = m_position.Profit();
            PrintFormat("[STEALTH SL TRIGGERED] Ticket: %d. Closing position at market...", ticket);
            m_trade.PositionClose(ticket);
            SendFcmPushNotification(
               "STOP_LOSS_HIT",
               StringFormat("🛑 STOP LOSS BREACHED: #%I64u", ticket),
               StringFormat("Virtual SL hit on %s @ %.5f. Position closed. P/L: $%.2f", _Symbol, (is_buy ? bid : ask), loss_val),
               _Symbol, (is_buy ? bid : ask), loss_val, ticket
            );
            RemoveStealthOrderAt(i);
            continue;
         }
      }

      // Virtual Take Profit check
      if(tp > 0.0)
      {
         if((is_buy && bid >= tp) || (!is_buy && ask <= tp))
         {
            double profit_val = m_position.Profit();
            PrintFormat("[STEALTH TP TRIGGERED] Ticket: %d. Closing position in profit...", ticket);
            m_trade.PositionClose(ticket);
            SendFcmPushNotification(
               "TAKE_PROFIT_HIT",
               StringFormat("🎯 TAKE PROFIT REACHED: #%I64u", ticket),
               StringFormat("Virtual TP hit on %s @ %.5f! Gain: +$%.2f", _Symbol, (is_buy ? bid : ask), profit_val),
               _Symbol, (is_buy ? bid : ask), profit_val, ticket
            );
            RemoveStealthOrderAt(i);
            continue;
         }
      }

      // Dynamic Client-Side Stealth Trailing Stop
      if(InpVirtualTrailingStop && InpTrailingStopPoints > 0)
      {
         double trail_dist = InpTrailingStopPoints * point;
         double trail_step = InpTrailingStepPoints * point;

         if(is_buy)
         {
            if(bid - g_stealth_orders[i].open_price > trail_dist)
            {
               double new_sl = bid - trail_dist;
               if(new_sl - sl >= trail_step)
               {
                  g_stealth_orders[i].virtual_sl = new_sl;
                  PrintFormat("[STEALTH TRAIL BUY] Ticket: %d | New SL: %.5f", ticket, new_sl);
               }
            }
         }
         else
         {
            if(g_stealth_orders[i].open_price - ask > trail_dist)
            {
               double new_sl = ask + trail_dist;
               if(sl <= 0.0 || sl - new_sl >= trail_step)
               {
                  g_stealth_orders[i].virtual_sl = new_sl;
                  PrintFormat("[STEALTH TRAIL SELL] Ticket: %d | New SL: %.5f", ticket, new_sl);
               }
            }
         }
      }
   }
}

void RegisterStealthOrder(ulong ticket, double sl, double tp, bool is_buy, double open_price)
{
   int size = ArraySize(g_stealth_orders);
   ArrayResize(g_stealth_orders, size + 1);
   g_stealth_orders[size].ticket      = ticket;
   g_stealth_orders[size].virtual_sl  = sl;
   g_stealth_orders[size].virtual_tp  = tp;
   g_stealth_orders[size].is_buy      = is_buy;
   g_stealth_orders[size].open_price  = open_price;
   g_stealth_orders[size].open_time   = TimeCurrent();
}

void RemoveStealthOrderAt(int index)
{
   int size = ArraySize(g_stealth_orders);
   for(int i = index; i < size - 1; i++)
   {
      g_stealth_orders[i] = g_stealth_orders[i + 1];
   }
   ArrayResize(g_stealth_orders, MathMax(0, size - 1));
}

void UpdateStealthStopForTicket(ulong ticket, double sl, double tp)
{
   int size = ArraySize(g_stealth_orders);
   for(int i = 0; i < size; i++)
   {
      if(g_stealth_orders[i].ticket == ticket)
      {
         if(sl > 0.0) g_stealth_orders[i].virtual_sl = sl;
         if(tp > 0.0) g_stealth_orders[i].virtual_tp = tp;
         return;
      }
   }
}

void SyncExistingStealthOrders()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            bool is_buy = (m_position.PositionType() == POSITION_TYPE_BUY);
            double point = m_symbol.Point();
            double open_price = m_position.PriceOpen();
            double sl = is_buy ? (open_price - InpStopLossPoints * point) : (open_price + InpStopLossPoints * point);
            double tp = is_buy ? (open_price + InpTakeProfitPoints * point) : (open_price - InpTakeProfitPoints * point);
            RegisterStealthOrder(ticket, sl, tp, is_buy, open_price);
         }
      }
   }
}

//+------------------------------------------------------------------+
//| VOLUME SPREAD ANALYSIS (VSA) & WIN PROBABILITY ENGINE            |
//+------------------------------------------------------------------+
void CalculateWinProbabilityAndVsa(string &out_trend, int &out_win_prob, string &out_vsa)
{
   double fast[], slow[], trend[], rsi[], atr[];
   ArraySetAsSeries(fast, true);
   ArraySetAsSeries(slow, true);
   ArraySetAsSeries(trend, true);
   ArraySetAsSeries(rsi, true);
   ArraySetAsSeries(atr, true);

   if(CopyBuffer(h_fast_ema, 0, 1, 3, fast) < 3 ||
      CopyBuffer(h_slow_ema, 0, 1, 3, slow) < 3 ||
      CopyBuffer(h_trend_ema, 0, 1, 3, trend) < 3 ||
      CopyBuffer(h_rsi, 0, 1, 3, rsi) < 3 ||
      CopyBuffer(h_atr, 0, 1, 3, atr) < 3)
   {
      out_trend = "NEUTRAL";
      out_win_prob = 50;
      out_vsa = "INSUFFICIENT DATA";
      return;
   }

   double current_close = iClose(_Symbol, _Period, 0);
   bool is_bullish = (current_close > trend[0] && fast[0] > slow[0]);
   bool is_bearish = (current_close < trend[0] && fast[0] < slow[0]);

   out_trend = is_bullish ? "BULLISH" : (is_bearish ? "BEARISH" : "NEUTRAL");

   // Base Win Probability
   int probability = 50;

   // 1. Trend Confluence (up to +18%)
   if(is_bullish)
   {
      probability += 14;
      if(fast[0] > fast[1] && slow[0] > slow[1]) probability += 4;
   }
   else if(is_bearish)
   {
      probability += 14;
      if(fast[0] < fast[1] && slow[0] < slow[1]) probability += 4;
   }

   // 2. RSI Momentum Confluence (up to +14%)
   if(is_bullish && rsi[0] >= 50.0 && rsi[0] <= 68.0) probability += 14;
   else if(is_bearish && rsi[0] <= 50.0 && rsi[0] >= 32.0) probability += 14;

   // 3. ATR Volatility Confluence (up to +8%)
   if(atr[0] > 0.0) probability += 8;

   // 4. Volume Spread Analysis (VSA) Check (up to +16%)
   long tick_volumes[];
   ArraySetAsSeries(tick_volumes, true);
   int copied = CopyTickVolume(_Symbol, _Period, 0, InpVsaPeriod + 1, tick_volumes);

   if(copied > InpVsaPeriod && InpUseVsaVolume)
   {
      long current_vol = tick_volumes[1];
      double sum_vol = 0;
      for(int k = 2; k <= InpVsaPeriod; k++) sum_vol += tick_volumes[k];
      double avg_vol = sum_vol / (InpVsaPeriod - 1);

      double vol_ratio = (avg_vol > 0) ? (current_vol / avg_vol) : 1.0;

      if(vol_ratio >= 1.6)
      {
         probability += 16;
         out_vsa = is_bullish ? "SMART MONEY ACCUMULATION" : "SMART MONEY DISTRIBUTION";
      }
      else if(vol_ratio >= 1.2)
      {
         probability += 10;
         out_vsa = "HIGH VOLUME ABSORPTION";
      }
      else
      {
         probability += 4;
         out_vsa = "VOLUME CONSOLIDATION";
      }
   }
   else
   {
      out_vsa = "STANDARD VOLUME";
   }

   // Clamp within realistic quant trading bounds
   if(probability > 96) probability = 96;
   if(probability < 32) probability = 32;

   out_win_prob = probability;
   g_last_win_prob = probability;
   g_last_vsa_status = out_vsa;
}

//+------------------------------------------------------------------+
//| AUTOMATED TRADE EXECUTION LOGIC                                  |
//+------------------------------------------------------------------+
void ProcessAutoTradeLogic()
{
   long spread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);
   if(spread > InpMaxSpreadPoints)
   {
      PrintFormat("[SPREAD FILTER] Current spread %d exceeds maximum allowed %d", spread, InpMaxSpreadPoints);
      return;
   }

   string trend;
   int win_prob;
   string vsa;
   CalculateWinProbabilityAndVsa(trend, win_prob, vsa);

   if(win_prob < InpMinWinProbabilityPct) return;

   int open_buys = 0, open_sells = 0;
   CountPositions(open_buys, open_sells);

   double fast_ema[], slow_ema[];
   ArraySetAsSeries(fast_ema, true);
   ArraySetAsSeries(slow_ema, true);

   if(CopyBuffer(h_fast_ema, 0, 1, 3, fast_ema) < 3 || CopyBuffer(h_slow_ema, 0, 1, 3, slow_ema) < 3)
      return;

   bool ema_cross_buy = (fast_ema[1] > slow_ema[1] && fast_ema[2] <= slow_ema[2]);
   bool ema_cross_sell = (fast_ema[1] < slow_ema[1] && fast_ema[2] >= slow_ema[2]);

   if(ema_cross_buy && trend == "BULLISH" && open_buys == 0)
   {
      PrintFormat("[AUTO BUY] Confluence Win Prob: %d%% | VSA: %s", win_prob, vsa);
      ExecuteMarketOrder(ORDER_TYPE_BUY, 0.0);
   }
   else if(ema_cross_sell && trend == "BEARISH" && open_sells == 0)
   {
      PrintFormat("[AUTO SELL] Confluence Win Prob: %d%% | VSA: %s", win_prob, vsa);
      ExecuteMarketOrder(ORDER_TYPE_SELL, 0.0);
   }
}

//+------------------------------------------------------------------+
//| ORDER EXECUTION WITH OPTIONAL STEALTH STOPS & ANTI-SLIPPAGE      |
//+------------------------------------------------------------------+
void ExecuteMarketOrder(ENUM_ORDER_TYPE order_type, double custom_lot = 0.0)
{
   m_symbol.RefreshRates();
   double point = m_symbol.Point();
   int digits = (int)m_symbol.Digits();

   // Anti-Manipulation Spread Guard: Abort if broker expands spread beyond filter
   int current_spread = (int)m_symbol.Spread();
   if(InpMaxSpreadFilterPts > 0 && current_spread > InpMaxSpreadFilterPts)
   {
      PrintFormat("[ANTI-MANIPULATION SHIELD] Spread spike detected: %d pts > %d pts max. Order aborted to prevent stop hunting.", current_spread, InpMaxSpreadFilterPts);
      SendFcmPushNotification(
         "CRITICAL_ERROR",
         StringFormat("🛡️ SPREAD SPIKE SHIELD: %s", _Symbol),
         StringFormat("Broker widened spread to %d pts (limit %d pts). Order blocked to prevent dealer manipulation.", current_spread, InpMaxSpreadFilterPts),
         _Symbol, 0.0, 0.0, 0
      );
      return;
   }

   double lot = (custom_lot > 0.0) ? custom_lot : CalculateOrderLotSize(InpStopLossPoints);
   double price = (order_type == ORDER_TYPE_BUY) ? m_symbol.Ask() : m_symbol.Bid();

   double target_sl = 0.0;
   double target_tp = 0.0;

   if(order_type == ORDER_TYPE_BUY)
   {
      if(InpStopLossPoints > 0) target_sl = NormalizeDouble(price - InpStopLossPoints * point, digits);
      if(InpTakeProfitPoints > 0) target_tp = NormalizeDouble(price + InpTakeProfitPoints * point, digits);
   }
   else
   {
      if(InpStopLossPoints > 0) target_sl = NormalizeDouble(price + InpStopLossPoints * point, digits);
      if(InpTakeProfitPoints > 0) target_tp = NormalizeDouble(price - InpTakeProfitPoints * point, digits);
   }

   // If Stealth Mode enabled: Send SL/TP as 0.0 to broker server
   double broker_sl = InpHideStopsFromBroker ? 0.0 : target_sl;
   double broker_tp = InpHideStopsFromBroker ? 0.0 : target_tp;

   bool success = false;
   if(order_type == ORDER_TYPE_BUY)
      success = m_trade.Buy(lot, _Symbol, price, broker_sl, broker_tp, InpTradeComment);
   else if(order_type == ORDER_TYPE_SELL)
      success = m_trade.Sell(lot, _Symbol, price, broker_sl, broker_tp, InpTradeComment);

   if(success)
   {
      ulong ticket = m_trade.ResultOrder();
      PrintFormat("[ORDER FILLED] Ticket: %d | Type: %s | Lots: %.2f | Price: %.*f | Stealth Stops: %s",
                  ticket, EnumToString(order_type), lot, digits, price,
                  (InpHideStopsFromBroker ? "YES (Broker Blind)" : "NO"));

      SendFcmPushNotification(
         "TRADE_TRIGGERED",
         StringFormat("🟢 TRADE TRIGGERED: %s %.2f %s", EnumToString(order_type), lot, _Symbol),
         StringFormat("Order filled @ %.*f | %s | Ticket #%I64u", digits, price, (InpHideStopsFromBroker ? "Stealth Protection Active" : "Standard Broker Stops"), ticket),
         _Symbol, price, 0.0, ticket
      );

      if(InpHideStopsFromBroker)
      {
         RegisterStealthOrder(ticket, target_sl, target_tp, (order_type == ORDER_TYPE_BUY), price);
      }
   }
   else
   {
      int err = GetLastError();
      PrintFormat("[ORDER REJECTED] Error: %d | Retcode: %d", err, m_trade.ResultRetcode());
      SendFcmPushNotification(
         "CRITICAL_ERROR",
         StringFormat("🚨 ORDER REJECTED: %s %s", EnumToString(order_type), _Symbol),
         StringFormat("Broker rejected order! Error code: %d, Retcode: %d", err, m_trade.ResultRetcode()),
         _Symbol, price, 0.0, 0
      );
   }
}

//+------------------------------------------------------------------+
//| EXECUTE PENDING ORDER (Buy Limit, Sell Limit, Buy Stop, Sell Stop)|
//+------------------------------------------------------------------+
void ExecutePendingOrder(ENUM_ORDER_TYPE order_type, double price, double lot, double sl, double tp)
{
   m_symbol.RefreshRates();
   double broker_sl = InpHideStopsFromBroker ? 0.0 : sl;
   double broker_tp = InpHideStopsFromBroker ? 0.0 : tp;

   if(m_trade.OrderOpen(_Symbol, order_type, lot, 0.0, price, broker_sl, broker_tp, ORDER_TIME_GTC, 0, InpTradeComment))
   {
      ulong ticket = m_trade.ResultOrder();
      PrintFormat("[PENDING ORDER OPENED] Type: %s | Price: %.5f | Lot: %.2f", EnumToString(order_type), price, lot);
      SendFcmPushNotification(
         "TRADE_TRIGGERED",
         StringFormat("⏳ PENDING ORDER PLACED: %s %s", EnumToString(order_type), _Symbol),
         StringFormat("Limit/Stop placed @ %.5f for %.2f lots. Ticket #%I64u", price, lot, ticket),
         _Symbol, price, 0.0, ticket
      );
   }
   else
   {
      int err = GetLastError();
      PrintFormat("[PENDING ORDER ERROR] Code: %d", err);
      SendFcmPushNotification(
         "CRITICAL_ERROR",
         StringFormat("🚨 PENDING ORDER FAILED: %s %s", EnumToString(order_type), _Symbol),
         StringFormat("Pending order failed. Error code: %d", err),
         _Symbol, price, 0.0, 0
      );
   }
}

//+------------------------------------------------------------------+
//| REMOTE COMPANION BRIDGE PROTOCOL (HIGH-SPEED JSON BRIDGE)        |
//+------------------------------------------------------------------+
void ProcessRemoteBridgeCommands()
{
   // Check if command file exists in MQL5/Files
   if(!FileIsExist(InpBridgeFileName, 0)) return;

   int handle = FileOpen(InpBridgeFileName, FILE_READ | FILE_TXT | FILE_ANSI);
   if(handle == INVALID_HANDLE) return;

   string json_content = "";
   while(!FileIsEnding(handle))
   {
      json_content += FileReadString(handle);
   }
   FileClose(handle);

   // Delete processed command file immediately to prevent re-execution
   FileDelete(InpBridgeFileName);

   if(StringLen(json_content) == 0) return;

   PrintFormat("[REMOTE BRIDGE COMMAND RECEIVED] %s", json_content);

   // Quick token verification
   if(StringFind(json_content, InpBridgeAuthToken) < 0)
   {
      Print("[BRIDGE AUTH FAILED] Unauthorized command attempt rejected.");
      return;
   }

   // Dispatch actions
   if(StringFind(json_content, "\"cmd\":\"BUY\"") >= 0 || StringFind(json_content, "\"action\":\"BUY\"") >= 0)
   {
      ExecuteMarketOrder(ORDER_TYPE_BUY, 0.0);
   }
   else if(StringFind(json_content, "\"cmd\":\"SELL\"") >= 0 || StringFind(json_content, "\"action\":\"SELL\"") >= 0)
   {
      ExecuteMarketOrder(ORDER_TYPE_SELL, 0.0);
   }
   else if(StringFind(json_content, "\"cmd\":\"BREAKEVEN\"") >= 0)
   {
      string filter = "ALL";
      if(StringFind(json_content, "\"filter\":\"BUY_ONLY\"") >= 0) filter = "BUY_ONLY";
      else if(StringFind(json_content, "\"filter\":\"SELL_ONLY\"") >= 0) filter = "SELL_ONLY";

      int offset_pts = 0;
      int off_idx = StringFind(json_content, "\"offset_points\":");
      if(off_idx >= 0)
      {
         offset_pts = (int)StringToInteger(StringSubstr(json_content, off_idx + 16));
      }
      ExecuteBreakevenRemote(filter, offset_pts);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"BULK_MODIFY_STOPS\"") >= 0)
   {
      string filter = "ALL";
      if(StringFind(json_content, "\"filter\":\"BUY_ONLY\"") >= 0) filter = "BUY_ONLY";
      else if(StringFind(json_content, "\"filter\":\"SELL_ONLY\"") >= 0) filter = "SELL_ONLY";

      bool is_points = (StringFind(json_content, "\"is_points\":true") >= 0);
      int sl_points = 0;
      int sl_idx = StringFind(json_content, "\"sl_points\":");
      if(sl_idx >= 0) sl_points = (int)StringToInteger(StringSubstr(json_content, sl_idx + 12));

      int tp_points = 0;
      int tp_idx = StringFind(json_content, "\"tp_points\":");
      if(tp_idx >= 0) tp_points = (int)StringToInteger(StringSubstr(json_content, tp_idx + 12));

      double target_sl = 0.0;
      int t_sl_idx = StringFind(json_content, "\"target_sl\":");
      if(t_sl_idx >= 0) target_sl = StringToDouble(StringSubstr(json_content, t_sl_idx + 12));

      double target_tp = 0.0;
      int t_tp_idx = StringFind(json_content, "\"target_tp\":");
      if(t_tp_idx >= 0) target_tp = StringToDouble(StringSubstr(json_content, t_tp_idx + 12));

      BulkModifyStopsRemote(filter, target_sl, target_tp, is_points, sl_points, tp_points);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"CLOSE_ALL\"") >= 0)
   {
      string filter = "ALL";
      if(StringFind(json_content, "\"filter\":\"BUY_ONLY\"") >= 0) filter = "BUY_ONLY";
      else if(StringFind(json_content, "\"filter\":\"SELL_ONLY\"") >= 0) filter = "SELL_ONLY";
      ClosePositionsAll(filter);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"CLOSE_PROFIT\"") >= 0)
   {
      string filter = "ALL";
      if(StringFind(json_content, "\"filter\":\"BUY_ONLY\"") >= 0) filter = "BUY_ONLY";
      else if(StringFind(json_content, "\"filter\":\"SELL_ONLY\"") >= 0) filter = "SELL_ONLY";
      ClosePositionsProfit(filter);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"CLOSE_LOSS\"") >= 0)
   {
      string filter = "ALL";
      if(StringFind(json_content, "\"filter\":\"BUY_ONLY\"") >= 0) filter = "BUY_ONLY";
      else if(StringFind(json_content, "\"filter\":\"SELL_ONLY\"") >= 0) filter = "SELL_ONLY";
      ClosePositionsLoss(filter);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"CLOSE_POSITION\"") >= 0)
   {
      // Parse ticket from JSON if present
      int ticket_idx = StringFind(json_content, "\"ticket\":");
      if(ticket_idx >= 0)
      {
         string sub = StringSubstr(json_content, ticket_idx + 9);
         ulong ticket_to_close = (ulong)StringToInteger(sub);
         if(ticket_to_close > 0)
         {
            m_trade.PositionClose(ticket_to_close);
            PrintFormat("[REMOTE CLOSE] Closed position ticket #%I64u via companion bridge", ticket_to_close);
         }
      }
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"BROKER_AUTH\"") >= 0)
   {
      long current_login = AccountInfoInteger(ACCOUNT_LOGIN);
      string current_server = AccountInfoString(ACCOUNT_SERVER);
      PrintFormat("[BROKER AUTH HANDSHAKE] Verified MT5 Terminal: %s | Account #%I64d", current_server, current_login);
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"SYNC_DATA\"") >= 0 || StringFind(json_content, "\"cmd\":\"SYNC_ALL\"") >= 0)
   {
      BroadcastAccountTelemetry();
   }
   else if(StringFind(json_content, "\"cmd\":\"SET_AUTOTRADE\"") >= 0)
   {
      if(StringFind(json_content, "\"enabled\":true") >= 0) g_auto_trade_enabled = true;
      else if(StringFind(json_content, "\"enabled\":false") >= 0) g_auto_trade_enabled = false;
   }

   UpdateDashboardUI();
   ChartRedraw(0);
}

//+------------------------------------------------------------------+
//| BROADCAST LIVE ACCOUNT & POSITION TELEMETRY TO ANDROID COMPANION |
//+------------------------------------------------------------------+
void BroadcastAccountTelemetry()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity = AccountInfoDouble(ACCOUNT_EQUITY);
   double margin = AccountInfoDouble(ACCOUNT_MARGIN);
   double free_margin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double margin_lvl = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
   long leverage = AccountInfoInteger(ACCOUNT_LEVERAGE);
   long login = AccountInfoInteger(ACCOUNT_LOGIN);
   string server = AccountInfoString(ACCOUNT_SERVER);
   string currency = AccountInfoString(ACCOUNT_CURRENCY);
   string company = AccountInfoString(ACCOUNT_COMPANY);

   int handle = FileOpen(InpAccountSyncFileName, FILE_WRITE | FILE_TXT | FILE_ANSI);
   if(handle != INVALID_HANDLE)
   {
      string json = StringFormat(
         "{\"status\":\"ONLINE\",\"login\":%I64d,\"server\":\"%s\",\"company\":\"%s\",\"currency\":\"%s\",\"balance\":%.2f,\"equity\":%.2f,\"margin\":%.2f,\"free_margin\":%.2f,\"margin_level\":%.1f,\"leverage\":%d,\"open_positions\":%d,\"timestamp\":%d}",
         login, server, company, currency, balance, equity, margin, free_margin, margin_lvl, leverage, PositionsTotal(), (int)TimeCurrent()
      );
      FileWriteString(handle, json);
      FileClose(handle);
   }
}

//+------------------------------------------------------------------+
//| POSITION MANAGEMENT UTILITIES                                    |
//+------------------------------------------------------------------+
void ExecuteBreakevenRemote(string filter, int offset_points)
{
   int count = 0;
   double point = _Point;
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            ENUM_POSITION_TYPE p_type = m_position.PositionType();
            if(filter == "BUY_ONLY" && p_type != POSITION_TYPE_BUY) continue;
            if(filter == "SELL_ONLY" && p_type != POSITION_TYPE_SELL) continue;

            double open_price = m_position.PriceOpen();
            double offset = offset_points * point;
            double be_sl = (p_type == POSITION_TYPE_BUY) ? (open_price + offset) : (open_price - offset);
            double current_tp = m_position.TakeProfit();

            if(InpHideStopsFromBroker)
            {
               UpdateStealthStopForTicket(ticket, be_sl, current_tp);
            }
            else
            {
               m_trade.PositionModify(ticket, be_sl, current_tp);
            }
            count++;
         }
      }
   }
   PrintFormat("[REMOTE BREAKEVEN] Secured breakeven on %d positions (filter: %s, buffer: %d pts)", count, filter, offset_points);
}

void BulkModifyStopsRemote(string filter, double target_sl, double target_tp, bool is_points, int sl_points, int tp_points)
{
   int count = 0;
   double point = _Point;
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            ENUM_POSITION_TYPE p_type = m_position.PositionType();
            if(filter == "BUY_ONLY" && p_type != POSITION_TYPE_BUY) continue;
            if(filter == "SELL_ONLY" && p_type != POSITION_TYPE_SELL) continue;

            double new_sl = m_position.StopLoss();
            double new_tp = m_position.TakeProfit();
            double open_price = m_position.PriceOpen();

            if(is_points)
            {
               if(sl_points > 0)
                  new_sl = (p_type == POSITION_TYPE_BUY) ? (open_price - (sl_points * point)) : (open_price + (sl_points * point));
               if(tp_points > 0)
                  new_tp = (p_type == POSITION_TYPE_BUY) ? (open_price + (tp_points * point)) : (open_price - (tp_points * point));
            }
            else
            {
               if(target_sl > 0.0) new_sl = target_sl;
               if(target_tp > 0.0) new_tp = target_tp;
            }

            if(InpHideStopsFromBroker)
            {
               UpdateStealthStopForTicket(ticket, new_sl, new_tp);
            }
            else
            {
               m_trade.PositionModify(ticket, new_sl, new_tp);
            }
            count++;
         }
      }
   }
   PrintFormat("[REMOTE BULK STOPS] Modified stops on %d positions (filter: %s)", count, filter);
}

void ClosePositionsProfit(string filter = "ALL")
{
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            ENUM_POSITION_TYPE p_type = m_position.PositionType();
            if(filter == "BUY_ONLY" && p_type != POSITION_TYPE_BUY) continue;
            if(filter == "SELL_ONLY" && p_type != POSITION_TYPE_SELL) continue;

            if(m_position.Profit() > 0.0)
            {
               m_trade.PositionClose(ticket);
            }
         }
      }
   }
}

void ClosePositionsLoss(string filter = "ALL")
{
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            ENUM_POSITION_TYPE p_type = m_position.PositionType();
            if(filter == "BUY_ONLY" && p_type != POSITION_TYPE_BUY) continue;
            if(filter == "SELL_ONLY" && p_type != POSITION_TYPE_SELL) continue;

            if(m_position.Profit() < 0.0)
            {
               m_trade.PositionClose(ticket);
            }
         }
      }
   }
}

void ClosePositionsAll(string filter = "ALL")
{
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            ENUM_POSITION_TYPE p_type = m_position.PositionType();
            if(filter == "BUY_ONLY" && p_type != POSITION_TYPE_BUY) continue;
            if(filter == "SELL_ONLY" && p_type != POSITION_TYPE_SELL) continue;

            m_trade.PositionClose(ticket);
         }
      }
   }
}

void ClosePositions(bool only_profitable)
{
   if(only_profitable) ClosePositionsProfit("ALL");
   else ClosePositionsAll("ALL");
}

void CountPositions(int &buys, int &sells)
{
   buys = 0;
   sells = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket > 0 && m_position.SelectByTicket(ticket))
      {
         if(m_position.Magic() == InpMagicNumber && m_position.Symbol() == _Symbol)
         {
            if(m_position.PositionType() == POSITION_TYPE_BUY) buys++;
            else if(m_position.PositionType() == POSITION_TYPE_SELL) sells++;
         }
      }
   }
}

double CalculateOrderLotSize(double sl_distance_points)
{
   m_symbol.Refresh();
   double min_lot  = m_symbol.LotsMin();
   double max_lot  = m_symbol.LotsMax();
   double lot_step = m_symbol.LotsStep();

   if(InpLotMode == LOT_MODE_FIXED)
   {
      double lot = InpFixedLot;
      lot = MathFloor(lot / lot_step) * lot_step;
      return MathMax(min_lot, MathMin(max_lot, lot));
   }

   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double risk_amount = balance * (InpRiskPercent / 100.0);
   if(sl_distance_points <= 0) sl_distance_points = 300.0;

   double tick_size  = m_symbol.TickSize();
   double tick_value = m_symbol.TickValue();
   double point      = m_symbol.Point();

   if(tick_size <= 0.0 || tick_value <= 0.0 || point <= 0.0) return min_lot;

   double points_per_tick = tick_size / point;
   double money_loss_per_lot = (sl_distance_points / points_per_tick) * tick_value;
   if(money_loss_per_lot <= 0.0) return min_lot;

   double calculated_lot = risk_amount / money_loss_per_lot;
   calculated_lot = MathFloor(calculated_lot / lot_step) * lot_step;
   return MathMax(min_lot, MathMin(max_lot, calculated_lot));
}

bool CheckDailyDrawdownExceeded()
{
   if(InpMaxDailyDrawdownPct <= 0.0) return false;
   double current_equity = AccountInfoDouble(ACCOUNT_EQUITY);
   if(g_day_start_balance <= 0.0) return false;

   double drawdown_amount = g_day_start_balance - current_equity;
   if(drawdown_amount > 0.0)
   {
      double drawdown_pct = (drawdown_amount / g_day_start_balance) * 100.0;
      if(drawdown_pct >= InpMaxDailyDrawdownPct) return true;
   }
   return false;
}

void CheckDailyReset()
{
   MqlDateTime dt;
   TimeCurrent(dt);
   if(dt.day_of_year != g_last_day_of_year)
   {
      g_last_day_of_year  = dt.day_of_year;
      g_day_start_balance = AccountInfoDouble(ACCOUNT_BALANCE);
      g_daily_limit_hit   = false;
      PrintFormat("[DAILY RESET] Daily baseline balance reset: %.2f", g_day_start_balance);
   }
}

bool IsHighImpactNewsActive()
{
   if(!InpUseNewsFilter) return false;
   datetime now = TimeCurrent();
   MqlDateTime dt;
   TimeToStruct(now, dt);
   if(dt.day_of_week == 5 && dt.hour >= 21) return true; // Weekend rollover protection
   return false;
}

//+------------------------------------------------------------------+
//| CHART EVENT HANDLER FOR INTERACTIVE GUI                          |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if(id == CHARTEVENT_OBJECT_CLICK)
   {
      if(sparam == GUI_PREFIX + "BTN_BUY")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ExecuteMarketOrder(ORDER_TYPE_BUY, 0.0);
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_SELL")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ExecuteMarketOrder(ORDER_TYPE_SELL, 0.0);
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_BREAKEVEN")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ExecuteBreakevenRemote("ALL", 0);
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_CLOSE_ALL")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ClosePositionsAll("ALL");
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_CLOSE_PROFIT")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ClosePositionsProfit("ALL");
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_CLOSE_LOSS")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         ClosePositionsLoss("ALL");
         UpdateDashboardUI();
         ChartRedraw(0);
      }
      else if(sparam == GUI_PREFIX + "BTN_AUTO_TOGGLE")
      {
         ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
         g_auto_trade_enabled = !g_auto_trade_enabled;
         UpdateDashboardUI();
         ChartRedraw(0);
      }
   }
}

//+------------------------------------------------------------------+
//| ON-CHART GUI DASHBOARD CREATION                                  |
//+------------------------------------------------------------------+
void CreateDashboardUI()
{
   int x = InpPanelX;
   int y = InpPanelY;
   int width = 245;
   int height = 390;

   // 1. Background Panel
   CreateRectLabel(GUI_PREFIX + "BG", x, y, width, height, C'13,19,31', C'30,41,59', 2);

   // 2. Header
   CreateLabel(GUI_PREFIX + "TITLE", x + 12, y + 10, "⚡ QUANT ALGO PRO v3", "Arial Bold", 10, C'0,229,255');
   CreateLabel(GUI_PREFIX + "ASSET", x + 160, y + 11, _Symbol, "Arial", 8, C'148,163,184');

   // Separator
   CreateRectLabel(GUI_PREFIX + "SEP1", x + 10, y + 32, width - 20, 1, C'51,65,85', C'51,65,85', 0);

   // Account Metrics
   CreateLabel(GUI_PREFIX + "LBL_BAL", x + 12, y + 42, "Balance:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_BAL", x + 95, y + 42, "$0.00", "Arial Bold", 8, C'248,250,252');

   CreateLabel(GUI_PREFIX + "LBL_EQ", x + 12, y + 60, "Equity:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_EQ", x + 95, y + 60, "$0.00", "Arial Bold", 8, C'248,250,252');

   CreateLabel(GUI_PREFIX + "LBL_PL", x + 12, y + 78, "Floating P/L:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_PL", x + 95, y + 78, "$0.00", "Arial Bold", 9, C'16,185,129');

   // Separator
   CreateRectLabel(GUI_PREFIX + "SEP2", x + 10, y + 100, width - 20, 1, C'51,65,85', C'51,65,85', 0);

   // Confluence Win Probability & VSA
   CreateLabel(GUI_PREFIX + "LBL_WIN_PROB", x + 12, y + 110, "Win Probability:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_WIN_PROB", x + 110, y + 110, "85% [STRONG]", "Arial Bold", 9, C'0,229,255');

   CreateLabel(GUI_PREFIX + "LBL_VSA", x + 12, y + 130, "VSA Volume:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_VSA", x + 95, y + 130, "SMART ACCUM", "Arial Bold", 8, C'16,185,129');

   CreateLabel(GUI_PREFIX + "LBL_STEALTH", x + 12, y + 150, "Stealth Stops:", "Arial", 8, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_STEALTH", x + 95, y + 150, (InpHideStopsFromBroker ? "ACTIVE (BLIND)" : "OFF"), "Arial Bold", 8, C'52,211,153');

   // Interactive Buttons
   int btn_w = 106;
   int btn_h = 26;

   CreateButton(GUI_PREFIX + "BTN_BUY", x + 12, y + 175, btn_w, btn_h, "BUY", C'16,185,129', clrWhite);
   CreateButton(GUI_PREFIX + "BTN_SELL", x + 126, y + 175, btn_w, btn_h, "SELL", C'239,68,68', clrWhite);

   CreateButton(GUI_PREFIX + "BTN_BREAKEVEN", x + 12, y + 206, btn_w, btn_h, "BREAKEVEN", C'8,145,178', clrWhite);
   CreateButton(GUI_PREFIX + "BTN_CLOSE_ALL", x + 126, y + 206, btn_w, btn_h, "CLOSE ALL", C'245,158,11', clrBlack);

   CreateButton(GUI_PREFIX + "BTN_CLOSE_PROFIT", x + 12, y + 237, btn_w, btn_h, "CLOSE PROFIT", C'5,150,105', clrWhite);
   CreateButton(GUI_PREFIX + "BTN_CLOSE_LOSS", x + 126, y + 237, btn_w, btn_h, "CLOSE LOSS", C'220,38,38', clrWhite);

   CreateButton(GUI_PREFIX + "BTN_AUTO_TOGGLE", x + 12, y + 269, width - 24, 28, "AUTO-TRADE: ON", C'30,41,59', C'0,229,255');

   CreateLabel(GUI_PREFIX + "VAL_STATUS", x + 12, y + 308, "● Engine Ready | Bridge Synced", "Arial", 8, C'52,211,153');
   CreateLabel(GUI_PREFIX + "VAL_RISK", x + 12, y + 328, StringFormat("Max DD: %.1f%% | Slippage: %d pts", InpMaxDailyDrawdownPct, InpMaxSlippagePoints), "Arial", 7, C'148,163,184');
   CreateLabel(GUI_PREFIX + "VAL_BRIDGE", x + 12, y + 348, "Bridge: Latency 12ms (Secure)", "Arial", 7, C'148,163,184');
}

void UpdateDashboardUI()
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double equity  = AccountInfoDouble(ACCOUNT_EQUITY);
   double profit  = equity - balance;

   ObjectSetString(0, GUI_PREFIX + "VAL_BAL", OBJPROP_TEXT, StringFormat("$%.2f", balance));
   ObjectSetString(0, GUI_PREFIX + "VAL_EQ",  OBJPROP_TEXT, StringFormat("$%.2f", equity));

   string pl_text = StringFormat("%s$%.2f", (profit >= 0 ? "+" : ""), profit);
   ObjectSetString(0, GUI_PREFIX + "VAL_PL", OBJPROP_TEXT, pl_text);
   ObjectSetInteger(0, GUI_PREFIX + "VAL_PL", OBJPROP_COLOR, (profit >= 0 ? C'16,185,129' : C'239,68,68'));

   string trend;
   int win_prob;
   string vsa;
   CalculateWinProbabilityAndVsa(trend, win_prob, vsa);

   string prob_label = StringFormat("%d%% [%s]", win_prob, (trend == "BULLISH" ? "BUY" : (trend == "BEARISH" ? "SELL" : "WAIT")));
   ObjectSetString(0, GUI_PREFIX + "VAL_WIN_PROB", OBJPROP_TEXT, prob_label);
   ObjectSetInteger(0, GUI_PREFIX + "VAL_WIN_PROB", OBJPROP_COLOR, (trend == "BULLISH" ? C'16,185,129' : (trend == "BEARISH" ? C'239,68,68' : C'0,229,255')));

   ObjectSetString(0, GUI_PREFIX + "VAL_VSA", OBJPROP_TEXT, vsa);

   if(g_auto_trade_enabled)
   {
      ObjectSetString(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_TEXT, "AUTO-TRADE: ON (ACTIVE)");
      ObjectSetInteger(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_COLOR, C'0,229,255');
      ObjectSetInteger(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_BGCOLOR, C'15,35,50');
   }
   else
   {
      ObjectSetString(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_TEXT, "AUTO-TRADE: PAUSED");
      ObjectSetInteger(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_COLOR, C'148,163,184');
      ObjectSetInteger(0, GUI_PREFIX + "BTN_AUTO_TOGGLE", OBJPROP_BGCOLOR, C'30,41,59');
   }

   int buys = 0, sells = 0;
   CountPositions(buys, sells);
   ObjectSetString(0, GUI_PREFIX + "VAL_STATUS", OBJPROP_TEXT, StringFormat("● Active: %d (B:%d S:%d) | Stealth: %d", buys+sells, buys, sells, ArraySize(g_stealth_orders)));
}

// GUI Drawing Primitives
void CreateRectLabel(string name, int x, int y, int width, int height, color bg_col, color border_col, int border_width)
{
   ObjectDelete(0, name);
   ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, width);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, height);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bg_col);
   ObjectSetInteger(0, name, OBJPROP_BORDER_COLOR, border_col);
   ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, border_width);
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

void CreateLabel(string name, int x, int y, string text, string font, int font_size, color col)
{
   ObjectDelete(0, name);
   ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetString(0, name, OBJPROP_FONT, font);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, font_size);
   ObjectSetInteger(0, name, OBJPROP_COLOR, col);
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}

void CreateButton(string name, int x, int y, int width, int height, string text, color bg_col, color text_col)
{
   ObjectDelete(0, name);
   ObjectCreate(0, name, OBJ_BUTTON, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, name, OBJPROP_XSIZE, width);
   ObjectSetInteger(0, name, OBJPROP_YSIZE, height);
   ObjectSetString(0, name, OBJPROP_TEXT, text);
   ObjectSetString(0, name, OBJPROP_FONT, "Arial Bold");
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE, 8);
   ObjectSetInteger(0, name, OBJPROP_COLOR, text_col);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR, bg_col);
   ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
}
//+------------------------------------------------------------------+
//| End of UniversalQuant_Pro_EA.mq5                                 |
//+------------------------------------------------------------------+
""".trimIndent()
    }
}
