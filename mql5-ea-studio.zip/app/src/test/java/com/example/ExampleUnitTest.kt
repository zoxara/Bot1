package com.example

import com.example.mql5.Mql5CodeGenerator
import com.example.mql5.Mql5Config
import com.example.trading.OrderType
import com.example.trading.TradingEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun mql5CodeGenerator_includesAllStealthVsaAndBridgeStructures() {
        val config = Mql5Config(
            hideStopsFromBroker = true,
            virtualTrailingStop = true,
            useVsaVolume = true,
            bridgeEnabled = true
        )
        val code = Mql5CodeGenerator.generateCompleteMql5Code(config)

        assertTrue("Code should contain SVirtualProtection struct", code.contains("struct SVirtualProtection"))
        assertTrue("Code should contain MonitorStealthOrders function", code.contains("void MonitorStealthOrders()"))
        assertTrue("Code should contain VSA volume calculation", code.contains("CalculateWinProbabilityAndVsa"))
        assertTrue("Code should contain bridge command processor", code.contains("void ProcessRemoteBridgeCommands()"))
        assertTrue("Code should contain bridge JSON filename", code.contains("mql5_bridge_commands.json"))
        assertTrue("Code should contain OnChartEvent handler", code.contains("void OnChartEvent("))
        assertTrue("Code should contain ExecuteMarketOrder", code.contains("ExecuteMarketOrder("))
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun tradingEngine_executesOrdersAndDispatchesBridgeLogs() = runTest {
        val testDispatcher = StandardTestDispatcher(testScheduler)
        val testScope = TestScope(testDispatcher)
        val config = Mql5Config(hideStopsFromBroker = true)
        val engine = TradingEngine(testScope, config)

        val initialPositions = engine.openPositions.size
        engine.executeMarketBuy()

        assertEquals("Should have 1 open position", initialPositions + 1, engine.openPositions.size)
        val pos = engine.openPositions.first()
        assertTrue("Position should have stealth enabled", pos.isStealthStop)

        // Verify Bridge Command was recorded
        assertTrue("Bridge logs should record the buy command", engine.bridgeLogs.isNotEmpty())
        val hasBuyCommand = engine.bridgeLogs.any { it.jsonPayload.contains("\"action\":\"BUY\"") }
        assertTrue("Payload should contain BUY action", hasBuyCommand)

        // Place Pending Order
        engine.placePendingOrder(OrderType.BUY_LIMIT, lot = 0.2, targetPrice = 2600.00)
        assertEquals("Should have 1 pending order", 1, engine.pendingOrders.size)

        // Cancel Pending Order
        val pendingTicket = engine.pendingOrders.first().ticket
        engine.cancelPendingOrder(pendingTicket)
        assertEquals("Pending orders should be empty after cancel", 0, engine.pendingOrders.size)
    }
}
